package org.apache.wml;

public abstract interface WMLMetaElement
  extends WMLElement
{
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract void setHttpEquiv(String paramString);
  
  public abstract String getHttpEquiv();
  
  public abstract void setForua(boolean paramBoolean);
  
  public abstract boolean getForua();
  
  public abstract void setScheme(String paramString);
  
  public abstract String getScheme();
  
  public abstract void setContent(String paramString);
  
  public abstract String getContent();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLMetaElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */