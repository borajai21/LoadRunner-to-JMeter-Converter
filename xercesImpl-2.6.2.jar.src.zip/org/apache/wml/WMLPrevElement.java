package org.apache.wml;

public abstract interface WMLPrevElement
  extends WMLElement
{}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLPrevElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */