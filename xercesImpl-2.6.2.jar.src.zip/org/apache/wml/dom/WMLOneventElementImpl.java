package org.apache.wml.dom;

import org.apache.wml.WMLOneventElement;
import org.apache.xerces.dom.ElementImpl;

public class WMLOneventElementImpl
  extends WMLElementImpl
  implements WMLOneventElement
{
  public WMLOneventElementImpl(WMLDocumentImpl paramWMLDocumentImpl, String paramString)
  {
    super(paramWMLDocumentImpl, paramString);
  }
  
  public void setClassName(String paramString)
  {
    setAttribute("class", paramString);
  }
  
  public String getClassName()
  {
    return getAttribute("class");
  }
  
  public void setId(String paramString)
  {
    setAttribute("id", paramString);
  }
  
  public String getId()
  {
    return getAttribute("id");
  }
  
  public void setType(String paramString)
  {
    setAttribute("type", paramString);
  }
  
  public String getType()
  {
    return getAttribute("type");
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\dom\WMLOneventElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */