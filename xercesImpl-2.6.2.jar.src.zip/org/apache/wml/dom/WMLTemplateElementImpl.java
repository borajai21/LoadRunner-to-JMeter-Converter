package org.apache.wml.dom;

import org.apache.wml.WMLTemplateElement;
import org.apache.xerces.dom.ElementImpl;

public class WMLTemplateElementImpl
  extends WMLElementImpl
  implements WMLTemplateElement
{
  public WMLTemplateElementImpl(WMLDocumentImpl paramWMLDocumentImpl, String paramString)
  {
    super(paramWMLDocumentImpl, paramString);
  }
  
  public void setOnTimer(String paramString)
  {
    setAttribute("ontimer", paramString);
  }
  
  public String getOnTimer()
  {
    return getAttribute("ontimer");
  }
  
  public void setOnEnterBackward(String paramString)
  {
    setAttribute("onenterbackward", paramString);
  }
  
  public String getOnEnterBackward()
  {
    return getAttribute("onenterbackward");
  }
  
  public void setClassName(String paramString)
  {
    setAttribute("class", paramString);
  }
  
  public String getClassName()
  {
    return getAttribute("class");
  }
  
  public void setId(String paramString)
  {
    setAttribute("id", paramString);
  }
  
  public String getId()
  {
    return getAttribute("id");
  }
  
  public void setOnEnterForward(String paramString)
  {
    setAttribute("onenterforward", paramString);
  }
  
  public String getOnEnterForward()
  {
    return getAttribute("onenterforward");
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\dom\WMLTemplateElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */