package org.apache.wml.dom;

import org.apache.wml.WMLMetaElement;
import org.apache.xerces.dom.ElementImpl;

public class WMLMetaElementImpl
  extends WMLElementImpl
  implements WMLMetaElement
{
  public WMLMetaElementImpl(WMLDocumentImpl paramWMLDocumentImpl, String paramString)
  {
    super(paramWMLDocumentImpl, paramString);
  }
  
  public void setForua(boolean paramBoolean)
  {
    setAttribute("forua", paramBoolean);
  }
  
  public boolean getForua()
  {
    return getAttribute("forua", false);
  }
  
  public void setScheme(String paramString)
  {
    setAttribute("scheme", paramString);
  }
  
  public String getScheme()
  {
    return getAttribute("scheme");
  }
  
  public void setClassName(String paramString)
  {
    setAttribute("class", paramString);
  }
  
  public String getClassName()
  {
    return getAttribute("class");
  }
  
  public void setHttpEquiv(String paramString)
  {
    setAttribute("http-equiv", paramString);
  }
  
  public String getHttpEquiv()
  {
    return getAttribute("http-equiv");
  }
  
  public void setId(String paramString)
  {
    setAttribute("id", paramString);
  }
  
  public String getId()
  {
    return getAttribute("id");
  }
  
  public void setContent(String paramString)
  {
    setAttribute("content", paramString);
  }
  
  public String getContent()
  {
    return getAttribute("content");
  }
  
  public void setName(String paramString)
  {
    setAttribute("name", paramString);
  }
  
  public String getName()
  {
    return getAttribute("name");
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\dom\WMLMetaElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */