package org.apache.wml;

public abstract interface WMLBElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLBElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */