package org.apache.wml;

public abstract interface WMLAccessElement
  extends WMLElement
{
  public abstract void setDomain(String paramString);
  
  public abstract String getDomain();
  
  public abstract void setPath(String paramString);
  
  public abstract String getPath();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLAccessElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */