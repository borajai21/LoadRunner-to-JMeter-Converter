package org.apache.wml;

import org.w3c.dom.Element;

public abstract interface WMLElement
  extends Element
{
  public abstract void setId(String paramString);
  
  public abstract String getId();
  
  public abstract void setClassName(String paramString);
  
  public abstract String getClassName();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */