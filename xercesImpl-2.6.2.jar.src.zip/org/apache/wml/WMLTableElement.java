package org.apache.wml;

public abstract interface WMLTableElement
  extends WMLElement
{
  public abstract void setTitle(String paramString);
  
  public abstract String getTitle();
  
  public abstract void setAlign(String paramString);
  
  public abstract String getAlign();
  
  public abstract void setColumns(int paramInt);
  
  public abstract int getColumns();
  
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\wml\WMLTableElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */