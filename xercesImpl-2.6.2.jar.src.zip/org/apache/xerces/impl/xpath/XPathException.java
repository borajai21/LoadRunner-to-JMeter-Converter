package org.apache.xerces.impl.xpath;

public class XPathException
  extends Exception
{
  private String fKey;
  
  public XPathException()
  {
    this.fKey = "c-general-xpath";
  }
  
  public XPathException(String paramString)
  {
    this.fKey = paramString;
  }
  
  public String getKey()
  {
    return this.fKey;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xpath\XPathException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */