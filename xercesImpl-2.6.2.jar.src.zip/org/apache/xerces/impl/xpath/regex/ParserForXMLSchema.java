package org.apache.xerces.impl.xpath.regex;

import java.util.Hashtable;
import java.util.Locale;

class ParserForXMLSchema
  extends RegexParser
{
  private static Hashtable ranges = null;
  private static Hashtable ranges2 = null;
  private static final String SPACES = "\t\n\r\r  ";
  private static final String NAMECHARS = "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣";
  private static final String LETTERS = "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣";
  private static final String DIGITS = "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩";
  
  public ParserForXMLSchema() {}
  
  public ParserForXMLSchema(Locale paramLocale) {}
  
  Token processCaret()
    throws ParseException
  {
    next();
    return Token.createChar(94);
  }
  
  Token processDollar()
    throws ParseException
  {
    next();
    return Token.createChar(36);
  }
  
  Token processLookahead()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processNegativelookahead()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processLookbehind()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processNegativelookbehind()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_A()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_Z()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_z()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_b()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_B()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_lt()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_gt()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processStar(Token paramToken)
    throws ParseException
  {
    next();
    return Token.createClosure(paramToken);
  }
  
  Token processPlus(Token paramToken)
    throws ParseException
  {
    next();
    return Token.createConcat(paramToken, Token.createClosure(paramToken));
  }
  
  Token processQuestion(Token paramToken)
    throws ParseException
  {
    next();
    Token.UnionToken localUnionToken = Token.createUnion();
    localUnionToken.addChild(paramToken);
    localUnionToken.addChild(Token.createEmpty());
    return localUnionToken;
  }
  
  boolean checkQuestion(int paramInt)
  {
    return false;
  }
  
  Token processParen()
    throws ParseException
  {
    next();
    Token.ParenToken localParenToken = Token.createParen(parseRegex(), 0);
    if (read() != 7) {
      throw ex("parser.factor.1", this.offset - 1);
    }
    next();
    return localParenToken;
  }
  
  Token processParen2()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processCondition()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processModifiers()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processIndependent()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token processBacksolidus_c()
    throws ParseException
  {
    next();
    return getTokenForShorthand(99);
  }
  
  Token processBacksolidus_C()
    throws ParseException
  {
    next();
    return getTokenForShorthand(67);
  }
  
  Token processBacksolidus_i()
    throws ParseException
  {
    next();
    return getTokenForShorthand(105);
  }
  
  Token processBacksolidus_I()
    throws ParseException
  {
    next();
    return getTokenForShorthand(73);
  }
  
  Token processBacksolidus_g()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset - 2);
  }
  
  Token processBacksolidus_X()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset - 2);
  }
  
  Token processBackreference()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset - 4);
  }
  
  int processCIinCharacterClass(RangeToken paramRangeToken, int paramInt)
  {
    paramRangeToken.mergeRanges(getTokenForShorthand(paramInt));
    return -1;
  }
  
  protected RangeToken parseCharacterClass(boolean paramBoolean)
    throws ParseException
  {
    setContext(1);
    next();
    int i = 0;
    RangeToken localRangeToken1 = null;
    RangeToken localRangeToken2;
    if ((read() == 0) && (this.chardata == 94))
    {
      i = 1;
      next();
      localRangeToken1 = Token.createRange();
      localRangeToken1.addRange(0, 1114111);
      localRangeToken2 = Token.createRange();
    }
    else
    {
      localRangeToken2 = Token.createRange();
    }
    int j;
    for (int k = 1; (j = read()) != 1; k = 0)
    {
      if ((j == 0) && (this.chardata == 93) && (k == 0))
      {
        if (i == 0) {
          break;
        }
        localRangeToken1.subtractRanges(localRangeToken2);
        localRangeToken2 = localRangeToken1;
        break;
      }
      int m = this.chardata;
      int n = 0;
      if (j == 10)
      {
        switch (m)
        {
        case 68: 
        case 83: 
        case 87: 
        case 100: 
        case 115: 
        case 119: 
          localRangeToken2.mergeRanges(getTokenForShorthand(m));
          n = 1;
          break;
        case 67: 
        case 73: 
        case 99: 
        case 105: 
          m = processCIinCharacterClass(localRangeToken2, m);
          if (m >= 0) {
            break;
          }
          n = 1;
          break;
        case 80: 
        case 112: 
          int i1 = this.offset;
          RangeToken localRangeToken4 = processBacksolidus_pP(m);
          if (localRangeToken4 == null) {
            throw ex("parser.atom.5", i1);
          }
          localRangeToken2.mergeRanges(localRangeToken4);
          n = 1;
          break;
        default: 
          m = decodeEscaped();
          break;
        }
      }
      else if ((j == 24) && (k == 0))
      {
        if (i != 0)
        {
          localRangeToken1.subtractRanges(localRangeToken2);
          localRangeToken2 = localRangeToken1;
        }
        RangeToken localRangeToken3 = parseCharacterClass(false);
        localRangeToken2.subtractRanges(localRangeToken3);
        if ((read() == 0) && (this.chardata == 93)) {
          break;
        }
        throw ex("parser.cc.5", this.offset);
      }
      next();
      if (n == 0)
      {
        if (j == 0)
        {
          if (m == 91) {
            throw ex("parser.cc.6", this.offset - 2);
          }
          if (m == 93) {
            throw ex("parser.cc.7", this.offset - 2);
          }
          if (m == 45) {
            throw ex("parser.cc.8", this.offset - 2);
          }
        }
        if ((read() != 0) || (this.chardata != 45))
        {
          localRangeToken2.addRange(m, m);
        }
        else
        {
          next();
          if ((j = read()) == 1) {
            throw ex("parser.cc.2", this.offset);
          }
          if (((j == 0) && (this.chardata == 93)) || (j == 24)) {
            throw ex("parser.cc.8", this.offset - 1);
          }
          int i2 = this.chardata;
          if (j == 0)
          {
            if (i2 == 91) {
              throw ex("parser.cc.6", this.offset - 1);
            }
            if (i2 == 93) {
              throw ex("parser.cc.7", this.offset - 1);
            }
            if (i2 == 45) {
              throw ex("parser.cc.8", this.offset - 2);
            }
          }
          else if (j == 10)
          {
            i2 = decodeEscaped();
          }
          next();
          if (m > i2) {
            throw ex("parser.ope.3", this.offset - 1);
          }
          localRangeToken2.addRange(m, i2);
        }
      }
    }
    if (read() == 1) {
      throw ex("parser.cc.2", this.offset);
    }
    localRangeToken2.sortRanges();
    localRangeToken2.compactRanges();
    setContext(0);
    next();
    return localRangeToken2;
  }
  
  protected RangeToken parseSetOperations()
    throws ParseException
  {
    throw ex("parser.process.1", this.offset);
  }
  
  Token getTokenForShorthand(int paramInt)
  {
    switch (paramInt)
    {
    case 100: 
      return getRange("xml:isDigit", true);
    case 68: 
      return getRange("xml:isDigit", false);
    case 119: 
      return getRange("xml:isWord", true);
    case 87: 
      return getRange("xml:isWord", false);
    case 115: 
      return getRange("xml:isSpace", true);
    case 83: 
      return getRange("xml:isSpace", false);
    case 99: 
      return getRange("xml:isNameChar", true);
    case 67: 
      return getRange("xml:isNameChar", false);
    case 105: 
      return getRange("xml:isInitialNameChar", true);
    case 73: 
      return getRange("xml:isInitialNameChar", false);
    }
    throw new RuntimeException("Internal Error: shorthands: \\u" + Integer.toString(paramInt, 16));
  }
  
  int decodeEscaped()
    throws ParseException
  {
    if (read() != 10) {
      throw ex("parser.next.1", this.offset - 1);
    }
    int i = this.chardata;
    switch (i)
    {
    case 110: 
      i = 10;
      break;
    case 114: 
      i = 13;
      break;
    case 116: 
      i = 9;
      break;
    case 40: 
    case 41: 
    case 42: 
    case 43: 
    case 45: 
    case 46: 
    case 63: 
    case 91: 
    case 92: 
    case 93: 
    case 94: 
    case 123: 
    case 124: 
    case 125: 
      break;
    default: 
      throw ex("parser.process.1", this.offset - 2);
    }
    return i;
  }
  
  protected static synchronized RangeToken getRange(String paramString, boolean paramBoolean)
  {
    if (ranges == null)
    {
      ranges = new Hashtable();
      ranges2 = new Hashtable();
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "\t\n\r\r  ");
      ranges.put("xml:isSpace", localRangeToken);
      ranges2.put("xml:isSpace", Token.complementRanges(localRangeToken));
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩");
      ranges.put("xml:isDigit", localRangeToken);
      ranges2.put("xml:isDigit", Token.complementRanges(localRangeToken));
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩");
      ranges.put("xml:isDigit", localRangeToken);
      ranges2.put("xml:isDigit", Token.complementRanges(localRangeToken));
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣");
      localRangeToken.mergeRanges((Token)ranges.get("xml:isDigit"));
      ranges.put("xml:isWord", localRangeToken);
      ranges2.put("xml:isWord", Token.complementRanges(localRangeToken));
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣");
      ranges.put("xml:isNameChar", localRangeToken);
      ranges2.put("xml:isNameChar", Token.complementRanges(localRangeToken));
      localRangeToken = Token.createRange();
      setupRange(localRangeToken, "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣");
      localRangeToken.addRange(95, 95);
      localRangeToken.addRange(58, 58);
      ranges.put("xml:isInitialNameChar", localRangeToken);
      ranges2.put("xml:isInitialNameChar", Token.complementRanges(localRangeToken));
    }
    RangeToken localRangeToken = paramBoolean ? (RangeToken)ranges.get(paramString) : (RangeToken)ranges2.get(paramString);
    return localRangeToken;
  }
  
  static void setupRange(Token paramToken, String paramString)
  {
    int i = paramString.length();
    for (int j = 0; j < i; j += 2) {
      paramToken.addRange(paramString.charAt(j), paramString.charAt(j + 1));
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xpath\regex\ParserForXMLSchema.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */