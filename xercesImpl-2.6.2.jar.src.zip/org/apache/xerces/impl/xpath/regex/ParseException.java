package org.apache.xerces.impl.xpath.regex;

public class ParseException
  extends RuntimeException
{
  int location;
  
  public ParseException(String paramString, int paramInt)
  {
    super(paramString);
    this.location = paramInt;
  }
  
  public int getLocation()
  {
    return this.location;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xpath\regex\ParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */