package org.apache.xerces.impl;

import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XNIException;

public abstract interface XMLEntityHandler
{
  public abstract void startEntity(String paramString1, XMLResourceIdentifier paramXMLResourceIdentifier, String paramString2)
    throws XNIException;
  
  public abstract void endEntity(String paramString)
    throws XNIException;
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\XMLEntityHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */