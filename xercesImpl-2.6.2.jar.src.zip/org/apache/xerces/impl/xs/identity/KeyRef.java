package org.apache.xerces.impl.xs.identity;

import org.apache.xerces.xs.XSIDCDefinition;

public class KeyRef
  extends IdentityConstraint
{
  protected UniqueOrKey fKey;
  
  public KeyRef(String paramString1, String paramString2, String paramString3, UniqueOrKey paramUniqueOrKey)
  {
    super(paramString1, paramString2, paramString3);
    this.fKey = paramUniqueOrKey;
    this.type = 2;
  }
  
  public UniqueOrKey getKey()
  {
    return this.fKey;
  }
  
  public XSIDCDefinition getRefKey()
  {
    return this.fKey;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\identity\KeyRef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */