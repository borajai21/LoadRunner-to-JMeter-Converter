package org.apache.xerces.impl.xs.identity;

public abstract interface ValueStore
{
  public abstract void addValue(Field paramField, Object paramObject);
  
  public abstract void reportError(String paramString, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\identity\ValueStore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */