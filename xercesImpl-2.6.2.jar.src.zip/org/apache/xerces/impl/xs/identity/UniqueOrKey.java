package org.apache.xerces.impl.xs.identity;

public class UniqueOrKey
  extends IdentityConstraint
{
  public UniqueOrKey(String paramString1, String paramString2, String paramString3, short paramShort)
  {
    super(paramString1, paramString2, paramString3);
    this.type = paramShort;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\identity\UniqueOrKey.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */