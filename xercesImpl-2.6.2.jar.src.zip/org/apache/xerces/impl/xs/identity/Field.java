package org.apache.xerces.impl.xs.identity;

import org.apache.xerces.impl.xpath.XPath;
import org.apache.xerces.impl.xpath.XPath.Axis;
import org.apache.xerces.impl.xpath.XPath.LocationPath;
import org.apache.xerces.impl.xpath.XPath.Step;
import org.apache.xerces.impl.xpath.XPathException;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xs.XSComplexTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;

public class Field
{
  protected XPath fXPath;
  protected IdentityConstraint fIdentityConstraint;
  protected boolean mayMatch = true;
  
  public Field(XPath paramXPath, IdentityConstraint paramIdentityConstraint)
  {
    this.fXPath = paramXPath;
    this.fIdentityConstraint = paramIdentityConstraint;
  }
  
  public void setMayMatch(boolean paramBoolean)
  {
    this.mayMatch = paramBoolean;
  }
  
  public boolean mayMatch()
  {
    return this.mayMatch;
  }
  
  public XPath getXPath()
  {
    return this.fXPath;
  }
  
  public IdentityConstraint getIdentityConstraint()
  {
    return this.fIdentityConstraint;
  }
  
  public XPathMatcher createMatcher(ValueStore paramValueStore)
  {
    return new Matcher(this.fXPath, paramValueStore);
  }
  
  public String toString()
  {
    return this.fXPath.toString();
  }
  
  protected class Matcher
    extends XPathMatcher
  {
    protected ValueStore fStore;
    
    public Matcher(Field.XPath paramXPath, ValueStore paramValueStore)
    {
      super();
      this.fStore = paramValueStore;
    }
    
    protected void matched(Object paramObject, boolean paramBoolean)
    {
      super.matched(paramObject, paramBoolean);
      if ((paramBoolean) && (Field.this.fIdentityConstraint.getCategory() == 1))
      {
        String str = "KeyMatchesNillable";
        this.fStore.reportError(str, new Object[] { Field.this.fIdentityConstraint.getElementName() });
      }
      this.fStore.addValue(Field.this, paramObject);
      Field.this.mayMatch = false;
    }
    
    protected void handleContent(XSTypeDefinition paramXSTypeDefinition, boolean paramBoolean, Object paramObject)
    {
      if ((paramXSTypeDefinition == null) || ((paramXSTypeDefinition.getTypeCategory() == 15) && (((XSComplexTypeDefinition)paramXSTypeDefinition).getContentType() != 1))) {
        this.fStore.reportError("cvc-id.3", new Object[] { Field.this.fIdentityConstraint.getName(), Field.this.fIdentityConstraint.getElementName() });
      }
      this.fMatchedString = paramObject;
      matched(this.fMatchedString, paramBoolean);
    }
  }
  
  public static class XPath
    extends XPath
  {
    public XPath(String paramString, SymbolTable paramSymbolTable, NamespaceContext paramNamespaceContext)
      throws XPathException
    {
      super(paramSymbolTable, paramNamespaceContext);
      for (int i = 0; i < this.fLocationPaths.length; i++) {
        for (int j = 0; j < this.fLocationPaths[i].steps.length; j++)
        {
          XPath.Axis localAxis = this.fLocationPaths[i].steps[j].axis;
          if ((localAxis.type == 2) && (j < this.fLocationPaths[i].steps.length - 1)) {
            throw new XPathException("c-fields-xpaths");
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\identity\Field.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */