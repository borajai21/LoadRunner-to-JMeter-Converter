package org.apache.xerces.impl.xs.identity;

public abstract interface FieldActivator
{
  public abstract void startValueScopeFor(IdentityConstraint paramIdentityConstraint, int paramInt);
  
  public abstract XPathMatcher activateField(Field paramField, int paramInt);
  
  public abstract void endValueScopeFor(IdentityConstraint paramIdentityConstraint, int paramInt);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\identity\FieldActivator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */