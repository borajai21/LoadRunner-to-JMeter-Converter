package org.apache.xerces.impl.xs.opti;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLString;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class SchemaDOM
  extends DefaultDocument
{
  static final int relationsRowResizeFactor = 15;
  static final int relationsColResizeFactor = 10;
  NodeImpl[][] relations;
  ElementImpl parent;
  int currLoc;
  int nextFreeLoc;
  boolean hidden;
  StringBuffer fAnnotationBuffer = null;
  
  public SchemaDOM()
  {
    reset();
  }
  
  public void startElement(QName paramQName, XMLAttributes paramXMLAttributes, int paramInt1, int paramInt2)
  {
    ElementImpl localElementImpl = new ElementImpl(paramInt1, paramInt2);
    processElement(paramQName, paramXMLAttributes, localElementImpl);
    this.parent = localElementImpl;
  }
  
  public void emptyElement(QName paramQName, XMLAttributes paramXMLAttributes, int paramInt1, int paramInt2)
  {
    ElementImpl localElementImpl = new ElementImpl(paramInt1, paramInt2);
    processElement(paramQName, paramXMLAttributes, localElementImpl);
  }
  
  private void processElement(QName paramQName, XMLAttributes paramXMLAttributes, ElementImpl paramElementImpl)
  {
    paramElementImpl.prefix = paramQName.prefix;
    paramElementImpl.localpart = paramQName.localpart;
    paramElementImpl.rawname = paramQName.rawname;
    paramElementImpl.uri = paramQName.uri;
    paramElementImpl.schemaDOM = this;
    Attr[] arrayOfAttr = new Attr[paramXMLAttributes.getLength()];
    for (int i = 0; i < paramXMLAttributes.getLength(); i++) {
      arrayOfAttr[i] = new AttrImpl(null, paramXMLAttributes.getPrefix(i), paramXMLAttributes.getLocalName(i), paramXMLAttributes.getQName(i), paramXMLAttributes.getURI(i), paramXMLAttributes.getValue(i));
    }
    paramElementImpl.attrs = arrayOfAttr;
    if (this.nextFreeLoc == this.relations.length) {
      resizeRelations();
    }
    if (this.relations[this.currLoc][0] != this.parent)
    {
      this.relations[this.nextFreeLoc][0] = this.parent;
      this.currLoc = (this.nextFreeLoc++);
    }
    int j = 0;
    int k = 1;
    for (k = 1; k < this.relations[this.currLoc].length; k++) {
      if (this.relations[this.currLoc][k] == null)
      {
        j = 1;
        break;
      }
    }
    if (j == 0) {
      resizeRelations(this.currLoc);
    }
    this.relations[this.currLoc][k] = paramElementImpl;
    this.parent.parentRow = this.currLoc;
    paramElementImpl.row = this.currLoc;
    paramElementImpl.col = k;
  }
  
  public void endElement()
  {
    this.currLoc = this.parent.row;
    this.parent = ((ElementImpl)this.relations[this.currLoc][0]);
  }
  
  void comment(XMLString paramXMLString)
  {
    this.fAnnotationBuffer.append("<!--").append(paramXMLString.toString()).append("-->");
  }
  
  void processingInstruction(String paramString1, String paramString2)
  {
    this.fAnnotationBuffer.append("<?").append(paramString1).append(" ").append(paramString2).append("?>");
  }
  
  void characters(XMLString paramXMLString)
  {
    for (int i = paramXMLString.offset; i < paramXMLString.offset + paramXMLString.length; i++) {
      if (paramXMLString.ch[i] == '&') {
        this.fAnnotationBuffer.append("&amp;");
      } else if (paramXMLString.ch[i] == '<') {
        this.fAnnotationBuffer.append("&lt;");
      } else {
        this.fAnnotationBuffer.append(paramXMLString.ch[i]);
      }
    }
  }
  
  void endAnnotationElement(QName paramQName, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.fAnnotationBuffer.append("\n</").append(paramQName.rawname).append(">");
      ElementImpl localElementImpl = (ElementImpl)this.relations[this.currLoc][1];
      if (this.nextFreeLoc == this.relations.length) {
        resizeRelations();
      }
      int i = localElementImpl.parentRow = this.nextFreeLoc++;
      int j = 0;
      for (int k = 1; k < this.relations[i].length; k++) {
        if (this.relations[i][k] == null)
        {
          j = 1;
          break;
        }
      }
      if (j == 0) {
        resizeRelations(i);
      }
      this.relations[i][k] = new TextImpl(this.fAnnotationBuffer, this, i, k);
      this.fAnnotationBuffer = null;
    }
    else
    {
      this.fAnnotationBuffer.append("</").append(paramQName.rawname).append(">");
    }
  }
  
  void startAnnotationCDATA()
  {
    this.fAnnotationBuffer.append("<![CDATA[");
  }
  
  void endAnnotationCDATA()
  {
    this.fAnnotationBuffer.append("]]>");
  }
  
  private void resizeRelations()
  {
    NodeImpl[][] arrayOfNodeImpl = new NodeImpl[this.relations.length + 15][];
    System.arraycopy(this.relations, 0, arrayOfNodeImpl, 0, this.relations.length);
    for (int i = this.relations.length; i < arrayOfNodeImpl.length; i++) {
      arrayOfNodeImpl[i] = new NodeImpl[10];
    }
    this.relations = arrayOfNodeImpl;
  }
  
  private void resizeRelations(int paramInt)
  {
    NodeImpl[] arrayOfNodeImpl = new NodeImpl[this.relations[paramInt].length + 10];
    System.arraycopy(this.relations[paramInt], 0, arrayOfNodeImpl, 0, this.relations[paramInt].length);
    this.relations[paramInt] = arrayOfNodeImpl;
  }
  
  public void reset()
  {
    if (this.relations != null) {
      for (int i = 0; i < this.relations.length; i++) {
        for (int j = 0; j < this.relations[i].length; j++) {
          this.relations[i][j] = null;
        }
      }
    }
    this.relations = new NodeImpl[15][];
    this.parent = new ElementImpl(0, 0);
    this.parent.rawname = "DOCUMENT_NODE";
    this.currLoc = 0;
    this.nextFreeLoc = 1;
    for (int k = 0; k < 15; k++) {
      this.relations[k] = new NodeImpl[10];
    }
    this.relations[this.currLoc][0] = this.parent;
  }
  
  public void printDOM() {}
  
  public static void traverse(Node paramNode, int paramInt)
  {
    indent(paramInt);
    System.out.print("<" + paramNode.getNodeName());
    Object localObject;
    if (paramNode.hasAttributes())
    {
      localObject = paramNode.getAttributes();
      for (int i = 0; i < ((NamedNodeMap)localObject).getLength(); i++) {
        System.out.print("  " + ((Attr)((NamedNodeMap)localObject).item(i)).getName() + "=\"" + ((Attr)((NamedNodeMap)localObject).item(i)).getValue() + "\"");
      }
    }
    if (paramNode.hasChildNodes())
    {
      System.out.println(">");
      paramInt += 4;
      for (localObject = paramNode.getFirstChild(); localObject != null; localObject = ((Node)localObject).getNextSibling()) {
        traverse((Node)localObject, paramInt);
      }
      paramInt -= 4;
      indent(paramInt);
      System.out.println("</" + paramNode.getNodeName() + ">");
    }
    else
    {
      System.out.println("/>");
    }
  }
  
  public static void indent(int paramInt)
  {
    for (int i = 0; i < paramInt; i++) {
      System.out.print(' ');
    }
  }
  
  public Element getDocumentElement()
  {
    return (ElementImpl)this.relations[0][1];
  }
  
  void startAnnotation(QName paramQName, XMLAttributes paramXMLAttributes, NamespaceContext paramNamespaceContext)
  {
    if (this.fAnnotationBuffer == null) {
      this.fAnnotationBuffer = new StringBuffer(256);
    }
    this.fAnnotationBuffer.append("<").append(paramQName.rawname).append(" ");
    Vector localVector = new Vector();
    String str1;
    for (int i = 0; i < paramXMLAttributes.getLength(); i++)
    {
      localObject = paramXMLAttributes.getValue(i);
      str1 = paramXMLAttributes.getPrefix(i);
      localVector.addElement(localObject);
      this.fAnnotationBuffer.append(paramXMLAttributes.getQName(i)).append("=\"").append((String)localObject).append("\" ");
    }
    Object localObject = paramNamespaceContext.getAllPrefixes();
    while (((Enumeration)localObject).hasMoreElements())
    {
      str1 = (String)((Enumeration)localObject).nextElement();
      String str2 = paramNamespaceContext.getURI(str1);
      if (!localVector.contains(str2)) {
        if (str1 == XMLSymbols.EMPTY_STRING) {
          this.fAnnotationBuffer.append("xmlns").append("=\"").append(str2).append("\" ");
        } else {
          this.fAnnotationBuffer.append("xmlns:").append(str1).append("=\"").append(str2).append("\" ");
        }
      }
    }
    this.fAnnotationBuffer.append(">\n");
  }
  
  void startAnnotationElement(QName paramQName, XMLAttributes paramXMLAttributes)
  {
    this.fAnnotationBuffer.append("<").append(paramQName.rawname).append(" ");
    for (int i = 0; i < paramXMLAttributes.getLength(); i++)
    {
      String str = paramXMLAttributes.getValue(i);
      this.fAnnotationBuffer.append(" ").append(paramXMLAttributes.getQName(i)).append("=\"").append(processAttValue(str)).append("\" ");
    }
    this.fAnnotationBuffer.append(">");
  }
  
  private static String processAttValue(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramString.length());
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if (c == '"') {
        localStringBuffer.append("&quot;");
      } else if (c == '>') {
        localStringBuffer.append("&gt;");
      } else if (c == '&') {
        localStringBuffer.append("&amp;");
      } else {
        localStringBuffer.append(c);
      }
    }
    return localStringBuffer.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\opti\SchemaDOM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */