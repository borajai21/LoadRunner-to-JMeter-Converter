package org.apache.xerces.impl.xs.opti;

import org.apache.xerces.dom3.TypeInfo;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;

public class AttrImpl
  extends NodeImpl
  implements Attr
{
  Element element;
  String value;
  
  public AttrImpl()
  {
    this.nodeType = 2;
  }
  
  public AttrImpl(Element paramElement, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    super(paramString1, paramString2, paramString3, paramString4, (short)2);
    this.element = paramElement;
    this.value = paramString5;
  }
  
  public String getName()
  {
    return this.rawname;
  }
  
  public boolean getSpecified()
  {
    return true;
  }
  
  public String getValue()
  {
    return this.value;
  }
  
  public Element getOwnerElement()
  {
    return this.element;
  }
  
  public void setValue(String paramString)
    throws DOMException
  {
    this.value = paramString;
  }
  
  public boolean isId()
  {
    return false;
  }
  
  public TypeInfo getSchemaTypeInfo()
  {
    return null;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\opti\AttrImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */