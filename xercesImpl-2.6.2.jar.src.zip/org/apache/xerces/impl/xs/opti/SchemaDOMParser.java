package org.apache.xerces.impl.xs.opti;

import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.xs.SchemaSymbols;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.Document;

public class SchemaDOMParser
  extends DefaultXMLDocumentHandler
{
  public static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
  protected XMLLocator fLocator;
  protected NamespaceContext fNamespaceContext = null;
  SchemaDOM schemaDOM;
  XMLParserConfiguration config;
  private int fAnnotationDepth = -1;
  private int fInnerAnnotationDepth = -1;
  private int fDepth = -1;
  XMLErrorReporter fErrorReporter;
  
  public SchemaDOMParser(XMLParserConfiguration paramXMLParserConfiguration)
  {
    this.config = paramXMLParserConfiguration;
  }
  
  public void startDocument(XMLLocator paramXMLLocator, String paramString, NamespaceContext paramNamespaceContext, Augmentations paramAugmentations)
    throws XNIException
  {
    this.fErrorReporter = ((XMLErrorReporter)this.config.getProperty("http://apache.org/xml/properties/internal/error-reporter"));
    this.schemaDOM = new SchemaDOM();
    this.fAnnotationDepth = -1;
    this.fInnerAnnotationDepth = -1;
    this.fDepth = -1;
    this.fLocator = paramXMLLocator;
    this.fNamespaceContext = paramNamespaceContext;
  }
  
  public void endDocument(Augmentations paramAugmentations)
    throws XNIException
  {}
  
  public void comment(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fAnnotationDepth > -1) {
      this.schemaDOM.comment(paramXMLString);
    }
  }
  
  public void processingInstruction(String paramString, XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fAnnotationDepth > -1) {
      this.schemaDOM.processingInstruction(paramString, paramXMLString.toString());
    }
  }
  
  public void characters(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fInnerAnnotationDepth == -1) {
      for (int i = paramXMLString.offset; i < paramXMLString.offset + paramXMLString.length; i++) {
        if (!XMLChar.isSpace(paramXMLString.ch[i]))
        {
          String str = new String(paramXMLString.ch, i, paramXMLString.length + paramXMLString.offset - i);
          this.fErrorReporter.reportError("http://www.w3.org/TR/xml-schema-1", "s4s-elt-character", new Object[] { str }, (short)1);
          break;
        }
      }
    } else {
      this.schemaDOM.characters(paramXMLString);
    }
  }
  
  public void startElement(QName paramQName, XMLAttributes paramXMLAttributes, Augmentations paramAugmentations)
    throws XNIException
  {
    this.fDepth += 1;
    if (this.fAnnotationDepth == -1)
    {
      if ((paramQName.uri == SchemaSymbols.URI_SCHEMAFORSCHEMA) && (paramQName.localpart == SchemaSymbols.ELT_ANNOTATION))
      {
        this.fAnnotationDepth = this.fDepth;
        this.schemaDOM.startAnnotation(paramQName, paramXMLAttributes, this.fNamespaceContext);
      }
    }
    else if (this.fDepth == this.fAnnotationDepth + 1)
    {
      this.fInnerAnnotationDepth = this.fDepth;
      this.schemaDOM.startAnnotationElement(paramQName, paramXMLAttributes);
    }
    else
    {
      this.schemaDOM.startAnnotationElement(paramQName, paramXMLAttributes);
      return;
    }
    this.schemaDOM.startElement(paramQName, paramXMLAttributes, this.fLocator.getLineNumber(), this.fLocator.getColumnNumber());
  }
  
  public void emptyElement(QName paramQName, XMLAttributes paramXMLAttributes, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fAnnotationDepth == -1)
    {
      if ((paramQName.uri == SchemaSymbols.URI_SCHEMAFORSCHEMA) && (paramQName.localpart == SchemaSymbols.ELT_ANNOTATION)) {
        this.schemaDOM.startAnnotation(paramQName, paramXMLAttributes, this.fNamespaceContext);
      }
    }
    else {
      this.schemaDOM.startAnnotationElement(paramQName, paramXMLAttributes);
    }
    this.schemaDOM.emptyElement(paramQName, paramXMLAttributes, this.fLocator.getLineNumber(), this.fLocator.getColumnNumber());
    if (this.fAnnotationDepth == -1)
    {
      if ((paramQName.uri == SchemaSymbols.URI_SCHEMAFORSCHEMA) && (paramQName.localpart == SchemaSymbols.ELT_ANNOTATION)) {
        this.schemaDOM.endAnnotationElement(paramQName, true);
      }
    }
    else {
      this.schemaDOM.endAnnotationElement(paramQName, false);
    }
  }
  
  public void endElement(QName paramQName, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fAnnotationDepth > -1)
    {
      if (this.fInnerAnnotationDepth == this.fDepth)
      {
        this.fInnerAnnotationDepth = -1;
        this.schemaDOM.endAnnotationElement(paramQName, false);
        this.schemaDOM.endElement();
      }
      else if (this.fAnnotationDepth == this.fDepth)
      {
        this.fAnnotationDepth = -1;
        this.schemaDOM.endAnnotationElement(paramQName, true);
        this.schemaDOM.endElement();
      }
      else
      {
        this.schemaDOM.endAnnotationElement(paramQName, false);
      }
    }
    else {
      this.schemaDOM.endElement();
    }
    this.fDepth -= 1;
  }
  
  public void ignorableWhitespace(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    if (this.fAnnotationDepth != -1) {
      this.schemaDOM.characters(paramXMLString);
    }
  }
  
  public void startCDATA(Augmentations paramAugmentations)
    throws XNIException
  {
    this.schemaDOM.startAnnotationCDATA();
  }
  
  public void endCDATA(Augmentations paramAugmentations)
    throws XNIException
  {
    this.schemaDOM.endAnnotationCDATA();
  }
  
  public Document getDocument()
  {
    return this.schemaDOM;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\opti\SchemaDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */