package org.apache.xerces.impl.xs.traversers;

abstract class Container
{
  static final int THRESHOLD = 5;
  OneAttr[] values;
  int pos = 0;
  
  static Container getContainer(int paramInt)
  {
    if (paramInt > 5) {
      return new LargeContainer(paramInt);
    }
    return new SmallContainer(paramInt);
  }
  
  abstract void put(String paramString, OneAttr paramOneAttr);
  
  abstract OneAttr get(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\traversers\Container.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */