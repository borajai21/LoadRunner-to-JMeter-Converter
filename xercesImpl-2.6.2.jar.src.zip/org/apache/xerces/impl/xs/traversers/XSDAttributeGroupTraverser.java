package org.apache.xerces.impl.xs.traversers;

import org.apache.xerces.impl.xs.SchemaGrammar;
import org.apache.xerces.impl.xs.SchemaSymbols;
import org.apache.xerces.impl.xs.XSAnnotationImpl;
import org.apache.xerces.impl.xs.XSAttributeGroupDecl;
import org.apache.xerces.util.DOMUtil;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.QName;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

class XSDAttributeGroupTraverser
  extends XSDAbstractTraverser
{
  XSDAttributeGroupTraverser(XSDHandler paramXSDHandler, XSAttributeChecker paramXSAttributeChecker)
  {
    super(paramXSDHandler, paramXSAttributeChecker);
  }
  
  XSAttributeGroupDecl traverseLocal(Element paramElement, XSDocumentInfo paramXSDocumentInfo, SchemaGrammar paramSchemaGrammar)
  {
    Object[] arrayOfObject1 = this.fAttrChecker.checkAttributes(paramElement, false, paramXSDocumentInfo);
    QName localQName = (QName)arrayOfObject1[XSAttributeChecker.ATTIDX_REF];
    XSAttributeGroupDecl localXSAttributeGroupDecl = null;
    if (localQName == null)
    {
      reportSchemaError("s4s-att-must-appear", new Object[] { "attributeGroup (local)", "ref" }, paramElement);
      this.fAttrChecker.returnAttrArray(arrayOfObject1, paramXSDocumentInfo);
      return null;
    }
    localXSAttributeGroupDecl = (XSAttributeGroupDecl)this.fSchemaHandler.getGlobalDecl(paramXSDocumentInfo, 2, localQName, paramElement);
    Element localElement = DOMUtil.getFirstChildElement(paramElement);
    if (localElement != null)
    {
      String str = DOMUtil.getLocalName(localElement);
      if (str.equals(SchemaSymbols.ELT_ANNOTATION))
      {
        traverseAnnotationDecl(localElement, arrayOfObject1, false, paramXSDocumentInfo);
        localElement = DOMUtil.getNextSiblingElement(localElement);
      }
      if (localElement != null)
      {
        Object[] arrayOfObject2 = { localQName.rawname, "(annotation?)", DOMUtil.getLocalName(localElement) };
        reportSchemaError("s4s-elt-must-match.1", arrayOfObject2, localElement);
      }
    }
    this.fAttrChecker.returnAttrArray(arrayOfObject1, paramXSDocumentInfo);
    return localXSAttributeGroupDecl;
  }
  
  XSAttributeGroupDecl traverseGlobal(Element paramElement, XSDocumentInfo paramXSDocumentInfo, SchemaGrammar paramSchemaGrammar)
  {
    XSAttributeGroupDecl localXSAttributeGroupDecl = new XSAttributeGroupDecl();
    Object[] arrayOfObject1 = this.fAttrChecker.checkAttributes(paramElement, true, paramXSDocumentInfo);
    String str = (String)arrayOfObject1[XSAttributeChecker.ATTIDX_NAME];
    if (str == null)
    {
      reportSchemaError("s4s-att-must-appear", new Object[] { "attributeGroup (global)", "name" }, paramElement);
      str = "no name";
    }
    localXSAttributeGroupDecl.fName = str;
    localXSAttributeGroupDecl.fTargetNamespace = paramXSDocumentInfo.fTargetNamespace;
    Element localElement = DOMUtil.getFirstChildElement(paramElement);
    XSAnnotationImpl localXSAnnotationImpl = null;
    if (localElement != null)
    {
      localObject1 = DOMUtil.getLocalName(localElement);
      if (((String)localObject1).equals(SchemaSymbols.ELT_ANNOTATION))
      {
        localXSAnnotationImpl = traverseAnnotationDecl(localElement, arrayOfObject1, false, paramXSDocumentInfo);
        localElement = DOMUtil.getNextSiblingElement(localElement);
      }
    }
    Object localObject1 = traverseAttrsAndAttrGrps(localElement, localXSAttributeGroupDecl, paramXSDocumentInfo, paramSchemaGrammar, null);
    if (localObject1 != null)
    {
      localObject2 = new Object[] { str, "(annotation?, ((attribute | attributeGroup)*, anyAttribute?))", DOMUtil.getLocalName((Node)localObject1) };
      reportSchemaError("s4s-elt-must-match.1", (Object[])localObject2, (Element)localObject1);
    }
    localXSAttributeGroupDecl.removeProhibitedAttrs();
    Object localObject2 = (XSAttributeGroupDecl)this.fSchemaHandler.getGrpOrAttrGrpRedefinedByRestriction(2, new QName(XMLSymbols.EMPTY_STRING, str, str, paramXSDocumentInfo.fTargetNamespace), paramXSDocumentInfo, paramElement);
    if (localObject2 != null)
    {
      Object[] arrayOfObject2 = localXSAttributeGroupDecl.validRestrictionOf(str, (XSAttributeGroupDecl)localObject2);
      if (arrayOfObject2 != null)
      {
        reportSchemaError((String)arrayOfObject2[(arrayOfObject2.length - 1)], arrayOfObject2, localElement);
        reportSchemaError("src-redefine.7.2.2", new Object[] { str, arrayOfObject2[(arrayOfObject2.length - 1)] }, localElement);
      }
    }
    localXSAttributeGroupDecl.fAnnotation = localXSAnnotationImpl;
    paramSchemaGrammar.addGlobalAttributeGroupDecl(localXSAttributeGroupDecl);
    this.fAttrChecker.returnAttrArray(arrayOfObject1, paramXSDocumentInfo);
    return localXSAttributeGroupDecl;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\traversers\XSDAttributeGroupTraverser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */