package org.apache.xerces.impl.xs.traversers;

class SmallContainer
  extends Container
{
  String[] keys;
  
  SmallContainer(int paramInt)
  {
    this.keys = new String[paramInt];
    this.values = new OneAttr[paramInt];
  }
  
  void put(String paramString, OneAttr paramOneAttr)
  {
    this.keys[this.pos] = paramString;
    this.values[(this.pos++)] = paramOneAttr;
  }
  
  OneAttr get(String paramString)
  {
    for (int i = 0; i < this.pos; i++) {
      if (this.keys[i].equals(paramString)) {
        return this.values[i];
      }
    }
    return null;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\traversers\SmallContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */