package org.apache.xerces.impl.xs.traversers;

class OneAttr
{
  public String name;
  public int dvIndex;
  public int valueIndex;
  public Object dfltValue;
  
  public OneAttr(String paramString, int paramInt1, int paramInt2, Object paramObject)
  {
    this.name = paramString;
    this.dvIndex = paramInt1;
    this.valueIndex = paramInt2;
    this.dfltValue = paramObject;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\traversers\OneAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */