package org.apache.xerces.impl.xs.util;

import org.apache.xerces.xs.ShortList;
import org.apache.xerces.xs.XSException;

public class ShortListImpl
  implements ShortList
{
  private short[] fArray = null;
  private int fLength = 0;
  
  public ShortListImpl(short[] paramArrayOfShort, int paramInt)
  {
    this.fArray = paramArrayOfShort;
    this.fLength = paramInt;
  }
  
  public int getLength()
  {
    return this.fLength;
  }
  
  public boolean contains(short paramShort)
  {
    for (int i = 0; i < this.fLength; i++) {
      if (this.fArray[i] == paramShort) {
        return true;
      }
    }
    return false;
  }
  
  public short item(int paramInt)
    throws XSException
  {
    if ((paramInt < 0) || (paramInt >= this.fLength)) {
      throw new XSException((short)2, null);
    }
    return this.fArray[paramInt];
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\util\ShortListImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */