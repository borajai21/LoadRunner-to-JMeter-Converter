package org.apache.xerces.impl.xs.util;

public final class XIntPool
{
  private static final short POOL_SIZE = 10;
  private static final XInt[] fXIntPool = new XInt[10];
  
  public final XInt getXInt(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < fXIntPool.length)) {
      return fXIntPool[paramInt];
    }
    return new XInt(paramInt);
  }
  
  static
  {
    for (int i = 0; i < 10; i++) {
      fXIntPool[i] = new XInt(i);
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\util\XIntPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */