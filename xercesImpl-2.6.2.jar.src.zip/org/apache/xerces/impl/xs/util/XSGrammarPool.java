package org.apache.xerces.impl.xs.util;

import java.util.Vector;
import org.apache.xerces.impl.xs.SchemaGrammar;
import org.apache.xerces.impl.xs.XSModelImpl;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.util.XMLGrammarPoolImpl.Entry;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xs.XSModel;

public class XSGrammarPool
  extends XMLGrammarPoolImpl
{
  public XSModel toXSModel()
  {
    Vector localVector = new Vector();
    for (int i = 0; i < this.fGrammars.length; i++) {
      for (XMLGrammarPoolImpl.Entry localEntry = this.fGrammars[i]; localEntry != null; localEntry = localEntry.next) {
        if (localEntry.desc.getGrammarType().equals("http://www.w3.org/2001/XMLSchema")) {
          localVector.addElement(localEntry.grammar);
        }
      }
    }
    int j = localVector.size();
    if (j == 0) {
      return null;
    }
    SchemaGrammar[] arrayOfSchemaGrammar = new SchemaGrammar[j];
    for (int k = 0; k < j; k++) {
      arrayOfSchemaGrammar[k] = ((SchemaGrammar)localVector.elementAt(k));
    }
    return new XSModelImpl(arrayOfSchemaGrammar);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\util\XSGrammarPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */