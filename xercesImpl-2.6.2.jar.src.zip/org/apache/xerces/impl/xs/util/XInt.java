package org.apache.xerces.impl.xs.util;

public final class XInt
{
  private int fValue;
  
  XInt(int paramInt)
  {
    this.fValue = paramInt;
  }
  
  public final int intValue()
  {
    return this.fValue;
  }
  
  public final short shortValue()
  {
    return (short)this.fValue;
  }
  
  public final boolean equals(XInt paramXInt)
  {
    return this.fValue == paramXInt.fValue;
  }
  
  public String toString()
  {
    return Integer.toString(this.fValue);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\util\XInt.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */