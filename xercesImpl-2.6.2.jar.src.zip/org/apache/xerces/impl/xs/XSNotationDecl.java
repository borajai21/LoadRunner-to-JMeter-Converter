package org.apache.xerces.impl.xs;

import org.apache.xerces.xs.XSAnnotation;
import org.apache.xerces.xs.XSNamespaceItem;
import org.apache.xerces.xs.XSNotationDeclaration;

public class XSNotationDecl
  implements XSNotationDeclaration
{
  public String fName = null;
  public String fTargetNamespace = null;
  public String fPublicId = null;
  public String fSystemId = null;
  public XSAnnotationImpl fAnnotation = null;
  
  public short getType()
  {
    return 11;
  }
  
  public String getName()
  {
    return this.fName;
  }
  
  public String getNamespace()
  {
    return this.fTargetNamespace;
  }
  
  public String getSystemId()
  {
    return this.fSystemId;
  }
  
  public String getPublicId()
  {
    return this.fPublicId;
  }
  
  public XSAnnotation getAnnotation()
  {
    return this.fAnnotation;
  }
  
  public XSNamespaceItem getNamespaceItem()
  {
    return null;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\XSNotationDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */