package org.apache.xerces.impl.xs.models;

import java.util.Vector;
import org.apache.xerces.impl.xs.SubstitutionGroupHandler;
import org.apache.xerces.impl.xs.XMLSchemaException;
import org.apache.xerces.xni.QName;

public abstract interface XSCMValidator
{
  public static final short FIRST_ERROR = -1;
  public static final short SUBSEQUENT_ERROR = -2;
  
  public abstract int[] startContentModel();
  
  public abstract Object oneTransition(QName paramQName, int[] paramArrayOfInt, SubstitutionGroupHandler paramSubstitutionGroupHandler);
  
  public abstract boolean endContentModel(int[] paramArrayOfInt);
  
  public abstract boolean checkUniqueParticleAttribution(SubstitutionGroupHandler paramSubstitutionGroupHandler)
    throws XMLSchemaException;
  
  public abstract Vector whatCanGoHere(int[] paramArrayOfInt);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\xs\models\XSCMValidator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */