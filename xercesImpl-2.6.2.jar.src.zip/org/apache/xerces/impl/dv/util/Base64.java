package org.apache.xerces.impl.dv.util;

public final class Base64
{
  private static final int BASELENGTH = 255;
  private static final int LOOKUPLENGTH = 64;
  private static final int TWENTYFOURBITGROUP = 24;
  private static final int EIGHTBIT = 8;
  private static final int SIXTEENBIT = 16;
  private static final int SIXBIT = 6;
  private static final int FOURBYTE = 4;
  private static final int SIGN = -128;
  private static final char PAD = '=';
  private static final boolean fDebug = false;
  private static final byte[] base64Alphabet = new byte['ÿ'];
  private static final char[] lookUpBase64Alphabet = new char[64];
  
  protected static boolean isWhiteSpace(char paramChar)
  {
    return (paramChar == ' ') || (paramChar == '\r') || (paramChar == '\n') || (paramChar == '\t');
  }
  
  protected static boolean isPad(char paramChar)
  {
    return paramChar == '=';
  }
  
  protected static boolean isData(char paramChar)
  {
    return base64Alphabet[paramChar] != -1;
  }
  
  protected static boolean isBase64(char paramChar)
  {
    return (isWhiteSpace(paramChar)) || (isPad(paramChar)) || (isData(paramChar));
  }
  
  public static String encode(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return null;
    }
    int i = paramArrayOfByte.length * 8;
    if (i == 0) {
      return "";
    }
    int j = i % 24;
    int k = i / 24;
    int m = j != 0 ? k + 1 : k;
    int n = (m - 1) / 19 + 1;
    char[] arrayOfChar = null;
    arrayOfChar = new char[m * 4 + n];
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    int i7 = 0;
    int i8 = 0;
    int i10;
    int i11;
    int i12;
    for (int i9 = 0; i9 < n - 1; i9++)
    {
      for (i10 = 0; i10 < 19; i10++)
      {
        i3 = paramArrayOfByte[(i7++)];
        i4 = paramArrayOfByte[(i7++)];
        i5 = paramArrayOfByte[(i7++)];
        i2 = (byte)(i4 & 0xF);
        i1 = (byte)(i3 & 0x3);
        i11 = (i3 & 0xFFFFFF80) == 0 ? (byte)(i3 >> 2) : (byte)(i3 >> 2 ^ 0xC0);
        i12 = (i4 & 0xFFFFFF80) == 0 ? (byte)(i4 >> 4) : (byte)(i4 >> 4 ^ 0xF0);
        int i13 = (i5 & 0xFFFFFF80) == 0 ? (byte)(i5 >> 6) : (byte)(i5 >> 6 ^ 0xFC);
        arrayOfChar[(i6++)] = lookUpBase64Alphabet[i11];
        arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i12 | i1 << 4)];
        arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i2 << 2 | i13)];
        arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i5 & 0x3F)];
        i8++;
      }
      arrayOfChar[(i6++)] = '\n';
    }
    while (i8 < k)
    {
      i3 = paramArrayOfByte[(i7++)];
      i4 = paramArrayOfByte[(i7++)];
      i5 = paramArrayOfByte[(i7++)];
      i2 = (byte)(i4 & 0xF);
      i1 = (byte)(i3 & 0x3);
      i10 = (i3 & 0xFFFFFF80) == 0 ? (byte)(i3 >> 2) : (byte)(i3 >> 2 ^ 0xC0);
      i11 = (i4 & 0xFFFFFF80) == 0 ? (byte)(i4 >> 4) : (byte)(i4 >> 4 ^ 0xF0);
      i12 = (i5 & 0xFFFFFF80) == 0 ? (byte)(i5 >> 6) : (byte)(i5 >> 6 ^ 0xFC);
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[i10];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i11 | i1 << 4)];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i2 << 2 | i12)];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i5 & 0x3F)];
      i8++;
    }
    if (j == 8)
    {
      i3 = paramArrayOfByte[i7];
      i1 = (byte)(i3 & 0x3);
      i10 = (i3 & 0xFFFFFF80) == 0 ? (byte)(i3 >> 2) : (byte)(i3 >> 2 ^ 0xC0);
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[i10];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i1 << 4)];
      arrayOfChar[(i6++)] = '=';
      arrayOfChar[(i6++)] = '=';
    }
    else if (j == 16)
    {
      i3 = paramArrayOfByte[i7];
      i4 = paramArrayOfByte[(i7 + 1)];
      i2 = (byte)(i4 & 0xF);
      i1 = (byte)(i3 & 0x3);
      i10 = (i3 & 0xFFFFFF80) == 0 ? (byte)(i3 >> 2) : (byte)(i3 >> 2 ^ 0xC0);
      i11 = (i4 & 0xFFFFFF80) == 0 ? (byte)(i4 >> 4) : (byte)(i4 >> 4 ^ 0xF0);
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[i10];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i11 | i1 << 4)];
      arrayOfChar[(i6++)] = lookUpBase64Alphabet[(i2 << 2)];
      arrayOfChar[(i6++)] = '=';
    }
    arrayOfChar[i6] = '\n';
    return new String(arrayOfChar);
  }
  
  public static byte[] decode(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    char[] arrayOfChar = paramString.toCharArray();
    int i = removeWhiteSpace(arrayOfChar);
    if (i % 4 != 0) {
      return null;
    }
    int j = i / 4;
    if (j == 0) {
      return new byte[0];
    }
    byte[] arrayOfByte1 = null;
    int k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    char c1 = '\000';
    char c2 = '\000';
    int i6 = 0;
    int i7 = 0;
    int i8 = 0;
    arrayOfByte1 = new byte[j * 3];
    while (i6 < j - 1)
    {
      if ((!isData(i4 = arrayOfChar[(i8++)])) || (!isData(i5 = arrayOfChar[(i8++)])) || (!isData(c1 = arrayOfChar[(i8++)])) || (!isData(c2 = arrayOfChar[(i8++)]))) {
        return null;
      }
      k = base64Alphabet[i4];
      m = base64Alphabet[i5];
      n = base64Alphabet[c1];
      i1 = base64Alphabet[c2];
      arrayOfByte1[(i7++)] = ((byte)(k << 2 | m >> 4));
      arrayOfByte1[(i7++)] = ((byte)((m & 0xF) << 4 | n >> 2 & 0xF));
      arrayOfByte1[(i7++)] = ((byte)(n << 6 | i1));
      i6++;
    }
    if ((!isData(i4 = arrayOfChar[(i8++)])) || (!isData(i5 = arrayOfChar[(i8++)]))) {
      return null;
    }
    k = base64Alphabet[i4];
    m = base64Alphabet[i5];
    c1 = arrayOfChar[(i8++)];
    c2 = arrayOfChar[(i8++)];
    if ((!isData(c1)) || (!isData(c2)))
    {
      byte[] arrayOfByte2;
      if ((isPad(c1)) && (isPad(c2)))
      {
        if ((m & 0xF) != 0) {
          return null;
        }
        arrayOfByte2 = new byte[i6 * 3 + 1];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i6 * 3);
        arrayOfByte2[i7] = ((byte)(k << 2 | m >> 4));
        return arrayOfByte2;
      }
      if ((!isPad(c1)) && (isPad(c2)))
      {
        n = base64Alphabet[c1];
        if ((n & 0x3) != 0) {
          return null;
        }
        arrayOfByte2 = new byte[i6 * 3 + 2];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i6 * 3);
        arrayOfByte2[(i7++)] = ((byte)(k << 2 | m >> 4));
        arrayOfByte2[i7] = ((byte)((m & 0xF) << 4 | n >> 2 & 0xF));
        return arrayOfByte2;
      }
      return null;
    }
    n = base64Alphabet[c1];
    i1 = base64Alphabet[c2];
    arrayOfByte1[(i7++)] = ((byte)(k << 2 | m >> 4));
    arrayOfByte1[(i7++)] = ((byte)((m & 0xF) << 4 | n >> 2 & 0xF));
    arrayOfByte1[(i7++)] = ((byte)(n << 6 | i1));
    return arrayOfByte1;
  }
  
  protected static int removeWhiteSpace(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null) {
      return 0;
    }
    int i = 0;
    int j = paramArrayOfChar.length;
    for (int k = 0; k < j; k++) {
      if (!isWhiteSpace(paramArrayOfChar[k])) {
        paramArrayOfChar[(i++)] = paramArrayOfChar[k];
      }
    }
    return i;
  }
  
  static
  {
    for (int i = 0; i < 255; i++) {
      base64Alphabet[i] = -1;
    }
    for (int j = 90; j >= 65; j--) {
      base64Alphabet[j] = ((byte)(j - 65));
    }
    for (int k = 122; k >= 97; k--) {
      base64Alphabet[k] = ((byte)(k - 97 + 26));
    }
    for (int m = 57; m >= 48; m--) {
      base64Alphabet[m] = ((byte)(m - 48 + 52));
    }
    base64Alphabet[43] = 62;
    base64Alphabet[47] = 63;
    for (int n = 0; n <= 25; n++) {
      lookUpBase64Alphabet[n] = ((char)(65 + n));
    }
    int i1 = 26;
    for (int i2 = 0; i1 <= 51; i2++)
    {
      lookUpBase64Alphabet[i1] = ((char)(97 + i2));
      i1++;
    }
    int i3 = 52;
    for (int i4 = 0; i3 <= 61; i4++)
    {
      lookUpBase64Alphabet[i3] = ((char)(48 + i4));
      i3++;
    }
    lookUpBase64Alphabet[62] = '+';
    lookUpBase64Alphabet[63] = '/';
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\util\Base64.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */