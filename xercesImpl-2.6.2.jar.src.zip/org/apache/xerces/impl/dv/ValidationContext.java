package org.apache.xerces.impl.dv;

public abstract interface ValidationContext
{
  public abstract boolean needFacetChecking();
  
  public abstract boolean needExtraChecking();
  
  public abstract boolean needToNormalize();
  
  public abstract boolean useNamespaces();
  
  public abstract boolean isEntityDeclared(String paramString);
  
  public abstract boolean isEntityUnparsed(String paramString);
  
  public abstract boolean isIdDeclared(String paramString);
  
  public abstract void addId(String paramString);
  
  public abstract void addIdRef(String paramString);
  
  public abstract String getSymbol(String paramString);
  
  public abstract String getURI(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\ValidationContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */