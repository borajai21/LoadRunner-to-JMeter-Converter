package org.apache.xerces.impl.dv.dtd;

import java.util.Enumeration;
import java.util.Hashtable;
import org.apache.xerces.impl.dv.DatatypeValidator;

public class XML11DTDDVFactoryImpl
  extends DTDDVFactoryImpl
{
  static Hashtable fXML11BuiltInTypes = new Hashtable();
  
  public DatatypeValidator getBuiltInDV(String paramString)
  {
    if (fXML11BuiltInTypes.get(paramString) != null) {
      return (DatatypeValidator)fXML11BuiltInTypes.get(paramString);
    }
    return (DatatypeValidator)DTDDVFactoryImpl.fBuiltInTypes.get(paramString);
  }
  
  public Hashtable getBuiltInTypes()
  {
    Hashtable localHashtable = (Hashtable)DTDDVFactoryImpl.fBuiltInTypes.clone();
    Enumeration localEnumeration = fXML11BuiltInTypes.keys();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      localHashtable.put(localObject, fXML11BuiltInTypes.get(localObject));
    }
    return localHashtable;
  }
  
  static
  {
    fXML11BuiltInTypes.put("XML11ID", new XML11IDDatatypeValidator());
    Object localObject = new XML11IDREFDatatypeValidator();
    fXML11BuiltInTypes.put("XML11IDREF", localObject);
    fXML11BuiltInTypes.put("XML11IDREFS", new ListDatatypeValidator((DatatypeValidator)localObject));
    localObject = new XML11NMTOKENDatatypeValidator();
    fXML11BuiltInTypes.put("XML11NMTOKEN", localObject);
    fXML11BuiltInTypes.put("XML11NMTOKENS", new ListDatatypeValidator((DatatypeValidator)localObject));
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\dtd\XML11DTDDVFactoryImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */