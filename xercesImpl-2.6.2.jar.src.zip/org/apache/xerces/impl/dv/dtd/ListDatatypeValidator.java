package org.apache.xerces.impl.dv.dtd;

import java.util.StringTokenizer;
import org.apache.xerces.impl.dv.DatatypeValidator;
import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;

public class ListDatatypeValidator
  implements DatatypeValidator
{
  DatatypeValidator fItemValidator;
  
  public ListDatatypeValidator(DatatypeValidator paramDatatypeValidator)
  {
    this.fItemValidator = paramDatatypeValidator;
  }
  
  public void validate(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " ");
    int i = localStringTokenizer.countTokens();
    if (i == 0) {
      throw new InvalidDatatypeValueException("EmptyList", null);
    }
    while (localStringTokenizer.hasMoreTokens()) {
      this.fItemValidator.validate(localStringTokenizer.nextToken(), paramValidationContext);
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\dtd\ListDatatypeValidator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */