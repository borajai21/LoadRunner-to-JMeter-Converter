package org.apache.xerces.impl.dv;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

class SecuritySupport
{
  private static final Object securitySupport;
  
  static SecuritySupport getInstance()
  {
    return (SecuritySupport)securitySupport;
  }
  
  ClassLoader getContextClassLoader()
  {
    return null;
  }
  
  ClassLoader getSystemClassLoader()
  {
    return null;
  }
  
  ClassLoader getParentClassLoader(ClassLoader paramClassLoader)
  {
    return null;
  }
  
  String getSystemProperty(String paramString)
  {
    return System.getProperty(paramString);
  }
  
  FileInputStream getFileInputStream(File paramFile)
    throws FileNotFoundException
  {
    return new FileInputStream(paramFile);
  }
  
  InputStream getResourceAsStream(ClassLoader paramClassLoader, String paramString)
  {
    InputStream localInputStream;
    if (paramClassLoader == null) {
      localInputStream = ClassLoader.getSystemResourceAsStream(paramString);
    } else {
      localInputStream = paramClassLoader.getResourceAsStream(paramString);
    }
    return localInputStream;
  }
  
  boolean getFileExists(File paramFile)
  {
    return paramFile.exists();
  }
  
  long getLastModified(File paramFile)
  {
    return paramFile.lastModified();
  }
  
  static
  {
    Object localObject1 = null;
    try
    {
      Class localClass = Class.forName("java.security.AccessController");
      localObject1 = new SecuritySupport12();
    }
    catch (Exception localException) {}finally
    {
      if (localObject1 == null) {
        localObject1 = new SecuritySupport();
      }
      securitySupport = localObject1;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\SecuritySupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */