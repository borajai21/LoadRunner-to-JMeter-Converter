package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.SchemaDVFactory;
import org.apache.xerces.impl.dv.XSFacets;
import org.apache.xerces.impl.dv.XSSimpleType;
import org.apache.xerces.impl.xs.XSDeclarationPool;
import org.apache.xerces.util.SymbolHash;
import org.apache.xerces.xs.XSObjectList;

public class SchemaDVFactoryImpl
  extends SchemaDVFactory
{
  static final String URI_SCHEMAFORSCHEMA = "http://www.w3.org/2001/XMLSchema";
  static SymbolHash fBuiltInTypes = new SymbolHash();
  protected XSDeclarationPool fDeclPool = null;
  
  public XSSimpleType getBuiltInType(String paramString)
  {
    return (XSSimpleType)fBuiltInTypes.get(paramString);
  }
  
  public SymbolHash getBuiltInTypes()
  {
    return fBuiltInTypes.makeClone();
  }
  
  public XSSimpleType createTypeRestriction(String paramString1, String paramString2, short paramShort, XSSimpleType paramXSSimpleType, XSObjectList paramXSObjectList)
  {
    if (this.fDeclPool != null)
    {
      XSSimpleTypeDecl localXSSimpleTypeDecl = this.fDeclPool.getSimpleTypeDecl();
      return localXSSimpleTypeDecl.setRestrictionValues((XSSimpleTypeDecl)paramXSSimpleType, paramString1, paramString2, paramShort, paramXSObjectList);
    }
    return new XSSimpleTypeDecl((XSSimpleTypeDecl)paramXSSimpleType, paramString1, paramString2, paramShort, false, paramXSObjectList);
  }
  
  public XSSimpleType createTypeList(String paramString1, String paramString2, short paramShort, XSSimpleType paramXSSimpleType, XSObjectList paramXSObjectList)
  {
    if (this.fDeclPool != null)
    {
      XSSimpleTypeDecl localXSSimpleTypeDecl = this.fDeclPool.getSimpleTypeDecl();
      return localXSSimpleTypeDecl.setListValues(paramString1, paramString2, paramShort, (XSSimpleTypeDecl)paramXSSimpleType, paramXSObjectList);
    }
    return new XSSimpleTypeDecl(paramString1, paramString2, paramShort, (XSSimpleTypeDecl)paramXSSimpleType, false, paramXSObjectList);
  }
  
  public XSSimpleType createTypeUnion(String paramString1, String paramString2, short paramShort, XSSimpleType[] paramArrayOfXSSimpleType, XSObjectList paramXSObjectList)
  {
    int i = paramArrayOfXSSimpleType.length;
    XSSimpleTypeDecl[] arrayOfXSSimpleTypeDecl = new XSSimpleTypeDecl[i];
    System.arraycopy(paramArrayOfXSSimpleType, 0, arrayOfXSSimpleTypeDecl, 0, i);
    if (this.fDeclPool != null)
    {
      XSSimpleTypeDecl localXSSimpleTypeDecl = this.fDeclPool.getSimpleTypeDecl();
      return localXSSimpleTypeDecl.setUnionValues(paramString1, paramString2, paramShort, arrayOfXSSimpleTypeDecl, paramXSObjectList);
    }
    return new XSSimpleTypeDecl(paramString1, paramString2, paramShort, arrayOfXSSimpleTypeDecl, paramXSObjectList);
  }
  
  static void createBuiltInTypes()
  {
    XSFacets localXSFacets = new XSFacets();
    XSSimpleTypeDecl localXSSimpleTypeDecl1 = XSSimpleTypeDecl.fAnySimpleType;
    fBuiltInTypes.put("anySimpleType", localXSSimpleTypeDecl1);
    XSSimpleTypeDecl localXSSimpleTypeDecl2 = new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "string", (short)1, (short)0, false, false, false, true, (short)2);
    fBuiltInTypes.put("string", localXSSimpleTypeDecl2);
    fBuiltInTypes.put("boolean", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "boolean", (short)2, (short)0, false, true, false, true, (short)3));
    XSSimpleTypeDecl localXSSimpleTypeDecl3 = new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "decimal", (short)3, (short)2, false, false, true, true, (short)4);
    fBuiltInTypes.put("decimal", localXSSimpleTypeDecl3);
    fBuiltInTypes.put("anyURI", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "anyURI", (short)17, (short)0, false, false, false, true, (short)18));
    fBuiltInTypes.put("base64Binary", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "base64Binary", (short)16, (short)0, false, false, false, true, (short)17));
    fBuiltInTypes.put("duration", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "duration", (short)6, (short)1, false, false, false, true, (short)7));
    fBuiltInTypes.put("dateTime", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "dateTime", (short)7, (short)1, false, false, false, true, (short)8));
    fBuiltInTypes.put("time", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "time", (short)8, (short)1, false, false, false, true, (short)9));
    fBuiltInTypes.put("date", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "date", (short)9, (short)1, false, false, false, true, (short)10));
    fBuiltInTypes.put("gYearMonth", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "gYearMonth", (short)10, (short)1, false, false, false, true, (short)11));
    fBuiltInTypes.put("gYear", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "gYear", (short)11, (short)1, false, false, false, true, (short)12));
    fBuiltInTypes.put("gMonthDay", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "gMonthDay", (short)12, (short)1, false, false, false, true, (short)13));
    fBuiltInTypes.put("gDay", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "gDay", (short)13, (short)1, false, false, false, true, (short)14));
    fBuiltInTypes.put("gMonth", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "gMonth", (short)14, (short)1, false, false, false, true, (short)15));
    XSSimpleTypeDecl localXSSimpleTypeDecl4 = new XSSimpleTypeDecl(localXSSimpleTypeDecl3, "integer", (short)23, (short)2, false, false, true, true, (short)30);
    fBuiltInTypes.put("integer", localXSSimpleTypeDecl4);
    localXSFacets.maxInclusive = "0";
    XSSimpleTypeDecl localXSSimpleTypeDecl5 = new XSSimpleTypeDecl(localXSSimpleTypeDecl4, "nonPositiveInteger", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)31);
    localXSSimpleTypeDecl5.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("nonPositiveInteger", localXSSimpleTypeDecl5);
    localXSFacets.maxInclusive = "-1";
    XSSimpleTypeDecl localXSSimpleTypeDecl6 = new XSSimpleTypeDecl(localXSSimpleTypeDecl4, "negativeInteger", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)32);
    localXSSimpleTypeDecl6.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("negativeInteger", localXSSimpleTypeDecl6);
    localXSFacets.maxInclusive = "9223372036854775807";
    localXSFacets.minInclusive = "-9223372036854775808";
    XSSimpleTypeDecl localXSSimpleTypeDecl7 = new XSSimpleTypeDecl(localXSSimpleTypeDecl4, "long", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)33);
    localXSSimpleTypeDecl7.applyFacets1(localXSFacets, (short)288, (short)0);
    fBuiltInTypes.put("long", localXSSimpleTypeDecl7);
    localXSFacets.maxInclusive = "2147483647";
    localXSFacets.minInclusive = "-2147483648";
    XSSimpleTypeDecl localXSSimpleTypeDecl8 = new XSSimpleTypeDecl(localXSSimpleTypeDecl7, "int", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)34);
    localXSSimpleTypeDecl8.applyFacets1(localXSFacets, (short)288, (short)0);
    fBuiltInTypes.put("int", localXSSimpleTypeDecl8);
    localXSFacets.maxInclusive = "32767";
    localXSFacets.minInclusive = "-32768";
    XSSimpleTypeDecl localXSSimpleTypeDecl9 = new XSSimpleTypeDecl(localXSSimpleTypeDecl8, "short", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)35);
    localXSSimpleTypeDecl9.applyFacets1(localXSFacets, (short)288, (short)0);
    fBuiltInTypes.put("short", localXSSimpleTypeDecl9);
    localXSFacets.maxInclusive = "127";
    localXSFacets.minInclusive = "-128";
    XSSimpleTypeDecl localXSSimpleTypeDecl10 = new XSSimpleTypeDecl(localXSSimpleTypeDecl9, "byte", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)36);
    localXSSimpleTypeDecl10.applyFacets1(localXSFacets, (short)288, (short)0);
    fBuiltInTypes.put("byte", localXSSimpleTypeDecl10);
    localXSFacets.minInclusive = "0";
    XSSimpleTypeDecl localXSSimpleTypeDecl11 = new XSSimpleTypeDecl(localXSSimpleTypeDecl4, "nonNegativeInteger", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)37);
    localXSSimpleTypeDecl11.applyFacets1(localXSFacets, (short)256, (short)0);
    fBuiltInTypes.put("nonNegativeInteger", localXSSimpleTypeDecl11);
    localXSFacets.maxInclusive = "18446744073709551615";
    XSSimpleTypeDecl localXSSimpleTypeDecl12 = new XSSimpleTypeDecl(localXSSimpleTypeDecl11, "unsignedLong", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)38);
    localXSSimpleTypeDecl12.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("unsignedLong", localXSSimpleTypeDecl12);
    localXSFacets.maxInclusive = "4294967295";
    XSSimpleTypeDecl localXSSimpleTypeDecl13 = new XSSimpleTypeDecl(localXSSimpleTypeDecl12, "unsignedInt", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)39);
    localXSSimpleTypeDecl13.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("unsignedInt", localXSSimpleTypeDecl13);
    localXSFacets.maxInclusive = "65535";
    XSSimpleTypeDecl localXSSimpleTypeDecl14 = new XSSimpleTypeDecl(localXSSimpleTypeDecl13, "unsignedShort", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)40);
    localXSSimpleTypeDecl14.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("unsignedShort", localXSSimpleTypeDecl14);
    localXSFacets.maxInclusive = "255";
    XSSimpleTypeDecl localXSSimpleTypeDecl15 = new XSSimpleTypeDecl(localXSSimpleTypeDecl14, "unsignedByte", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)41);
    localXSSimpleTypeDecl15.applyFacets1(localXSFacets, (short)32, (short)0);
    fBuiltInTypes.put("unsignedByte", localXSSimpleTypeDecl15);
    localXSFacets.minInclusive = "1";
    XSSimpleTypeDecl localXSSimpleTypeDecl16 = new XSSimpleTypeDecl(localXSSimpleTypeDecl11, "positiveInteger", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)42);
    localXSSimpleTypeDecl16.applyFacets1(localXSFacets, (short)256, (short)0);
    fBuiltInTypes.put("positiveInteger", localXSSimpleTypeDecl16);
    fBuiltInTypes.put("float", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "float", (short)4, (short)1, true, true, true, true, (short)5));
    fBuiltInTypes.put("double", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "double", (short)5, (short)1, true, true, true, true, (short)6));
    fBuiltInTypes.put("hexBinary", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "hexBinary", (short)15, (short)0, false, false, false, true, (short)16));
    fBuiltInTypes.put("NOTATION", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "NOTATION", (short)19, (short)0, false, false, false, true, (short)20));
    localXSFacets.whiteSpace = 1;
    XSSimpleTypeDecl localXSSimpleTypeDecl17 = new XSSimpleTypeDecl(localXSSimpleTypeDecl2, "normalizedString", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)21);
    localXSSimpleTypeDecl17.applyFacets1(localXSFacets, (short)16, (short)0);
    fBuiltInTypes.put("normalizedString", localXSSimpleTypeDecl17);
    localXSFacets.whiteSpace = 2;
    XSSimpleTypeDecl localXSSimpleTypeDecl18 = new XSSimpleTypeDecl(localXSSimpleTypeDecl17, "token", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)22);
    localXSSimpleTypeDecl18.applyFacets1(localXSFacets, (short)16, (short)0);
    fBuiltInTypes.put("token", localXSSimpleTypeDecl18);
    localXSFacets.whiteSpace = 2;
    localXSFacets.pattern = "([a-zA-Z]{1,8})(-[a-zA-Z0-9]{1,8})*";
    XSSimpleTypeDecl localXSSimpleTypeDecl19 = new XSSimpleTypeDecl(localXSSimpleTypeDecl18, "language", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)23);
    localXSSimpleTypeDecl19.applyFacets1(localXSFacets, (short)24, (short)0);
    fBuiltInTypes.put("language", localXSSimpleTypeDecl19);
    localXSFacets.whiteSpace = 2;
    XSSimpleTypeDecl localXSSimpleTypeDecl20 = new XSSimpleTypeDecl(localXSSimpleTypeDecl18, "Name", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)25);
    localXSSimpleTypeDecl20.applyFacets1(localXSFacets, (short)16, (short)0, (short)2);
    fBuiltInTypes.put("Name", localXSSimpleTypeDecl20);
    localXSFacets.whiteSpace = 2;
    XSSimpleTypeDecl localXSSimpleTypeDecl21 = new XSSimpleTypeDecl(localXSSimpleTypeDecl20, "NCName", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)26);
    localXSSimpleTypeDecl21.applyFacets1(localXSFacets, (short)16, (short)0, (short)3);
    fBuiltInTypes.put("NCName", localXSSimpleTypeDecl21);
    fBuiltInTypes.put("QName", new XSSimpleTypeDecl(localXSSimpleTypeDecl1, "QName", (short)18, (short)0, false, false, false, true, (short)19));
    fBuiltInTypes.put("ID", new XSSimpleTypeDecl(localXSSimpleTypeDecl21, "ID", (short)20, (short)0, false, false, false, true, (short)27));
    XSSimpleTypeDecl localXSSimpleTypeDecl22 = new XSSimpleTypeDecl(localXSSimpleTypeDecl21, "IDREF", (short)21, (short)0, false, false, false, true, (short)28);
    fBuiltInTypes.put("IDREF", localXSSimpleTypeDecl22);
    localXSFacets.minLength = 1;
    XSSimpleTypeDecl localXSSimpleTypeDecl23 = new XSSimpleTypeDecl(null, "http://www.w3.org/2001/XMLSchema", (short)0, localXSSimpleTypeDecl22, true, null);
    XSSimpleTypeDecl localXSSimpleTypeDecl24 = new XSSimpleTypeDecl(localXSSimpleTypeDecl23, "IDREFS", "http://www.w3.org/2001/XMLSchema", (short)0, false, null);
    localXSSimpleTypeDecl24.applyFacets1(localXSFacets, (short)2, (short)0);
    fBuiltInTypes.put("IDREFS", localXSSimpleTypeDecl24);
    XSSimpleTypeDecl localXSSimpleTypeDecl25 = new XSSimpleTypeDecl(localXSSimpleTypeDecl21, "ENTITY", (short)22, (short)0, false, false, false, true, (short)29);
    fBuiltInTypes.put("ENTITY", localXSSimpleTypeDecl25);
    localXSFacets.minLength = 1;
    localXSSimpleTypeDecl23 = new XSSimpleTypeDecl(null, "http://www.w3.org/2001/XMLSchema", (short)0, localXSSimpleTypeDecl25, true, null);
    XSSimpleTypeDecl localXSSimpleTypeDecl26 = new XSSimpleTypeDecl(localXSSimpleTypeDecl23, "ENTITIES", "http://www.w3.org/2001/XMLSchema", (short)0, false, null);
    localXSSimpleTypeDecl26.applyFacets1(localXSFacets, (short)2, (short)0);
    fBuiltInTypes.put("ENTITIES", localXSSimpleTypeDecl26);
    localXSFacets.whiteSpace = 2;
    XSSimpleTypeDecl localXSSimpleTypeDecl27 = new XSSimpleTypeDecl(localXSSimpleTypeDecl18, "NMTOKEN", "http://www.w3.org/2001/XMLSchema", (short)0, false, null, (short)24);
    localXSSimpleTypeDecl27.applyFacets1(localXSFacets, (short)16, (short)0, (short)1);
    fBuiltInTypes.put("NMTOKEN", localXSSimpleTypeDecl27);
    localXSFacets.minLength = 1;
    localXSSimpleTypeDecl23 = new XSSimpleTypeDecl(null, "http://www.w3.org/2001/XMLSchema", (short)0, localXSSimpleTypeDecl27, true, null);
    XSSimpleTypeDecl localXSSimpleTypeDecl28 = new XSSimpleTypeDecl(localXSSimpleTypeDecl23, "NMTOKENS", "http://www.w3.org/2001/XMLSchema", (short)0, false, null);
    localXSSimpleTypeDecl28.applyFacets1(localXSFacets, (short)2, (short)0);
    fBuiltInTypes.put("NMTOKENS", localXSSimpleTypeDecl28);
  }
  
  public void setDeclPool(XSDeclarationPool paramXSDeclarationPool)
  {
    this.fDeclPool = paramXSDeclarationPool;
  }
  
  static
  {
    createBuiltInTypes();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\SchemaDVFactoryImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */