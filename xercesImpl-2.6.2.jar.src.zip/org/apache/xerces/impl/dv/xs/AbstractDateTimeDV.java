package org.apache.xerces.impl.dv.xs;

public abstract class AbstractDateTimeDV
  extends TypeValidator
{
  private static final boolean DEBUG = false;
  protected static final int CY = 0;
  protected static final int M = 1;
  protected static final int D = 2;
  protected static final int h = 3;
  protected static final int m = 4;
  protected static final int s = 5;
  protected static final int ms = 6;
  protected static final int utc = 7;
  protected static final int hh = 0;
  protected static final int mm = 1;
  protected static final int TOTAL_SIZE = 8;
  protected static final int YEAR = 2000;
  protected static final int MONTH = 1;
  protected static final int DAY = 15;
  
  public short getAllowedFacets()
  {
    return 2552;
  }
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    return compareDates(((DateTimeData)paramObject1).data, ((DateTimeData)paramObject2).data, true);
  }
  
  protected short compareDates(int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean paramBoolean)
  {
    if (paramArrayOfInt1[7] == paramArrayOfInt2[7]) {
      return compareOrder(paramArrayOfInt1, paramArrayOfInt2);
    }
    int[] arrayOfInt1 = new int[8];
    int[] arrayOfInt2 = new int[2];
    short s1;
    short s2;
    if (paramArrayOfInt1[7] == 90)
    {
      cloneDate(paramArrayOfInt2, arrayOfInt1);
      arrayOfInt2[0] = 14;
      arrayOfInt2[1] = 0;
      arrayOfInt1[7] = 43;
      normalize(arrayOfInt1, arrayOfInt2);
      s1 = compareOrder(paramArrayOfInt1, arrayOfInt1);
      if (s1 == -1) {
        return s1;
      }
      cloneDate(paramArrayOfInt2, arrayOfInt1);
      arrayOfInt2[0] = 14;
      arrayOfInt2[1] = 0;
      arrayOfInt1[7] = 45;
      normalize(arrayOfInt1, arrayOfInt2);
      s2 = compareOrder(paramArrayOfInt1, arrayOfInt1);
      if (s2 == 1) {
        return s2;
      }
      return 2;
    }
    if (paramArrayOfInt2[7] == 90)
    {
      cloneDate(paramArrayOfInt1, arrayOfInt1);
      arrayOfInt2[0] = 14;
      arrayOfInt2[1] = 0;
      arrayOfInt1[7] = 45;
      normalize(arrayOfInt1, arrayOfInt2);
      s1 = compareOrder(arrayOfInt1, paramArrayOfInt2);
      if (s1 == -1) {
        return s1;
      }
      cloneDate(paramArrayOfInt1, arrayOfInt1);
      arrayOfInt2[0] = 14;
      arrayOfInt2[1] = 0;
      arrayOfInt1[7] = 43;
      normalize(arrayOfInt1, arrayOfInt2);
      s2 = compareOrder(arrayOfInt1, paramArrayOfInt2);
      if (s2 == 1) {
        return s2;
      }
      return 2;
    }
    return 2;
  }
  
  protected short compareOrder(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    for (int i = 0; i < 8; i++)
    {
      if (paramArrayOfInt1[i] < paramArrayOfInt2[i]) {
        return -1;
      }
      if (paramArrayOfInt1[i] > paramArrayOfInt2[i]) {
        return 1;
      }
    }
    return 0;
  }
  
  protected void getTime(String paramString, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
    throws RuntimeException
  {
    int i = paramInt1 + 2;
    paramArrayOfInt1[3] = parseInt(paramString, paramInt1, i);
    if (paramString.charAt(i++) != ':') {
      throw new RuntimeException("Error in parsing time zone");
    }
    paramInt1 = i;
    i += 2;
    paramArrayOfInt1[4] = parseInt(paramString, paramInt1, i);
    if (paramString.charAt(i++) != ':') {
      throw new RuntimeException("Error in parsing time zone");
    }
    paramInt1 = i;
    i += 2;
    paramArrayOfInt1[5] = parseInt(paramString, paramInt1, i);
    if (i == paramInt2) {
      return;
    }
    paramInt1 = i;
    int j = paramString.charAt(paramInt1) == '.' ? paramInt1 : -1;
    int k = findUTCSign(paramString, paramInt1, paramInt2);
    if (j != -1)
    {
      paramInt1 = k < 0 ? paramInt2 : k;
      paramArrayOfInt1[6] = parseInt(paramString, j + 1, paramInt1);
    }
    if (k > 0)
    {
      if (paramInt1 != k) {
        throw new RuntimeException("Error in parsing time zone");
      }
      getTimeZone(paramString, paramArrayOfInt1, k, paramInt2, paramArrayOfInt2);
    }
    else if (paramInt1 != paramInt2)
    {
      throw new RuntimeException("Error in parsing time zone");
    }
  }
  
  protected int getDate(String paramString, int paramInt1, int paramInt2, int[] paramArrayOfInt)
    throws RuntimeException
  {
    paramInt1 = getYearMonth(paramString, paramInt1, paramInt2, paramArrayOfInt);
    if (paramString.charAt(paramInt1++) != '-') {
      throw new RuntimeException("CCYY-MM must be followed by '-' sign");
    }
    int i = paramInt1 + 2;
    paramArrayOfInt[2] = parseInt(paramString, paramInt1, i);
    return i;
  }
  
  protected int getYearMonth(String paramString, int paramInt1, int paramInt2, int[] paramArrayOfInt)
    throws RuntimeException
  {
    if (paramString.charAt(0) == '-') {
      paramInt1++;
    }
    int i = indexOf(paramString, paramInt1, paramInt2, '-');
    if (i == -1) {
      throw new RuntimeException("Year separator is missing or misplaced");
    }
    int j = i - paramInt1;
    if (j < 4) {
      throw new RuntimeException("Year must have 'CCYY' format");
    }
    if ((j > 4) && (paramString.charAt(paramInt1) == '0')) {
      throw new RuntimeException("Leading zeros are required if the year value would otherwise have fewer than four digits; otherwise they are forbidden");
    }
    paramArrayOfInt[0] = parseIntYear(paramString, i);
    if (paramString.charAt(i) != '-') {
      throw new RuntimeException("CCYY must be followed by '-' sign");
    }
    i++;
    paramInt1 = i;
    i = paramInt1 + 2;
    paramArrayOfInt[1] = parseInt(paramString, paramInt1, i);
    return i;
  }
  
  protected void parseTimeZone(String paramString, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
    throws RuntimeException
  {
    if (paramInt1 < paramInt2)
    {
      int i = findUTCSign(paramString, paramInt1, paramInt2);
      if (i < 0) {
        throw new RuntimeException("Error in month parsing");
      }
      getTimeZone(paramString, paramArrayOfInt1, i, paramInt2, paramArrayOfInt2);
    }
  }
  
  protected void getTimeZone(String paramString, int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2)
    throws RuntimeException
  {
    paramArrayOfInt1[7] = paramString.charAt(paramInt1);
    if (paramString.charAt(paramInt1) == 'Z')
    {
      if (paramInt2 > ++paramInt1) {
        throw new RuntimeException("Error in parsing time zone");
      }
      return;
    }
    if (paramInt1 <= paramInt2 - 6)
    {
      paramInt1++;
      int i = paramInt1 + 2;
      paramArrayOfInt2[0] = parseInt(paramString, paramInt1, i);
      if (paramString.charAt(i++) != ':') {
        throw new RuntimeException("Error in parsing time zone");
      }
      paramArrayOfInt2[1] = parseInt(paramString, i, i + 2);
      if (i + 2 != paramInt2) {
        throw new RuntimeException("Error in parsing time zone");
      }
    }
    else
    {
      throw new RuntimeException("Error in parsing time zone");
    }
  }
  
  protected int indexOf(String paramString, int paramInt1, int paramInt2, char paramChar)
  {
    for (int i = paramInt1; i < paramInt2; i++) {
      if (paramString.charAt(i) == paramChar) {
        return i;
      }
    }
    return -1;
  }
  
  protected void validateDateTime(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (paramArrayOfInt1[0] == 0) {
      throw new RuntimeException("The year \"0000\" is an illegal year value");
    }
    if ((paramArrayOfInt1[1] < 1) || (paramArrayOfInt1[1] > 12)) {
      throw new RuntimeException("The month must have values 1 to 12");
    }
    if ((paramArrayOfInt1[2] > maxDayInMonthFor(paramArrayOfInt1[0], paramArrayOfInt1[1])) || (paramArrayOfInt1[2] < 1)) {
      throw new RuntimeException("The day must have values 1 to 31");
    }
    if ((paramArrayOfInt1[3] > 23) || (paramArrayOfInt1[3] < 0)) {
      if ((paramArrayOfInt1[3] == 24) && (paramArrayOfInt1[4] == 0) && (paramArrayOfInt1[5] == 0) && (paramArrayOfInt1[6] == 0))
      {
        paramArrayOfInt1[3] = 0;
        if (paramArrayOfInt1[2] += 1 > maxDayInMonthFor(paramArrayOfInt1[0], paramArrayOfInt1[1]))
        {
          paramArrayOfInt1[2] = 1;
          if (paramArrayOfInt1[1] += 1 > 12)
          {
            paramArrayOfInt1[1] = 1;
            if (paramArrayOfInt1[0] += 1 == 0) {
              paramArrayOfInt1[0] = 1;
            }
          }
        }
      }
      else
      {
        throw new RuntimeException("Hour must have values 0-23, unless 24:00:00");
      }
    }
    if ((paramArrayOfInt1[4] > 59) || (paramArrayOfInt1[4] < 0)) {
      throw new RuntimeException("Minute must have values 0-59");
    }
    if ((paramArrayOfInt1[5] > 60) || (paramArrayOfInt1[5] < 0)) {
      throw new RuntimeException("Second must have values 0-60");
    }
    if ((paramArrayOfInt2[0] > 14) || (paramArrayOfInt2[0] < -14)) {
      throw new RuntimeException("Time zone should have range -14..+14");
    }
    if ((paramArrayOfInt2[1] > 59) || (paramArrayOfInt2[1] < -59)) {
      throw new RuntimeException("Minute must have values 0-59");
    }
  }
  
  protected int findUTCSign(String paramString, int paramInt1, int paramInt2)
  {
    for (int j = paramInt1; j < paramInt2; j++)
    {
      int i = paramString.charAt(j);
      if ((i == 90) || (i == 43) || (i == 45)) {
        return j;
      }
    }
    return -1;
  }
  
  protected int parseInt(String paramString, int paramInt1, int paramInt2)
    throws NumberFormatException
  {
    int i = 10;
    int j = 0;
    int k = 0;
    int n = -2147483647;
    int i1 = n / i;
    int i2 = paramInt1;
    do
    {
      k = TypeValidator.getDigit(paramString.charAt(i2));
      if (k < 0) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      if (j < i1) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      j *= i;
      if (j < n + k) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      j -= k;
      i2++;
    } while (i2 < paramInt2);
    return -j;
  }
  
  protected int parseIntYear(String paramString, int paramInt)
  {
    int i = 10;
    int j = 0;
    int k = 0;
    int n = 0;
    int i3 = 0;
    int i1;
    if (paramString.charAt(0) == '-')
    {
      k = 1;
      i1 = Integer.MIN_VALUE;
      n++;
    }
    else
    {
      i1 = -2147483647;
    }
    int i2 = i1 / i;
    while (n < paramInt)
    {
      i3 = TypeValidator.getDigit(paramString.charAt(n++));
      if (i3 < 0) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      if (j < i2) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      j *= i;
      if (j < i1 + i3) {
        throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
      }
      j -= i3;
    }
    if (k != 0)
    {
      if (n > 1) {
        return j;
      }
      throw new NumberFormatException("'" + paramString.toString() + "' has wrong format");
    }
    return -j;
  }
  
  protected void normalize(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i = 1;
    if (paramArrayOfInt1[7] == 43) {
      i = -1;
    }
    int j = paramArrayOfInt1[4] + i * paramArrayOfInt2[1];
    int k = fQuotient(j, 60);
    paramArrayOfInt1[4] = mod(j, 60, k);
    j = paramArrayOfInt1[3] + i * paramArrayOfInt2[0] + k;
    k = fQuotient(j, 24);
    paramArrayOfInt1[3] = mod(j, 24, k);
    paramArrayOfInt1[2] += k;
    for (;;)
    {
      j = maxDayInMonthFor(paramArrayOfInt1[0], paramArrayOfInt1[1]);
      if (paramArrayOfInt1[2] < 1)
      {
        paramArrayOfInt1[2] += maxDayInMonthFor(paramArrayOfInt1[0], paramArrayOfInt1[1] - 1);
        k = -1;
      }
      else
      {
        if (paramArrayOfInt1[2] <= j) {
          break;
        }
        paramArrayOfInt1[2] -= j;
        k = 1;
      }
      j = paramArrayOfInt1[1] + k;
      paramArrayOfInt1[1] = modulo(j, 1, 13);
      paramArrayOfInt1[0] += fQuotient(j, 1, 13);
    }
    paramArrayOfInt1[7] = 90;
  }
  
  protected void resetDateObj(int[] paramArrayOfInt)
  {
    for (int i = 0; i < 8; i++) {
      paramArrayOfInt[i] = 0;
    }
  }
  
  protected int maxDayInMonthFor(int paramInt1, int paramInt2)
  {
    if ((paramInt2 == 4) || (paramInt2 == 6) || (paramInt2 == 9) || (paramInt2 == 11)) {
      return 30;
    }
    if (paramInt2 == 2)
    {
      if (isLeapYear(paramInt1)) {
        return 29;
      }
      return 28;
    }
    return 31;
  }
  
  private boolean isLeapYear(int paramInt)
  {
    return (paramInt % 4 == 0) && ((paramInt % 100 != 0) || (paramInt % 400 == 0));
  }
  
  protected int mod(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 - paramInt3 * paramInt2;
  }
  
  protected int fQuotient(int paramInt1, int paramInt2)
  {
    return (int)Math.floor(paramInt1 / paramInt2);
  }
  
  protected int modulo(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt1 - paramInt2;
    int j = paramInt3 - paramInt2;
    return mod(i, j, fQuotient(i, j)) + paramInt2;
  }
  
  protected int fQuotient(int paramInt1, int paramInt2, int paramInt3)
  {
    return fQuotient(paramInt1 - paramInt2, paramInt3 - paramInt2);
  }
  
  protected String dateToString(int[] paramArrayOfInt)
  {
    StringBuffer localStringBuffer = new StringBuffer(25);
    append(localStringBuffer, paramArrayOfInt[0], 4);
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[1], 2);
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[2], 2);
    localStringBuffer.append('T');
    append(localStringBuffer, paramArrayOfInt[3], 2);
    localStringBuffer.append(':');
    append(localStringBuffer, paramArrayOfInt[4], 2);
    localStringBuffer.append(':');
    append(localStringBuffer, paramArrayOfInt[5], 2);
    localStringBuffer.append('.');
    localStringBuffer.append(paramArrayOfInt[6]);
    append(localStringBuffer, (char)paramArrayOfInt[7], 0);
    return localStringBuffer.toString();
  }
  
  protected void append(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
    {
      paramStringBuffer.append('-');
      paramInt1 = -paramInt1;
    }
    if (paramInt2 == 4)
    {
      if (paramInt1 < 10) {
        paramStringBuffer.append("000");
      } else if (paramInt1 < 100) {
        paramStringBuffer.append("00");
      } else if (paramInt1 < 1000) {
        paramStringBuffer.append("0");
      }
      paramStringBuffer.append(paramInt1);
    }
    else if (paramInt2 == 2)
    {
      if (paramInt1 < 10) {
        paramStringBuffer.append('0');
      }
      paramStringBuffer.append(paramInt1);
    }
    else if (paramInt1 != 0)
    {
      paramStringBuffer.append((char)paramInt1);
    }
  }
  
  private void cloneDate(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, 0, 8);
  }
  
  static final class DateTimeData
  {
    final int[] data;
    final AbstractDateTimeDV type;
    private String canonical;
    
    public DateTimeData(int[] paramArrayOfInt, AbstractDateTimeDV paramAbstractDateTimeDV)
    {
      this.data = paramArrayOfInt;
      this.type = paramAbstractDateTimeDV;
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof DateTimeData)) {
        return false;
      }
      int[] arrayOfInt = ((DateTimeData)paramObject).data;
      return this.type.compareDates(this.data, arrayOfInt, true) == 0;
    }
    
    public synchronized String toString()
    {
      if (this.canonical == null) {
        this.canonical = this.type.dateToString(this.data);
      }
      return this.canonical;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\AbstractDateTimeDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */