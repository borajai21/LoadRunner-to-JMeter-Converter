package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;
import org.apache.xerces.impl.dv.util.Base64;

public class Base64BinaryDV
  extends TypeValidator
{
  public short getAllowedFacets()
  {
    return 2079;
  }
  
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    byte[] arrayOfByte = Base64.decode(paramString);
    if (arrayOfByte == null) {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "base64Binary" });
    }
    return new XBase64(arrayOfByte);
  }
  
  public int getDataLength(Object paramObject)
  {
    return ((XBase64)paramObject).length();
  }
  
  private static final class XBase64
  {
    final byte[] data;
    private String canonical;
    
    public XBase64(byte[] paramArrayOfByte)
    {
      this.data = paramArrayOfByte;
    }
    
    public synchronized String toString()
    {
      if (this.canonical == null) {
        this.canonical = Base64.encode(this.data);
      }
      return this.canonical;
    }
    
    public int length()
    {
      return this.data.length;
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof XBase64)) {
        return false;
      }
      byte[] arrayOfByte = ((XBase64)paramObject).data;
      int i = this.data.length;
      if (i != arrayOfByte.length) {
        return false;
      }
      for (int j = 0; j < i; j++) {
        if (this.data[j] != arrayOfByte[j]) {
          return false;
        }
      }
      return true;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\Base64BinaryDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */