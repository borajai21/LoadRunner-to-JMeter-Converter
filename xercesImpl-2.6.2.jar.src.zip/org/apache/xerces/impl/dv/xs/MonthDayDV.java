package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;

public class MonthDayDV
  extends AbstractDateTimeDV
{
  private static final int MONTHDAY_SIZE = 7;
  
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    try
    {
      return new AbstractDateTimeDV.DateTimeData(parse(paramString), this);
    }
    catch (Exception localException)
    {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "gMonthDay" });
    }
  }
  
  protected int[] parse(String paramString)
    throws SchemaDateTimeException
  {
    int i = paramString.length();
    int[] arrayOfInt1 = new int[8];
    int[] arrayOfInt2 = new int[2];
    arrayOfInt1[0] = 2000;
    if ((paramString.charAt(0) != '-') || (paramString.charAt(1) != '-')) {
      throw new SchemaDateTimeException("Invalid format for gMonthDay: " + paramString);
    }
    arrayOfInt1[1] = parseInt(paramString, 2, 4);
    int j = 4;
    if (paramString.charAt(j++) != '-') {
      throw new SchemaDateTimeException("Invalid format for gMonthDay: " + paramString);
    }
    arrayOfInt1[2] = parseInt(paramString, j, j + 2);
    if (7 < i)
    {
      int k = findUTCSign(paramString, 7, i);
      if (k < 0) {
        throw new SchemaDateTimeException("Error in month parsing:" + paramString);
      }
      getTimeZone(paramString, arrayOfInt1, k, i, arrayOfInt2);
    }
    validateDateTime(arrayOfInt1, arrayOfInt2);
    if ((arrayOfInt1[7] != 0) && (arrayOfInt1[7] != 90)) {
      normalize(arrayOfInt1, arrayOfInt2);
    }
    return arrayOfInt1;
  }
  
  protected String dateToString(int[] paramArrayOfInt)
  {
    StringBuffer localStringBuffer = new StringBuffer(8);
    localStringBuffer.append('-');
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[1], 2);
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[2], 2);
    append(localStringBuffer, (char)paramArrayOfInt[7], 0);
    return localStringBuffer.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\MonthDayDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */