package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;

public class DurationDV
  extends AbstractDateTimeDV
{
  private static final int[][] DATETIMES = { { 1696, 9, 1, 0, 0, 0, 0, 90 }, { 1697, 2, 1, 0, 0, 0, 0, 90 }, { 1903, 3, 1, 0, 0, 0, 0, 90 }, { 1903, 7, 1, 0, 0, 0, 0, 90 } };
  
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    try
    {
      return new AbstractDateTimeDV.DateTimeData(parse(paramString), this);
    }
    catch (Exception localException)
    {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "duration" });
    }
  }
  
  protected int[] parse(String paramString)
    throws SchemaDateTimeException
  {
    int i = paramString.length();
    int[] arrayOfInt = new int[8];
    int j = 0;
    int k = paramString.charAt(j++);
    if ((k != 80) && (k != 45)) {
      throw new SchemaDateTimeException();
    }
    arrayOfInt[7] = (k == 45 ? 45 : 0);
    if ((k == 45) && (paramString.charAt(j++) != 'P')) {
      throw new SchemaDateTimeException();
    }
    int m = 1;
    if (arrayOfInt[7] == 45) {
      m = -1;
    }
    int n = 0;
    int i1 = indexOf(paramString, j, i, 'T');
    if (i1 == -1) {
      i1 = i;
    }
    int i2 = indexOf(paramString, j, i1, 'Y');
    if (i2 != -1)
    {
      arrayOfInt[0] = (m * parseInt(paramString, j, i2));
      j = i2 + 1;
      n = 1;
    }
    i2 = indexOf(paramString, j, i1, 'M');
    if (i2 != -1)
    {
      arrayOfInt[1] = (m * parseInt(paramString, j, i2));
      j = i2 + 1;
      n = 1;
    }
    i2 = indexOf(paramString, j, i1, 'D');
    if (i2 != -1)
    {
      arrayOfInt[2] = (m * parseInt(paramString, j, i2));
      j = i2 + 1;
      n = 1;
    }
    if ((i == i1) && (j != i)) {
      throw new SchemaDateTimeException();
    }
    if (i != i1)
    {
      i2 = indexOf(paramString, ++j, i, 'H');
      if (i2 != -1)
      {
        arrayOfInt[3] = (m * parseInt(paramString, j, i2));
        j = i2 + 1;
        n = 1;
      }
      i2 = indexOf(paramString, j, i, 'M');
      if (i2 != -1)
      {
        arrayOfInt[4] = (m * parseInt(paramString, j, i2));
        j = i2 + 1;
        n = 1;
      }
      i2 = indexOf(paramString, j, i, 'S');
      if (i2 != -1)
      {
        int i3 = indexOf(paramString, j, i2, '.');
        if (i3 > 0)
        {
          arrayOfInt[5] = (m * parseInt(paramString, j, i3));
          arrayOfInt[6] = (m * parseInt(paramString, i3 + 1, i2));
        }
        else
        {
          arrayOfInt[5] = (m * parseInt(paramString, j, i2));
        }
        j = i2 + 1;
        n = 1;
      }
      if ((j != i) || (paramString.charAt(--j) == 'T')) {
        throw new SchemaDateTimeException();
      }
    }
    if (n == 0) {
      throw new SchemaDateTimeException();
    }
    return arrayOfInt;
  }
  
  protected short compareDates(int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean paramBoolean)
  {
    short s2 = 2;
    short s1 = compareOrder(paramArrayOfInt1, paramArrayOfInt2);
    if (s1 == 0) {
      return 0;
    }
    int[][] arrayOfInt = new int[2][8];
    int[] arrayOfInt1 = addDuration(paramArrayOfInt1, DATETIMES[0], arrayOfInt[0]);
    int[] arrayOfInt2 = addDuration(paramArrayOfInt2, DATETIMES[0], arrayOfInt[1]);
    s1 = compareOrder(arrayOfInt1, arrayOfInt2);
    if (s1 == 2) {
      return 2;
    }
    arrayOfInt1 = addDuration(paramArrayOfInt1, DATETIMES[1], arrayOfInt[0]);
    arrayOfInt2 = addDuration(paramArrayOfInt2, DATETIMES[1], arrayOfInt[1]);
    s2 = compareOrder(arrayOfInt1, arrayOfInt2);
    s1 = compareResults(s1, s2, paramBoolean);
    if (s1 == 2) {
      return 2;
    }
    arrayOfInt1 = addDuration(paramArrayOfInt1, DATETIMES[2], arrayOfInt[0]);
    arrayOfInt2 = addDuration(paramArrayOfInt2, DATETIMES[2], arrayOfInt[1]);
    s2 = compareOrder(arrayOfInt1, arrayOfInt2);
    s1 = compareResults(s1, s2, paramBoolean);
    if (s1 == 2) {
      return 2;
    }
    arrayOfInt1 = addDuration(paramArrayOfInt1, DATETIMES[3], arrayOfInt[0]);
    arrayOfInt2 = addDuration(paramArrayOfInt2, DATETIMES[3], arrayOfInt[1]);
    s2 = compareOrder(arrayOfInt1, arrayOfInt2);
    s1 = compareResults(s1, s2, paramBoolean);
    return s1;
  }
  
  private short compareResults(short paramShort1, short paramShort2, boolean paramBoolean)
  {
    if (paramShort2 == 2) {
      return 2;
    }
    if ((paramShort1 != paramShort2) && (paramBoolean)) {
      return 2;
    }
    if ((paramShort1 != paramShort2) && (!paramBoolean))
    {
      if ((paramShort1 != 0) && (paramShort2 != 0)) {
        return 2;
      }
      return paramShort1 != 0 ? paramShort1 : paramShort2;
    }
    return paramShort1;
  }
  
  private int[] addDuration(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    resetDateObj(paramArrayOfInt3);
    int i = paramArrayOfInt2[1] + paramArrayOfInt1[1];
    paramArrayOfInt3[1] = modulo(i, 1, 13);
    int j = fQuotient(i, 1, 13);
    paramArrayOfInt3[0] = (paramArrayOfInt2[0] + paramArrayOfInt1[0] + j);
    i = paramArrayOfInt2[5] + paramArrayOfInt1[5];
    j = fQuotient(i, 60);
    paramArrayOfInt3[5] = mod(i, 60, j);
    i = paramArrayOfInt2[4] + paramArrayOfInt1[4] + j;
    j = fQuotient(i, 60);
    paramArrayOfInt3[4] = mod(i, 60, j);
    i = paramArrayOfInt2[3] + paramArrayOfInt1[3] + j;
    j = fQuotient(i, 24);
    paramArrayOfInt3[3] = mod(i, 24, j);
    paramArrayOfInt3[2] = (paramArrayOfInt2[2] + paramArrayOfInt1[2] + j);
    for (;;)
    {
      i = maxDayInMonthFor(paramArrayOfInt3[0], paramArrayOfInt3[1]);
      if (paramArrayOfInt3[2] < 1)
      {
        paramArrayOfInt3[2] += maxDayInMonthFor(paramArrayOfInt3[0], paramArrayOfInt3[1] - 1);
        j = -1;
      }
      else
      {
        if (paramArrayOfInt3[2] <= i) {
          break;
        }
        paramArrayOfInt3[2] -= i;
        j = 1;
      }
      i = paramArrayOfInt3[1] + j;
      paramArrayOfInt3[1] = modulo(i, 1, 13);
      paramArrayOfInt3[0] += fQuotient(i, 1, 13);
    }
    paramArrayOfInt3[7] = 90;
    return paramArrayOfInt3;
  }
  
  protected String dateToString(int[] paramArrayOfInt)
  {
    StringBuffer localStringBuffer = new StringBuffer(30);
    int i = 1;
    if (paramArrayOfInt[0] < 0)
    {
      localStringBuffer.append('-');
      i = -1;
    }
    localStringBuffer.append('P');
    localStringBuffer.append(i * paramArrayOfInt[0]);
    localStringBuffer.append('Y');
    localStringBuffer.append(i * paramArrayOfInt[1]);
    localStringBuffer.append('M');
    localStringBuffer.append(i * paramArrayOfInt[2]);
    localStringBuffer.append('D');
    localStringBuffer.append('T');
    localStringBuffer.append(i * paramArrayOfInt[3]);
    localStringBuffer.append('H');
    localStringBuffer.append(i * paramArrayOfInt[4]);
    localStringBuffer.append('M');
    localStringBuffer.append(i * paramArrayOfInt[5]);
    localStringBuffer.append('.');
    localStringBuffer.append(i * paramArrayOfInt[6]);
    localStringBuffer.append('S');
    return localStringBuffer.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\DurationDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */