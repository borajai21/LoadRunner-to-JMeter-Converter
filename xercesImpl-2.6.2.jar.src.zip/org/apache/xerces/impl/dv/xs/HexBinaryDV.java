package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;
import org.apache.xerces.impl.dv.util.HexBin;

public class HexBinaryDV
  extends TypeValidator
{
  public short getAllowedFacets()
  {
    return 2079;
  }
  
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    byte[] arrayOfByte = HexBin.decode(paramString);
    if (arrayOfByte == null) {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "hexBinary" });
    }
    return new XHex(arrayOfByte);
  }
  
  public int getDataLength(Object paramObject)
  {
    return ((XHex)paramObject).length();
  }
  
  private static final class XHex
  {
    final byte[] data;
    private String canonical;
    
    public XHex(byte[] paramArrayOfByte)
    {
      this.data = paramArrayOfByte;
    }
    
    public synchronized String toString()
    {
      if (this.canonical == null) {
        this.canonical = HexBin.encode(this.data);
      }
      return this.canonical;
    }
    
    public int length()
    {
      return this.data.length;
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof XHex)) {
        return false;
      }
      byte[] arrayOfByte = ((XHex)paramObject).data;
      int i = this.data.length;
      if (i != arrayOfByte.length) {
        return false;
      }
      for (int j = 0; j < i; j++) {
        if (this.data[j] != arrayOfByte[j]) {
          return false;
        }
      }
      return true;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\HexBinaryDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */