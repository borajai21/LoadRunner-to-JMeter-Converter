package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;

public class ListDV
  extends TypeValidator
{
  public short getAllowedFacets()
  {
    return 2079;
  }
  
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    return paramString;
  }
  
  public int getDataLength(Object paramObject)
  {
    return ((ListData)paramObject).length();
  }
  
  static final class ListData
  {
    final Object[] data;
    private String canonical;
    
    public ListData(Object[] paramArrayOfObject)
    {
      this.data = paramArrayOfObject;
    }
    
    public synchronized String toString()
    {
      if (this.canonical == null)
      {
        int i = this.data.length;
        StringBuffer localStringBuffer = new StringBuffer();
        if (i > 0) {
          localStringBuffer.append(this.data[0].toString());
        }
        for (int j = 1; j < i; j++)
        {
          localStringBuffer.append(' ');
          localStringBuffer.append(this.data[j].toString());
        }
        this.canonical = localStringBuffer.toString();
      }
      return this.canonical;
    }
    
    public int length()
    {
      return this.data.length;
    }
    
    public Object item(int paramInt)
    {
      return this.data[paramInt];
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof ListData)) {
        return false;
      }
      Object[] arrayOfObject = ((ListData)paramObject).data;
      int i = this.data.length;
      if (i != arrayOfObject.length) {
        return false;
      }
      for (int j = 0; j < i; j++) {
        if (!this.data[j].equals(arrayOfObject[j])) {
          return false;
        }
      }
      return true;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\ListDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */