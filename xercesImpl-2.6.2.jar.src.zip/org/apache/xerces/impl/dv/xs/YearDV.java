package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;
import org.apache.xerces.impl.dv.ValidationContext;

public class YearDV
  extends AbstractDateTimeDV
{
  public Object getActualValue(String paramString, ValidationContext paramValidationContext)
    throws InvalidDatatypeValueException
  {
    try
    {
      return new AbstractDateTimeDV.DateTimeData(parse(paramString), this);
    }
    catch (Exception localException)
    {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "gYear" });
    }
  }
  
  protected int[] parse(String paramString)
    throws SchemaDateTimeException
  {
    int i = paramString.length();
    int[] arrayOfInt1 = new int[8];
    int[] arrayOfInt2 = new int[2];
    int j = 0;
    if (paramString.charAt(0) == '-') {
      j = 1;
    }
    int k = findUTCSign(paramString, j, i);
    if (k == -1)
    {
      arrayOfInt1[0] = parseIntYear(paramString, i);
    }
    else
    {
      arrayOfInt1[0] = parseIntYear(paramString, k);
      getTimeZone(paramString, arrayOfInt1, k, i, arrayOfInt2);
    }
    arrayOfInt1[1] = 1;
    arrayOfInt1[2] = 1;
    validateDateTime(arrayOfInt1, arrayOfInt2);
    if ((arrayOfInt1[7] != 0) && (arrayOfInt1[7] != 90)) {
      normalize(arrayOfInt1, arrayOfInt2);
    }
    return arrayOfInt1;
  }
  
  protected String dateToString(int[] paramArrayOfInt)
  {
    StringBuffer localStringBuffer = new StringBuffer(5);
    append(localStringBuffer, paramArrayOfInt[0], 4);
    append(localStringBuffer, (char)paramArrayOfInt[7], 0);
    return localStringBuffer.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\YearDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */