package org.apache.xerces.impl.dv.xs;

import org.apache.xerces.impl.dv.InvalidDatatypeValueException;

public class DateDV
  extends DateTimeDV
{
  public Object getActualValue(String paramString)
    throws InvalidDatatypeValueException
  {
    try
    {
      return new AbstractDateTimeDV.DateTimeData(parse(paramString), this);
    }
    catch (Exception localException)
    {
      throw new InvalidDatatypeValueException("cvc-datatype-valid.1.2.1", new Object[] { paramString, "date" });
    }
  }
  
  protected int[] parse(String paramString)
    throws SchemaDateTimeException
  {
    int i = paramString.length();
    int[] arrayOfInt1 = new int[8];
    int[] arrayOfInt2 = new int[2];
    int j = getDate(paramString, 0, i, arrayOfInt1);
    parseTimeZone(paramString, j, i, arrayOfInt1, arrayOfInt2);
    validateDateTime(arrayOfInt1, arrayOfInt2);
    if ((arrayOfInt1[7] != 0) && (arrayOfInt1[7] != 90)) {
      normalize(arrayOfInt1, arrayOfInt2);
    }
    return arrayOfInt1;
  }
  
  protected String dateToString(int[] paramArrayOfInt)
  {
    StringBuffer localStringBuffer = new StringBuffer(25);
    append(localStringBuffer, paramArrayOfInt[0], 4);
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[1], 2);
    localStringBuffer.append('-');
    append(localStringBuffer, paramArrayOfInt[2], 2);
    append(localStringBuffer, (char)paramArrayOfInt[7], 0);
    return localStringBuffer.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\xs\DateDV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */