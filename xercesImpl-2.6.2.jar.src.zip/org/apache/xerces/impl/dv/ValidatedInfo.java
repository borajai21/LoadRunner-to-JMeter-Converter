package org.apache.xerces.impl.dv;

import org.apache.xerces.xs.ShortList;

public class ValidatedInfo
{
  public String normalizedValue;
  public Object actualValue;
  public short actualValueType;
  public XSSimpleType memberType;
  public XSSimpleType[] memberTypes;
  public ShortList itemValueTypes;
  
  public void reset()
  {
    this.normalizedValue = null;
    this.actualValue = null;
    this.memberType = null;
    this.memberTypes = null;
  }
  
  public String stringValue()
  {
    if (this.actualValue == null) {
      return this.normalizedValue;
    }
    return this.actualValue.toString();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dv\ValidatedInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */