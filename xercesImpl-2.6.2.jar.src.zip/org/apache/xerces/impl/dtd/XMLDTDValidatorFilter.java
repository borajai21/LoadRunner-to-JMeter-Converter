package org.apache.xerces.impl.dtd;

import org.apache.xerces.xni.parser.XMLDocumentFilter;

public abstract interface XMLDTDValidatorFilter
  extends XMLDocumentFilter
{
  public abstract boolean hasGrammar();
  
  public abstract boolean validate();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dtd\XMLDTDValidatorFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */