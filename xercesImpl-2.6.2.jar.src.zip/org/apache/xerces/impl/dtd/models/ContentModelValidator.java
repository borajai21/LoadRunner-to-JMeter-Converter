package org.apache.xerces.impl.dtd.models;

import org.apache.xerces.xni.QName;

public abstract interface ContentModelValidator
{
  public abstract int validate(QName[] paramArrayOfQName, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dtd\models\ContentModelValidator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */