package org.apache.xerces.impl.dtd.models;

public class CMUniOp
  extends CMNode
{
  private CMNode fChild;
  
  public CMUniOp(int paramInt, CMNode paramCMNode)
  {
    super(paramInt);
    if ((type() != 1) && (type() != 2) && (type() != 3)) {
      throw new RuntimeException("ImplementationMessages.VAL_UST");
    }
    this.fChild = paramCMNode;
  }
  
  final CMNode getChild()
  {
    return this.fChild;
  }
  
  public boolean isNullable()
  {
    if (type() == 3) {
      return this.fChild.isNullable();
    }
    return true;
  }
  
  protected void calcFirstPos(CMStateSet paramCMStateSet)
  {
    paramCMStateSet.setTo(this.fChild.firstPos());
  }
  
  protected void calcLastPos(CMStateSet paramCMStateSet)
  {
    paramCMStateSet.setTo(this.fChild.lastPos());
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\dtd\models\CMUniOp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */