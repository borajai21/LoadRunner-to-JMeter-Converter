package org.apache.xerces.impl.validation;

public abstract interface EntityState
{
  public abstract boolean isEntityDeclared(String paramString);
  
  public abstract boolean isEntityUnparsed(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\validation\EntityState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */