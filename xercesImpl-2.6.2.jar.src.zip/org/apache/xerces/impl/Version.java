package org.apache.xerces.impl;

import java.io.PrintStream;

public class Version
{
  /**
   * @deprecated
   */
  public static String fVersion = "Xerces-J 2.6.2";
  private static final String fImmutableVersion = "Xerces-J 2.6.2";
  
  public static String getVersion()
  {
    return "Xerces-J 2.6.2";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    System.out.println(fVersion);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */