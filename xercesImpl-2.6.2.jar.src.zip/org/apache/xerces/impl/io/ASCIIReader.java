package org.apache.xerces.impl.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Locale;
import org.apache.xerces.util.MessageFormatter;

public class ASCIIReader
  extends Reader
{
  public static final int DEFAULT_BUFFER_SIZE = 2048;
  protected InputStream fInputStream;
  protected byte[] fBuffer;
  private MessageFormatter fFormatter = null;
  private Locale fLocale = null;
  
  public ASCIIReader(InputStream paramInputStream, MessageFormatter paramMessageFormatter, Locale paramLocale)
  {
    this(paramInputStream, 2048, paramMessageFormatter, paramLocale);
  }
  
  public ASCIIReader(InputStream paramInputStream, int paramInt, MessageFormatter paramMessageFormatter, Locale paramLocale)
  {
    this.fInputStream = paramInputStream;
    this.fBuffer = new byte[paramInt];
    this.fFormatter = paramMessageFormatter;
    this.fLocale = paramLocale;
  }
  
  public int read()
    throws IOException
  {
    int i = this.fInputStream.read();
    if (i >= 128) {
      throw new IOException(this.fFormatter.formatMessage(this.fLocale, "InvalidASCII", new Object[] { Integer.toString(i) }));
    }
    return i;
  }
  
  public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 > this.fBuffer.length) {
      paramInt2 = this.fBuffer.length;
    }
    int i = this.fInputStream.read(this.fBuffer, 0, paramInt2);
    for (int j = 0; j < i; j++)
    {
      int k = this.fBuffer[j];
      if (k < 0) {
        throw new IOException(this.fFormatter.formatMessage(this.fLocale, "InvalidASCII", new Object[] { Integer.toString(k & 0xFF) }));
      }
      paramArrayOfChar[(paramInt1 + j)] = ((char)k);
    }
    return i;
  }
  
  public long skip(long paramLong)
    throws IOException
  {
    return this.fInputStream.skip(paramLong);
  }
  
  public boolean ready()
    throws IOException
  {
    return false;
  }
  
  public boolean markSupported()
  {
    return this.fInputStream.markSupported();
  }
  
  public void mark(int paramInt)
    throws IOException
  {
    this.fInputStream.mark(paramInt);
  }
  
  public void reset()
    throws IOException
  {
    this.fInputStream.reset();
  }
  
  public void close()
    throws IOException
  {
    this.fInputStream.close();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\impl\io\ASCIIReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */