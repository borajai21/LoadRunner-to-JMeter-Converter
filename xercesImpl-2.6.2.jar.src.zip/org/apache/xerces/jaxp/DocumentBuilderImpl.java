package org.apache.xerces.jaxp;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.xerces.dom.DOMImplementationImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.parsers.AbstractDOMParser;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.helpers.DefaultHandler;

public class DocumentBuilderImpl
  extends DocumentBuilder
  implements JAXPConstants
{
  private EntityResolver er = null;
  private ErrorHandler eh = null;
  private DOMParser domParser = null;
  
  DocumentBuilderImpl(DocumentBuilderFactory paramDocumentBuilderFactory, Hashtable paramHashtable)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    if (paramDocumentBuilderFactory.isValidating()) {
      setErrorHandler(new DefaultValidationErrorHandler());
    }
    this.domParser.setFeature("http://xml.org/sax/features/validation", paramDocumentBuilderFactory.isValidating());
    this.domParser.setFeature("http://xml.org/sax/features/namespaces", paramDocumentBuilderFactory.isNamespaceAware());
    this.domParser.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", !paramDocumentBuilderFactory.isIgnoringElementContentWhitespace());
    this.domParser.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", !paramDocumentBuilderFactory.isExpandEntityReferences());
    this.domParser.setFeature("http://apache.org/xml/features/include-comments", !paramDocumentBuilderFactory.isIgnoringComments());
    this.domParser.setFeature("http://apache.org/xml/features/create-cdata-nodes", !paramDocumentBuilderFactory.isCoalescing());
    setDocumentBuilderFactoryAttributes(paramHashtable);
  }
  
  private void setDocumentBuilderFactoryAttributes(Hashtable paramHashtable)
    throws SAXNotSupportedException, SAXNotRecognizedException
  {
    if (paramHashtable == null) {
      return;
    }
    Enumeration localEnumeration = paramHashtable.keys();
    while (localEnumeration.hasMoreElements())
    {
      String str1 = (String)localEnumeration.nextElement();
      Object localObject = paramHashtable.get(str1);
      if ((localObject instanceof Boolean)) {
        this.domParser.setFeature(str1, ((Boolean)localObject).booleanValue());
      } else if ("http://java.sun.com/xml/jaxp/properties/schemaLanguage".equals(str1))
      {
        if (("http://www.w3.org/2001/XMLSchema".equals(localObject)) && (isValidating()))
        {
          this.domParser.setFeature("http://apache.org/xml/features/validation/schema", true);
          this.domParser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
        }
      }
      else if ("http://java.sun.com/xml/jaxp/properties/schemaSource".equals(str1))
      {
        if (isValidating())
        {
          String str2 = (String)paramHashtable.get("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
          if ((str2 != null) && ("http://www.w3.org/2001/XMLSchema".equals(str2))) {
            this.domParser.setProperty(str1, localObject);
          } else {
            throw new IllegalArgumentException(DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "jaxp-order-not-supported", new Object[] { "http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://java.sun.com/xml/jaxp/properties/schemaSource" }));
          }
        }
      }
      else {
        this.domParser.setProperty(str1, localObject);
      }
    }
  }
  
  public Document newDocument()
  {
    return new DocumentImpl();
  }
  
  public DOMImplementation getDOMImplementation()
  {
    return DOMImplementationImpl.getDOMImplementation();
  }
  
  public Document parse(InputSource paramInputSource)
    throws SAXException, IOException
  {
    if (paramInputSource == null) {
      throw new IllegalArgumentException(DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "jaxp-null-input-source", null));
    }
    if (this.er != null) {
      this.domParser.setEntityResolver(this.er);
    }
    if (this.eh != null) {
      this.domParser.setErrorHandler(this.eh);
    }
    this.domParser.parse(paramInputSource);
    return this.domParser.getDocument();
  }
  
  public boolean isNamespaceAware()
  {
    try
    {
      return this.domParser.getFeature("http://xml.org/sax/features/namespaces");
    }
    catch (SAXException localSAXException)
    {
      throw new IllegalStateException(localSAXException.getMessage());
    }
  }
  
  public boolean isValidating()
  {
    try
    {
      return this.domParser.getFeature("http://xml.org/sax/features/validation");
    }
    catch (SAXException localSAXException)
    {
      throw new IllegalStateException(localSAXException.getMessage());
    }
  }
  
  public void setEntityResolver(EntityResolver paramEntityResolver)
  {
    this.er = paramEntityResolver;
  }
  
  public void setErrorHandler(ErrorHandler paramErrorHandler)
  {
    this.eh = (paramErrorHandler == null ? new DefaultHandler() : paramErrorHandler);
  }
  
  DOMParser getDOMParser()
  {
    return this.domParser;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\jaxp\DocumentBuilderImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */