package org.apache.xerces.jaxp;

import java.util.Enumeration;
import java.util.Hashtable;
import javax.xml.parsers.SAXParserFactory;
import org.apache.xerces.util.SAXMessageFormatter;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

public class SAXParserImpl
  extends javax.xml.parsers.SAXParser
  implements JAXPConstants
{
  private XMLReader xmlReader = new org.apache.xerces.parsers.SAXParser();
  private String schemaLanguage = null;
  
  SAXParserImpl(SAXParserFactory paramSAXParserFactory, Hashtable paramHashtable)
    throws SAXException
  {
    if (paramSAXParserFactory.isValidating()) {
      this.xmlReader.setErrorHandler(new DefaultValidationErrorHandler());
    }
    this.xmlReader.setFeature("http://xml.org/sax/features/validation", paramSAXParserFactory.isValidating());
    this.xmlReader.setFeature("http://xml.org/sax/features/namespaces", paramSAXParserFactory.isNamespaceAware());
    this.xmlReader.setFeature("http://xml.org/sax/features/namespace-prefixes", !paramSAXParserFactory.isNamespaceAware());
    setFeatures(paramHashtable);
  }
  
  private void setFeatures(Hashtable paramHashtable)
    throws SAXNotSupportedException, SAXNotRecognizedException
  {
    if (paramHashtable != null)
    {
      Enumeration localEnumeration = paramHashtable.keys();
      while (localEnumeration.hasMoreElements())
      {
        String str = (String)localEnumeration.nextElement();
        boolean bool = ((Boolean)paramHashtable.get(str)).booleanValue();
        this.xmlReader.setFeature(str, bool);
      }
    }
  }
  
  public Parser getParser()
    throws SAXException
  {
    return (Parser)this.xmlReader;
  }
  
  public XMLReader getXMLReader()
  {
    return this.xmlReader;
  }
  
  public boolean isNamespaceAware()
  {
    try
    {
      return this.xmlReader.getFeature("http://xml.org/sax/features/namespaces");
    }
    catch (SAXException localSAXException)
    {
      throw new IllegalStateException(localSAXException.getMessage());
    }
  }
  
  public boolean isValidating()
  {
    try
    {
      return this.xmlReader.getFeature("http://xml.org/sax/features/validation");
    }
    catch (SAXException localSAXException)
    {
      throw new IllegalStateException(localSAXException.getMessage());
    }
  }
  
  public void setProperty(String paramString, Object paramObject)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    if ("http://java.sun.com/xml/jaxp/properties/schemaLanguage".equals(paramString))
    {
      if ("http://www.w3.org/2001/XMLSchema".equals(paramObject))
      {
        if (isValidating())
        {
          this.schemaLanguage = "http://www.w3.org/2001/XMLSchema";
          this.xmlReader.setFeature("http://apache.org/xml/features/validation/schema", true);
          this.xmlReader.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
        }
      }
      else if (paramObject == null)
      {
        this.schemaLanguage = null;
        this.xmlReader.setFeature("http://apache.org/xml/features/validation/schema", false);
      }
      else
      {
        throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(null, "schema-not-supported", null));
      }
    }
    else if ("http://java.sun.com/xml/jaxp/properties/schemaSource".equals(paramString))
    {
      String str = (String)getProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
      if ((str != null) && ("http://www.w3.org/2001/XMLSchema".equals(str))) {
        this.xmlReader.setProperty(paramString, paramObject);
      } else {
        throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(null, "jaxp-order-not-supported", new Object[] { "http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://java.sun.com/xml/jaxp/properties/schemaSource" }));
      }
    }
    else
    {
      this.xmlReader.setProperty(paramString, paramObject);
    }
  }
  
  public Object getProperty(String paramString)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    if ("http://java.sun.com/xml/jaxp/properties/schemaLanguage".equals(paramString)) {
      return this.schemaLanguage;
    }
    return this.xmlReader.getProperty(paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\jaxp\SAXParserImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */