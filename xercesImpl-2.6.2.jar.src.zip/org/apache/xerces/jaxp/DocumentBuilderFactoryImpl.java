package org.apache.xerces.jaxp;

import java.util.Hashtable;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.xerces.parsers.DOMParser;
import org.xml.sax.SAXException;

public class DocumentBuilderFactoryImpl
  extends DocumentBuilderFactory
{
  private Hashtable attributes;
  
  public DocumentBuilder newDocumentBuilder()
    throws ParserConfigurationException
  {
    try
    {
      return new DocumentBuilderImpl(this, this.attributes);
    }
    catch (SAXException localSAXException)
    {
      throw new ParserConfigurationException(localSAXException.getMessage());
    }
  }
  
  public void setAttribute(String paramString, Object paramObject)
    throws IllegalArgumentException
  {
    if (paramObject == null)
    {
      if (this.attributes != null) {
        this.attributes.remove(paramString);
      }
      return;
    }
    if (this.attributes == null) {
      this.attributes = new Hashtable();
    }
    this.attributes.put(paramString, paramObject);
    try
    {
      new DocumentBuilderImpl(this, this.attributes);
    }
    catch (Exception localException)
    {
      this.attributes.remove(paramString);
      throw new IllegalArgumentException(localException.getMessage());
    }
  }
  
  public Object getAttribute(String paramString)
    throws IllegalArgumentException
  {
    if (this.attributes != null)
    {
      localObject = this.attributes.get(paramString);
      if (localObject != null) {
        return localObject;
      }
    }
    Object localObject = null;
    try
    {
      localObject = new DocumentBuilderImpl(this, this.attributes).getDOMParser();
      return ((DOMParser)localObject).getProperty(paramString);
    }
    catch (SAXException localSAXException1)
    {
      try
      {
        boolean bool = ((DOMParser)localObject).getFeature(paramString);
        return bool ? Boolean.TRUE : Boolean.FALSE;
      }
      catch (SAXException localSAXException2)
      {
        throw new IllegalArgumentException(localSAXException1.getMessage());
      }
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\jaxp\DocumentBuilderFactoryImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */