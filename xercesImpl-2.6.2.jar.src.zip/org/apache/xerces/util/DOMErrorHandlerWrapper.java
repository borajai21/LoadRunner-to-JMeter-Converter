package org.apache.xerces.util;

import java.io.PrintWriter;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMLocatorImpl;
import org.apache.xerces.dom3.DOMError;
import org.apache.xerces.dom3.DOMErrorHandler;
import org.apache.xerces.dom3.DOMLocator;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLParseException;
import org.w3c.dom.Node;

public class DOMErrorHandlerWrapper
  implements XMLErrorHandler, DOMErrorHandler
{
  protected DOMErrorHandler fDomErrorHandler;
  boolean eStatus = true;
  protected PrintWriter fOut;
  public Node fCurrentNode;
  protected final DOMErrorImpl fDOMError = new DOMErrorImpl();
  
  public DOMErrorHandlerWrapper()
  {
    this.fOut = new PrintWriter(System.err);
  }
  
  public DOMErrorHandlerWrapper(DOMErrorHandler paramDOMErrorHandler)
  {
    this.fDomErrorHandler = paramDOMErrorHandler;
  }
  
  public void setErrorHandler(DOMErrorHandler paramDOMErrorHandler)
  {
    this.fDomErrorHandler = paramDOMErrorHandler;
  }
  
  public DOMErrorHandler getErrorHandler()
  {
    return this.fDomErrorHandler;
  }
  
  public void warning(String paramString1, String paramString2, XMLParseException paramXMLParseException)
    throws XNIException
  {
    this.fDOMError.fSeverity = 1;
    this.fDOMError.fException = paramXMLParseException;
    this.fDOMError.fType = paramString2;
    this.fDOMError.fRelatedData = (this.fDOMError.fMessage = paramXMLParseException.getMessage());
    DOMLocatorImpl localDOMLocatorImpl = this.fDOMError.fLocator;
    if (localDOMLocatorImpl != null)
    {
      localDOMLocatorImpl.fColumnNumber = paramXMLParseException.getColumnNumber();
      localDOMLocatorImpl.fLineNumber = paramXMLParseException.getLineNumber();
      localDOMLocatorImpl.fUri = paramXMLParseException.getExpandedSystemId();
      localDOMLocatorImpl.fRelatedNode = this.fCurrentNode;
    }
    this.fDomErrorHandler.handleError(this.fDOMError);
  }
  
  public void error(String paramString1, String paramString2, XMLParseException paramXMLParseException)
    throws XNIException
  {
    this.fDOMError.fSeverity = 2;
    this.fDOMError.fException = paramXMLParseException;
    this.fDOMError.fType = paramString2;
    this.fDOMError.fRelatedData = (this.fDOMError.fMessage = paramXMLParseException.getMessage());
    DOMLocatorImpl localDOMLocatorImpl = this.fDOMError.fLocator;
    if (localDOMLocatorImpl != null)
    {
      localDOMLocatorImpl.fColumnNumber = paramXMLParseException.getColumnNumber();
      localDOMLocatorImpl.fLineNumber = paramXMLParseException.getLineNumber();
      localDOMLocatorImpl.fUri = paramXMLParseException.getExpandedSystemId();
      localDOMLocatorImpl.fRelatedNode = this.fCurrentNode;
    }
    this.fDomErrorHandler.handleError(this.fDOMError);
  }
  
  public void fatalError(String paramString1, String paramString2, XMLParseException paramXMLParseException)
    throws XNIException
  {
    this.fDOMError.fSeverity = 3;
    this.fDOMError.fException = paramXMLParseException;
    this.fDOMError.fType = paramString2;
    this.fDOMError.fRelatedData = (this.fDOMError.fMessage = paramXMLParseException.getMessage());
    DOMLocatorImpl localDOMLocatorImpl = this.fDOMError.fLocator;
    if (localDOMLocatorImpl != null)
    {
      localDOMLocatorImpl.fColumnNumber = paramXMLParseException.getColumnNumber();
      localDOMLocatorImpl.fLineNumber = paramXMLParseException.getLineNumber();
      localDOMLocatorImpl.fUri = paramXMLParseException.getExpandedSystemId();
      localDOMLocatorImpl.fRelatedNode = this.fCurrentNode;
    }
    this.fDomErrorHandler.handleError(this.fDOMError);
  }
  
  public boolean handleError(DOMError paramDOMError)
  {
    printError(paramDOMError);
    return this.eStatus;
  }
  
  private void printError(DOMError paramDOMError)
  {
    int i = paramDOMError.getSeverity();
    this.fOut.print("[");
    if (i == 1)
    {
      this.fOut.print("Warning");
    }
    else if (i == 2)
    {
      this.fOut.print("Error");
    }
    else
    {
      this.fOut.print("FatalError");
      this.eStatus = false;
    }
    this.fOut.print("] ");
    DOMLocator localDOMLocator = paramDOMError.getLocation();
    if (localDOMLocator != null)
    {
      this.fOut.print(localDOMLocator.getLineNumber());
      this.fOut.print(":");
      this.fOut.print(localDOMLocator.getColumnNumber());
      this.fOut.print(":");
      this.fOut.print(localDOMLocator.getByteOffset());
      this.fOut.print(",");
      this.fOut.print(localDOMLocator.getUtf16Offset());
      Node localNode = localDOMLocator.getRelatedNode();
      if (localNode != null)
      {
        this.fOut.print("[");
        this.fOut.print(localNode.getNodeName());
        this.fOut.print("]");
      }
      String str = localDOMLocator.getUri();
      if (str != null)
      {
        int j = str.lastIndexOf('/');
        if (j != -1) {
          str = str.substring(j + 1);
        }
        this.fOut.print(": ");
        this.fOut.print(str);
      }
    }
    this.fOut.print(":");
    this.fOut.print(paramDOMError.getMessage());
    this.fOut.println();
    this.fOut.flush();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\util\DOMErrorHandlerWrapper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */