package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.Locale;
import org.apache.xerces.util.EntityResolverWrapper;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SymbolHash;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.PSVIProvider;
import org.xml.sax.AttributeList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.DeclHandler;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.LocatorImpl;

public abstract class AbstractSAXParser
  extends AbstractXMLDocumentParser
  implements PSVIProvider, Parser, XMLReader
{
  protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
  protected static final String NAMESPACE_PREFIXES = "http://xml.org/sax/features/namespace-prefixes";
  protected static final String STRING_INTERNING = "http://xml.org/sax/features/string-interning";
  protected static final String ALLOW_UE_AND_NOTATION_EVENTS = "http://xml.org/sax/features/allow-dtd-events-after-endDTD";
  private static final String[] RECOGNIZED_FEATURES = { "http://xml.org/sax/features/namespaces", "http://xml.org/sax/features/namespace-prefixes", "http://xml.org/sax/features/string-interning" };
  protected static final String LEXICAL_HANDLER = "http://xml.org/sax/properties/lexical-handler";
  protected static final String DECLARATION_HANDLER = "http://xml.org/sax/properties/declaration-handler";
  protected static final String DOM_NODE = "http://xml.org/sax/properties/dom-node";
  private static final String[] RECOGNIZED_PROPERTIES = { "http://xml.org/sax/properties/lexical-handler", "http://xml.org/sax/properties/declaration-handler", "http://xml.org/sax/properties/dom-node" };
  protected boolean fNamespaces;
  protected boolean fNamespacePrefixes = false;
  protected ContentHandler fContentHandler;
  protected DocumentHandler fDocumentHandler;
  protected NamespaceContext fNamespaceContext;
  protected DTDHandler fDTDHandler;
  protected DeclHandler fDeclHandler;
  protected LexicalHandler fLexicalHandler;
  protected QName fQName = new QName();
  protected boolean fParseInProgress = false;
  protected String fVersion;
  private final AttributesProxy fAttributesProxy = new AttributesProxy();
  private Augmentations fAugmentations = null;
  private static final int BUFFER_SIZE = 20;
  private char[] fCharBuffer = new char[20];
  protected SymbolHash fDeclaredAttrs = null;
  
  protected AbstractSAXParser(XMLParserConfiguration paramXMLParserConfiguration)
  {
    super(paramXMLParserConfiguration);
    paramXMLParserConfiguration.addRecognizedFeatures(RECOGNIZED_FEATURES);
    paramXMLParserConfiguration.addRecognizedProperties(RECOGNIZED_PROPERTIES);
    try
    {
      paramXMLParserConfiguration.setFeature("http://xml.org/sax/features/allow-dtd-events-after-endDTD", false);
    }
    catch (XMLConfigurationException localXMLConfigurationException) {}
  }
  
  public void startDocument(XMLLocator paramXMLLocator, String paramString, NamespaceContext paramNamespaceContext, Augmentations paramAugmentations)
    throws XNIException
  {
    this.fNamespaceContext = paramNamespaceContext;
    try
    {
      if (this.fDocumentHandler != null)
      {
        if (paramXMLLocator != null) {
          this.fDocumentHandler.setDocumentLocator(new LocatorProxy(paramXMLLocator));
        }
        this.fDocumentHandler.startDocument();
      }
      if (this.fContentHandler != null)
      {
        if (paramXMLLocator != null) {
          this.fContentHandler.setDocumentLocator(new LocatorProxy(paramXMLLocator));
        }
        this.fContentHandler.startDocument();
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void xmlDecl(String paramString1, String paramString2, String paramString3, Augmentations paramAugmentations)
    throws XNIException
  {
    this.fVersion = paramString1;
  }
  
  public void doctypeDecl(String paramString1, String paramString2, String paramString3, Augmentations paramAugmentations)
    throws XNIException
  {
    this.fInDTD = true;
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.startDTD(paramString1, paramString2, paramString3);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
    if (this.fDeclHandler != null) {
      this.fDeclaredAttrs = new SymbolHash();
    }
  }
  
  public void startGeneralEntity(String paramString1, XMLResourceIdentifier paramXMLResourceIdentifier, String paramString2, Augmentations paramAugmentations)
    throws XNIException
  {
    startParameterEntity(paramString1, paramXMLResourceIdentifier, paramString2, paramAugmentations);
  }
  
  public void endGeneralEntity(String paramString, Augmentations paramAugmentations)
    throws XNIException
  {
    endParameterEntity(paramString, paramAugmentations);
  }
  
  public void startElement(QName paramQName, XMLAttributes paramXMLAttributes, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDocumentHandler != null)
      {
        this.fAttributesProxy.setAttributes(paramXMLAttributes);
        this.fDocumentHandler.startElement(paramQName.rawname, this.fAttributesProxy);
      }
      if (this.fContentHandler != null)
      {
        if (this.fNamespaces)
        {
          int i = startNamespaceMapping();
          if (i > 0)
          {
            int j = paramXMLAttributes.getLength();
            for (int k = j - 1; k >= 0; k--)
            {
              paramXMLAttributes.getName(k, this.fQName);
              if (((this.fQName.prefix != null) && (this.fQName.prefix.equals("xmlns"))) || (this.fQName.rawname.equals("xmlns"))) {
                if (!this.fNamespacePrefixes)
                {
                  paramXMLAttributes.removeAttributeAt(k);
                }
                else
                {
                  this.fQName.prefix = "";
                  this.fQName.uri = "";
                  this.fQName.localpart = "";
                  paramXMLAttributes.setName(k, this.fQName);
                }
              }
            }
          }
        }
        this.fAugmentations = paramAugmentations;
        String str1 = paramQName.uri != null ? paramQName.uri : "";
        String str2 = this.fNamespaces ? paramQName.localpart : "";
        this.fAttributesProxy.setAttributes(paramXMLAttributes);
        this.fContentHandler.startElement(str1, str2, paramQName.rawname, this.fAttributesProxy);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void characters(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    if (paramXMLString.length == 0) {
      return;
    }
    try
    {
      if (this.fDocumentHandler != null) {
        this.fDocumentHandler.characters(paramXMLString.ch, paramXMLString.offset, paramXMLString.length);
      }
      if (this.fContentHandler != null) {
        this.fContentHandler.characters(paramXMLString.ch, paramXMLString.offset, paramXMLString.length);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void ignorableWhitespace(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDocumentHandler != null) {
        this.fDocumentHandler.ignorableWhitespace(paramXMLString.ch, paramXMLString.offset, paramXMLString.length);
      }
      if (this.fContentHandler != null) {
        this.fContentHandler.ignorableWhitespace(paramXMLString.ch, paramXMLString.offset, paramXMLString.length);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void endElement(QName paramQName, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDocumentHandler != null) {
        this.fDocumentHandler.endElement(paramQName.rawname);
      }
      if (this.fContentHandler != null)
      {
        this.fAugmentations = paramAugmentations;
        String str1 = paramQName.uri != null ? paramQName.uri : "";
        String str2 = this.fNamespaces ? paramQName.localpart : "";
        this.fContentHandler.endElement(str1, str2, paramQName.rawname);
        if (this.fNamespaces) {
          endNamespaceMapping();
        }
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void startCDATA(Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.startCDATA();
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void endCDATA(Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.endCDATA();
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void comment(XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.comment(paramXMLString.ch, 0, paramXMLString.length);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void processingInstruction(String paramString, XMLString paramXMLString, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDocumentHandler != null) {
        this.fDocumentHandler.processingInstruction(paramString, paramXMLString.toString());
      }
      if (this.fContentHandler != null) {
        this.fContentHandler.processingInstruction(paramString, paramXMLString.toString());
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void endDocument(Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDocumentHandler != null) {
        this.fDocumentHandler.endDocument();
      }
      if (this.fContentHandler != null) {
        this.fContentHandler.endDocument();
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void startExternalSubset(XMLResourceIdentifier paramXMLResourceIdentifier, Augmentations paramAugmentations)
    throws XNIException
  {
    startParameterEntity("[dtd]", null, null, paramAugmentations);
  }
  
  public void endExternalSubset(Augmentations paramAugmentations)
    throws XNIException
  {
    endParameterEntity("[dtd]", paramAugmentations);
  }
  
  public void startParameterEntity(String paramString1, XMLResourceIdentifier paramXMLResourceIdentifier, String paramString2, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.startEntity(paramString1);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void endParameterEntity(String paramString, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.endEntity(paramString);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void elementDecl(String paramString1, String paramString2, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDeclHandler != null) {
        this.fDeclHandler.elementDecl(paramString1, paramString2);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void attributeDecl(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, String paramString4, XMLString paramXMLString1, XMLString paramXMLString2, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDeclHandler != null)
      {
        String str = paramString1 + "<" + paramString2;
        if (this.fDeclaredAttrs.get(str) != null) {
          return;
        }
        this.fDeclaredAttrs.put(str, Boolean.TRUE);
        if ((paramString3.equals("NOTATION")) || (paramString3.equals("ENUMERATION")))
        {
          localObject = new StringBuffer();
          if (paramString3.equals("NOTATION"))
          {
            ((StringBuffer)localObject).append(paramString3);
            ((StringBuffer)localObject).append(" (");
          }
          else
          {
            ((StringBuffer)localObject).append("(");
          }
          for (int i = 0; i < paramArrayOfString.length; i++)
          {
            ((StringBuffer)localObject).append(paramArrayOfString[i]);
            if (i < paramArrayOfString.length - 1) {
              ((StringBuffer)localObject).append('|');
            }
          }
          ((StringBuffer)localObject).append(')');
          paramString3 = ((StringBuffer)localObject).toString();
        }
        Object localObject = paramXMLString1 == null ? null : paramXMLString1.toString();
        this.fDeclHandler.attributeDecl(paramString1, paramString2, paramString3, paramString4, (String)localObject);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void internalEntityDecl(String paramString, XMLString paramXMLString1, XMLString paramXMLString2, Augmentations paramAugmentations)
    throws XNIException
  {
    try
    {
      if (this.fDeclHandler != null) {
        this.fDeclHandler.internalEntityDecl(paramString, paramXMLString1.toString());
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void externalEntityDecl(String paramString, XMLResourceIdentifier paramXMLResourceIdentifier, Augmentations paramAugmentations)
    throws XNIException
  {
    String str1 = paramXMLResourceIdentifier.getPublicId();
    String str2 = paramXMLResourceIdentifier.getLiteralSystemId();
    try
    {
      if (this.fDeclHandler != null) {
        this.fDeclHandler.externalEntityDecl(paramString, str1, str2);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void unparsedEntityDecl(String paramString1, XMLResourceIdentifier paramXMLResourceIdentifier, String paramString2, Augmentations paramAugmentations)
    throws XNIException
  {
    String str1 = paramXMLResourceIdentifier.getPublicId();
    String str2 = paramXMLResourceIdentifier.getExpandedSystemId();
    try
    {
      if (this.fDTDHandler != null) {
        this.fDTDHandler.unparsedEntityDecl(paramString1, str1, str2, paramString2);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void notationDecl(String paramString, XMLResourceIdentifier paramXMLResourceIdentifier, Augmentations paramAugmentations)
    throws XNIException
  {
    String str1 = paramXMLResourceIdentifier.getPublicId();
    String str2 = paramXMLResourceIdentifier.getExpandedSystemId();
    try
    {
      if (this.fDTDHandler != null) {
        this.fDTDHandler.notationDecl(paramString, str1, str2);
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
  }
  
  public void endDTD(Augmentations paramAugmentations)
    throws XNIException
  {
    this.fInDTD = false;
    try
    {
      if (this.fLexicalHandler != null) {
        this.fLexicalHandler.endDTD();
      }
    }
    catch (SAXException localSAXException)
    {
      throw new XNIException(localSAXException);
    }
    if (this.fDeclaredAttrs != null) {
      this.fDeclaredAttrs.clear();
    }
  }
  
  public void parse(String paramString)
    throws SAXException, IOException
  {
    XMLInputSource localXMLInputSource = new XMLInputSource(null, paramString, null);
    try
    {
      parse(localXMLInputSource);
    }
    catch (XMLParseException localXMLParseException)
    {
      Exception localException = localXMLParseException.getException();
      if (localException == null)
      {
        localObject = new LocatorImpl()
        {
          public String getXMLVersion()
          {
            return AbstractSAXParser.this.fVersion;
          }
          
          public String getEncoding()
          {
            return null;
          }
        };
        ((LocatorImpl)localObject).setPublicId(localXMLParseException.getPublicId());
        ((LocatorImpl)localObject).setSystemId(localXMLParseException.getExpandedSystemId());
        ((LocatorImpl)localObject).setLineNumber(localXMLParseException.getLineNumber());
        ((LocatorImpl)localObject).setColumnNumber(localXMLParseException.getColumnNumber());
        throw new SAXParseException(localXMLParseException.getMessage(), (Locator)localObject);
      }
      if ((localException instanceof SAXException)) {
        throw ((SAXException)localException);
      }
      if ((localException instanceof IOException)) {
        throw ((IOException)localException);
      }
      throw new SAXException(localException);
    }
    catch (XNIException localXNIException)
    {
      Object localObject = localXNIException.getException();
      if (localObject == null) {
        throw new SAXException(localXNIException.getMessage());
      }
      if ((localObject instanceof SAXException)) {
        throw ((SAXException)localObject);
      }
      if ((localObject instanceof IOException)) {
        throw ((IOException)localObject);
      }
      throw new SAXException((Exception)localObject);
    }
  }
  
  public void parse(InputSource paramInputSource)
    throws SAXException, IOException
  {
    try
    {
      XMLInputSource localXMLInputSource = new XMLInputSource(paramInputSource.getPublicId(), paramInputSource.getSystemId(), null);
      localXMLInputSource.setByteStream(paramInputSource.getByteStream());
      localXMLInputSource.setCharacterStream(paramInputSource.getCharacterStream());
      localXMLInputSource.setEncoding(paramInputSource.getEncoding());
      parse(localXMLInputSource);
    }
    catch (XMLParseException localXMLParseException)
    {
      Exception localException = localXMLParseException.getException();
      if (localException == null)
      {
        localObject = new LocatorImpl()
        {
          public String getXMLVersion()
          {
            return AbstractSAXParser.this.fVersion;
          }
          
          public String getEncoding()
          {
            return null;
          }
        };
        ((LocatorImpl)localObject).setPublicId(localXMLParseException.getPublicId());
        ((LocatorImpl)localObject).setSystemId(localXMLParseException.getExpandedSystemId());
        ((LocatorImpl)localObject).setLineNumber(localXMLParseException.getLineNumber());
        ((LocatorImpl)localObject).setColumnNumber(localXMLParseException.getColumnNumber());
        throw new SAXParseException(localXMLParseException.getMessage(), (Locator)localObject);
      }
      if ((localException instanceof SAXException)) {
        throw ((SAXException)localException);
      }
      if ((localException instanceof IOException)) {
        throw ((IOException)localException);
      }
      throw new SAXException(localException);
    }
    catch (XNIException localXNIException)
    {
      Object localObject = localXNIException.getException();
      if (localObject == null) {
        throw new SAXException(localXNIException.getMessage());
      }
      if ((localObject instanceof SAXException)) {
        throw ((SAXException)localObject);
      }
      if ((localObject instanceof IOException)) {
        throw ((IOException)localObject);
      }
      throw new SAXException((Exception)localObject);
    }
  }
  
  public void setEntityResolver(EntityResolver paramEntityResolver)
  {
    try
    {
      this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", new EntityResolverWrapper(paramEntityResolver));
    }
    catch (XMLConfigurationException localXMLConfigurationException) {}
  }
  
  public EntityResolver getEntityResolver()
  {
    EntityResolver localEntityResolver = null;
    try
    {
      XMLEntityResolver localXMLEntityResolver = (XMLEntityResolver)this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
      if ((localXMLEntityResolver != null) && ((localXMLEntityResolver instanceof EntityResolverWrapper))) {
        localEntityResolver = ((EntityResolverWrapper)localXMLEntityResolver).getEntityResolver();
      }
    }
    catch (XMLConfigurationException localXMLConfigurationException) {}
    return localEntityResolver;
  }
  
  public void setErrorHandler(ErrorHandler paramErrorHandler)
  {
    try
    {
      this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/error-handler", new ErrorHandlerWrapper(paramErrorHandler));
    }
    catch (XMLConfigurationException localXMLConfigurationException) {}
  }
  
  public ErrorHandler getErrorHandler()
  {
    ErrorHandler localErrorHandler = null;
    try
    {
      XMLErrorHandler localXMLErrorHandler = (XMLErrorHandler)this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/error-handler");
      if ((localXMLErrorHandler != null) && ((localXMLErrorHandler instanceof ErrorHandlerWrapper))) {
        localErrorHandler = ((ErrorHandlerWrapper)localXMLErrorHandler).getErrorHandler();
      }
    }
    catch (XMLConfigurationException localXMLConfigurationException) {}
    return localErrorHandler;
  }
  
  public void setLocale(Locale paramLocale)
    throws SAXException
  {
    this.fConfiguration.setLocale(paramLocale);
  }
  
  public void setDTDHandler(DTDHandler paramDTDHandler)
  {
    this.fDTDHandler = paramDTDHandler;
  }
  
  public void setDocumentHandler(DocumentHandler paramDocumentHandler)
  {
    this.fDocumentHandler = paramDocumentHandler;
  }
  
  public void setContentHandler(ContentHandler paramContentHandler)
  {
    this.fContentHandler = paramContentHandler;
  }
  
  public ContentHandler getContentHandler()
  {
    return this.fContentHandler;
  }
  
  public DTDHandler getDTDHandler()
  {
    return this.fDTDHandler;
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    try
    {
      if (paramString.startsWith("http://xml.org/sax/features/"))
      {
        int i = paramString.length() - "http://xml.org/sax/features/".length();
        if ((i == "namespaces".length()) && (paramString.endsWith("namespaces")))
        {
          this.fConfiguration.setFeature(paramString, paramBoolean);
          this.fNamespaces = paramBoolean;
          return;
        }
        if ((i == "namespace-prefixes".length()) && (paramString.endsWith("namespace-prefixes")))
        {
          this.fConfiguration.setFeature(paramString, paramBoolean);
          this.fNamespacePrefixes = paramBoolean;
          return;
        }
        if ((i == "string-interning".length()) && (paramString.endsWith("string-interning")))
        {
          if (!paramBoolean) {
            throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "false-not-supported", new Object[] { paramString }));
          }
          return;
        }
      }
      this.fConfiguration.setFeature(paramString, paramBoolean);
    }
    catch (XMLConfigurationException localXMLConfigurationException)
    {
      String str = localXMLConfigurationException.getIdentifier();
      if (localXMLConfigurationException.getType() == 0) {
        throw new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[] { str }));
      }
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[] { str }));
    }
  }
  
  public boolean getFeature(String paramString)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    try
    {
      if (paramString.startsWith("http://xml.org/sax/features/"))
      {
        int i = paramString.length() - "http://xml.org/sax/features/".length();
        if ((i == "namespace-prefixes".length()) && (paramString.endsWith("namespace-prefixes")))
        {
          boolean bool = this.fConfiguration.getFeature(paramString);
          return bool;
        }
        if ((i == "string-interning".length()) && (paramString.endsWith("string-interning"))) {
          return true;
        }
      }
      return this.fConfiguration.getFeature(paramString);
    }
    catch (XMLConfigurationException localXMLConfigurationException)
    {
      String str = localXMLConfigurationException.getIdentifier();
      if (localXMLConfigurationException.getType() == 0) {
        throw new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[] { str }));
      }
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[] { str }));
    }
  }
  
  public void setProperty(String paramString, Object paramObject)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    try
    {
      if (paramString.startsWith("http://xml.org/sax/properties/"))
      {
        int i = paramString.length() - "http://xml.org/sax/properties/".length();
        if ((i == "lexical-handler".length()) && (paramString.endsWith("lexical-handler")))
        {
          try
          {
            setLexicalHandler((LexicalHandler)paramObject);
          }
          catch (ClassCastException localClassCastException1)
          {
            throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "incompatible-class", new Object[] { paramString, "org.xml.sax.ext.LexicalHandler" }));
          }
          return;
        }
        if ((i == "declaration-handler".length()) && (paramString.endsWith("declaration-handler")))
        {
          try
          {
            setDeclHandler((DeclHandler)paramObject);
          }
          catch (ClassCastException localClassCastException2)
          {
            throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "incompatible-class", new Object[] { paramString, "org.xml.sax.ext.DeclHandler" }));
          }
          return;
        }
        if ((i == "dom-node".length()) && (paramString.endsWith("dom-node"))) {
          throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-read-only", new Object[] { paramString }));
        }
      }
      this.fConfiguration.setProperty(paramString, paramObject);
    }
    catch (XMLConfigurationException localXMLConfigurationException)
    {
      String str = localXMLConfigurationException.getIdentifier();
      if (localXMLConfigurationException.getType() == 0) {
        throw new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[] { str }));
      }
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[] { str }));
    }
  }
  
  public Object getProperty(String paramString)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    try
    {
      if (paramString.startsWith("http://xml.org/sax/properties/"))
      {
        int i = paramString.length() - "http://xml.org/sax/properties/".length();
        if ((i == "lexical-handler".length()) && (paramString.endsWith("lexical-handler"))) {
          return getLexicalHandler();
        }
        if ((i == "declaration-handler".length()) && (paramString.endsWith("declaration-handler"))) {
          return getDeclHandler();
        }
        if ((i == "dom-node".length()) && (paramString.endsWith("dom-node"))) {
          throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "dom-node-read-not-supported", null));
        }
      }
      return this.fConfiguration.getProperty(paramString);
    }
    catch (XMLConfigurationException localXMLConfigurationException)
    {
      String str = localXMLConfigurationException.getIdentifier();
      if (localXMLConfigurationException.getType() == 0) {
        throw new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[] { str }));
      }
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[] { str }));
    }
  }
  
  protected void setDeclHandler(DeclHandler paramDeclHandler)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    if (this.fParseInProgress) {
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-parsing-supported", new Object[] { "http://xml.org/sax/properties/declaration-handler" }));
    }
    this.fDeclHandler = paramDeclHandler;
  }
  
  protected DeclHandler getDeclHandler()
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    return this.fDeclHandler;
  }
  
  protected void setLexicalHandler(LexicalHandler paramLexicalHandler)
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    if (this.fParseInProgress) {
      throw new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-parsing-supported", new Object[] { "http://xml.org/sax/properties/lexical-handler" }));
    }
    this.fLexicalHandler = paramLexicalHandler;
  }
  
  protected LexicalHandler getLexicalHandler()
    throws SAXNotRecognizedException, SAXNotSupportedException
  {
    return this.fLexicalHandler;
  }
  
  protected final int startNamespaceMapping()
    throws SAXException
  {
    int i = this.fNamespaceContext.getDeclaredPrefixCount();
    if (i > 0)
    {
      String str1 = null;
      String str2 = null;
      for (int j = 0; j < i; j++)
      {
        str1 = this.fNamespaceContext.getDeclaredPrefixAt(j);
        str2 = this.fNamespaceContext.getURI(str1);
        this.fContentHandler.startPrefixMapping(str1, str2 == null ? "" : str2);
      }
    }
    return i;
  }
  
  protected final void endNamespaceMapping()
    throws SAXException
  {
    int i = this.fNamespaceContext.getDeclaredPrefixCount();
    if (i > 0) {
      for (int j = 0; j < i; j++) {
        this.fContentHandler.endPrefixMapping(this.fNamespaceContext.getDeclaredPrefixAt(j));
      }
    }
  }
  
  public void reset()
    throws XNIException
  {
    super.reset();
    this.fInDTD = false;
    this.fVersion = "1.0";
    this.fNamespaces = this.fConfiguration.getFeature("http://xml.org/sax/features/namespaces");
    this.fNamespacePrefixes = this.fConfiguration.getFeature("http://xml.org/sax/features/namespace-prefixes");
    this.fAugmentations = null;
    this.fDeclaredAttrs = null;
  }
  
  public ElementPSVI getElementPSVI()
  {
    return this.fAugmentations != null ? (ElementPSVI)this.fAugmentations.getItem("ELEMENT_PSVI") : null;
  }
  
  public AttributePSVI getAttributePSVI(int paramInt)
  {
    return (AttributePSVI)this.fAttributesProxy.fAttributes.getAugmentations(paramInt).getItem("ATTRIBUTE_PSVI");
  }
  
  public AttributePSVI getAttributePSVIByName(String paramString1, String paramString2)
  {
    return (AttributePSVI)this.fAttributesProxy.fAttributes.getAugmentations(paramString1, paramString2).getItem("ATTRIBUTE_PSVI");
  }
  
  protected static final class AttributesProxy
    implements AttributeList, Attributes
  {
    protected XMLAttributes fAttributes;
    
    public void setAttributes(XMLAttributes paramXMLAttributes)
    {
      this.fAttributes = paramXMLAttributes;
    }
    
    public int getLength()
    {
      return this.fAttributes.getLength();
    }
    
    public String getName(int paramInt)
    {
      return this.fAttributes.getQName(paramInt);
    }
    
    public String getQName(int paramInt)
    {
      return this.fAttributes.getQName(paramInt);
    }
    
    public String getURI(int paramInt)
    {
      String str = this.fAttributes.getURI(paramInt);
      return str != null ? str : "";
    }
    
    public String getLocalName(int paramInt)
    {
      return this.fAttributes.getLocalName(paramInt);
    }
    
    public String getType(int paramInt)
    {
      return this.fAttributes.getType(paramInt);
    }
    
    public String getType(String paramString)
    {
      return this.fAttributes.getType(paramString);
    }
    
    public String getType(String paramString1, String paramString2)
    {
      return paramString1.equals("") ? this.fAttributes.getType(null, paramString2) : this.fAttributes.getType(paramString1, paramString2);
    }
    
    public String getValue(int paramInt)
    {
      return this.fAttributes.getValue(paramInt);
    }
    
    public String getValue(String paramString)
    {
      return this.fAttributes.getValue(paramString);
    }
    
    public String getValue(String paramString1, String paramString2)
    {
      return paramString1.equals("") ? this.fAttributes.getValue(null, paramString2) : this.fAttributes.getValue(paramString1, paramString2);
    }
    
    public int getIndex(String paramString)
    {
      return this.fAttributes.getIndex(paramString);
    }
    
    public int getIndex(String paramString1, String paramString2)
    {
      return paramString1.equals("") ? this.fAttributes.getIndex(null, paramString2) : this.fAttributes.getIndex(paramString1, paramString2);
    }
  }
  
  protected class LocatorProxy
    implements Locator
  {
    protected XMLLocator fLocator;
    
    public LocatorProxy(XMLLocator paramXMLLocator)
    {
      this.fLocator = paramXMLLocator;
    }
    
    public String getPublicId()
    {
      return this.fLocator.getPublicId();
    }
    
    public String getSystemId()
    {
      return this.fLocator.getExpandedSystemId();
    }
    
    public int getLineNumber()
    {
      return this.fLocator.getLineNumber();
    }
    
    public int getColumnNumber()
    {
      return this.fLocator.getColumnNumber();
    }
    
    public String getXMLVersion()
    {
      return AbstractSAXParser.this.fVersion;
    }
    
    public String getEncoding()
    {
      return this.fLocator.getEncoding();
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\parsers\AbstractSAXParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */