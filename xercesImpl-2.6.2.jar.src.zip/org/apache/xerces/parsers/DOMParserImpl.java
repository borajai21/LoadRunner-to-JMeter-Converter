package org.apache.xerces.parsers;

import java.io.StringReader;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DOMStringListImpl;
import org.apache.xerces.dom3.DOMConfiguration;
import org.apache.xerces.dom3.DOMErrorHandler;
import org.apache.xerces.dom3.DOMStringList;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.DOMErrorHandlerWrapper;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSParserFilter;
import org.w3c.dom.ls.LSResourceResolver;

public class DOMParserImpl
  extends AbstractDOMParser
  implements LSParser, DOMConfiguration
{
  protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
  protected static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
  protected static final String XMLSCHEMA = "http://apache.org/xml/features/validation/schema";
  protected static final String DYNAMIC_VALIDATION = "http://apache.org/xml/features/validation/dynamic";
  protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
  protected static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
  protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
  protected static final String PSVI_AUGMENT = "http://apache.org/xml/features/validation/schema/augment-psvi";
  protected String fSchemaType = null;
  protected boolean fBusy = false;
  protected static final boolean DEBUG = false;
  private Vector fSchemaLocations = new Vector();
  private String fSchemaLocation = null;
  private DOMStringList fRecognizedParameters;
  
  public DOMParserImpl(String paramString1, String paramString2)
  {
    this((XMLParserConfiguration)ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", paramString1));
    if (paramString2 != null) {
      if (paramString2.equals(Constants.NS_DTD))
      {
        this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema", false);
        this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_DTD);
        this.fSchemaType = Constants.NS_DTD;
      }
      else if (paramString2.equals(Constants.NS_XMLSCHEMA))
      {
        this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_XMLSCHEMA);
      }
    }
  }
  
  public DOMParserImpl(XMLParserConfiguration paramXMLParserConfiguration)
  {
    super(paramXMLParserConfiguration);
    String[] arrayOfString = { "canonical-form", "cdata-sections", "charset-overrides-xml-encoding", "infoset", "namespace-declarations", "supported-media-types-only", "certified", "well-formed", "ignore-unknown-character-denormalizations" };
    this.fConfiguration.addRecognizedFeatures(arrayOfString);
    this.fConfiguration.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false);
    this.fConfiguration.setFeature("namespace-declarations", true);
    this.fConfiguration.setFeature("well-formed", true);
    this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", true);
    this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", true);
    this.fConfiguration.setFeature("http://xml.org/sax/features/namespaces", true);
    this.fConfiguration.setFeature("http://apache.org/xml/features/validation/dynamic", false);
    this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", false);
    this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema/normalized-value", false);
    this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", false);
    this.fConfiguration.setFeature("canonical-form", false);
    this.fConfiguration.setFeature("charset-overrides-xml-encoding", true);
    this.fConfiguration.setFeature("supported-media-types-only", false);
    this.fConfiguration.setFeature("ignore-unknown-character-denormalizations", true);
    this.fConfiguration.setFeature("certified", true);
    this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema/normalized-value", false);
  }
  
  public DOMParserImpl(SymbolTable paramSymbolTable)
  {
    this((XMLParserConfiguration)ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XML11Configuration"));
    this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/symbol-table", paramSymbolTable);
  }
  
  public DOMParserImpl(SymbolTable paramSymbolTable, XMLGrammarPool paramXMLGrammarPool)
  {
    this((XMLParserConfiguration)ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XML11Configuration"));
    this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/symbol-table", paramSymbolTable);
    this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/grammar-pool", paramXMLGrammarPool);
  }
  
  public void reset()
  {
    super.reset();
    if (this.fSkippedElemStack != null) {
      this.fSkippedElemStack.removeAllElements();
    }
    this.fSchemaLocations.clear();
    this.fRejectedElement.clear();
    this.fFilterReject = false;
    this.fSchemaType = null;
  }
  
  public DOMConfiguration getDomConfig()
  {
    return this;
  }
  
  public LSParserFilter getFilter()
  {
    return this.fDOMFilter;
  }
  
  public void setFilter(LSParserFilter paramLSParserFilter)
  {
    this.fDOMFilter = paramLSParserFilter;
    if (this.fSkippedElemStack == null) {
      this.fSkippedElemStack = new Stack();
    }
  }
  
  public void setParameter(String paramString, Object paramObject)
    throws DOMException
  {
    if ((paramObject instanceof Boolean))
    {
      boolean bool = ((Boolean)paramObject).booleanValue();
      try
      {
        if (paramString.equals("comments"))
        {
          this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", bool);
        }
        else if (paramString.equals("datatype-normalization"))
        {
          this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema/normalized-value", bool);
        }
        else if (paramString.equals("entities"))
        {
          this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", bool);
        }
        else if (paramString.equals("disallow-doctype"))
        {
          this.fConfiguration.setFeature("http://apache.org/xml/features/disallow-doctype-decl", bool);
        }
        else
        {
          String str4;
          if ((paramString.equals("supported-media-types-only")) || (paramString.equals("normalize-characters")) || (paramString.equals("check-character-normalization")) || (paramString.equals("canonical-form")))
          {
            if (bool)
            {
              str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
              throw new DOMException((short)9, str4);
            }
          }
          else if (paramString.equals("namespaces"))
          {
            this.fConfiguration.setFeature("http://xml.org/sax/features/namespaces", bool);
          }
          else if (paramString.equals("infoset"))
          {
            if (bool)
            {
              this.fConfiguration.setFeature("http://xml.org/sax/features/namespaces", true);
              this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", true);
              this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", true);
              this.fConfiguration.setFeature("http://apache.org/xml/features/validation/dynamic", false);
              this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", false);
              this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema/normalized-value", false);
              this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", false);
            }
          }
          else if (paramString.equals("cdata-sections"))
          {
            this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", bool);
          }
          else if ((paramString.equals("namespace-declarations")) || (paramString.equals("well-formed")) || (paramString.equals("ignore-unknown-character-denormalizations")))
          {
            if (!bool)
            {
              str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
              throw new DOMException((short)9, str4);
            }
          }
          else if (paramString.equals("validate"))
          {
            this.fConfiguration.setFeature("http://xml.org/sax/features/validation", bool);
            if (this.fSchemaType != Constants.NS_DTD) {
              this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema", bool);
            }
            if (bool) {
              this.fConfiguration.setFeature("http://apache.org/xml/features/validation/dynamic", false);
            }
          }
          else if (paramString.equals("validate-if-schema"))
          {
            this.fConfiguration.setFeature("http://apache.org/xml/features/validation/dynamic", bool);
            if (bool) {
              this.fConfiguration.setFeature("http://xml.org/sax/features/validation", false);
            }
          }
          else if (paramString.equals("element-content-whitespace"))
          {
            this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", bool);
          }
          else if (paramString.equals("psvi"))
          {
            this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema/augment-psvi", true);
            this.fConfiguration.setProperty("http://apache.org/xml/properties/dom/document-class-name", "org.apache.xerces.dom.PSVIDocumentImpl");
          }
          else
          {
            this.fConfiguration.setFeature(paramString, bool);
          }
        }
      }
      catch (XMLConfigurationException localXMLConfigurationException5)
      {
        String str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
        throw new DOMException((short)8, str5);
      }
    }
    else if (paramString.equals("error-handler"))
    {
      if (paramObject == null) {
        return;
      }
      if ((paramObject instanceof DOMErrorHandler))
      {
        try
        {
          this.fErrorHandler = new DOMErrorHandlerWrapper((DOMErrorHandler)paramObject);
          this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/error-handler", this.fErrorHandler);
        }
        catch (XMLConfigurationException localXMLConfigurationException1) {}
      }
      else
      {
        String str1 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
        throw new DOMException((short)9, str1);
      }
    }
    else
    {
      Object localObject;
      if (paramString.equals("resource-resolver"))
      {
        if ((paramObject instanceof LSResourceResolver))
        {
          try
          {
            this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", new DOMEntityResolverWrapper((LSResourceResolver)paramObject));
          }
          catch (XMLConfigurationException localXMLConfigurationException2) {}
        }
        else
        {
          localObject = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
          throw new DOMException((short)9, (String)localObject);
        }
      }
      else if (paramString.equals("schema-location"))
      {
        if ((paramObject instanceof String))
        {
          try
          {
            if (this.fSchemaType == Constants.NS_XMLSCHEMA)
            {
              this.fSchemaLocation = ((String)paramObject);
              localObject = new StringTokenizer(this.fSchemaLocation, " \n\t\r");
              if (((StringTokenizer)localObject).hasMoreTokens())
              {
                this.fSchemaLocations.clear();
                this.fSchemaLocations.add(((StringTokenizer)localObject).nextToken());
                while (((StringTokenizer)localObject).hasMoreTokens()) {
                  this.fSchemaLocations.add(((StringTokenizer)localObject).nextToken());
                }
                this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", this.fSchemaLocations.toArray());
              }
              else
              {
                this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", paramObject);
              }
            }
            else
            {
              localObject = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
              throw new DOMException((short)9, (String)localObject);
            }
          }
          catch (XMLConfigurationException localXMLConfigurationException3) {}
        }
        else
        {
          String str2 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
          throw new DOMException((short)9, str2);
        }
      }
      else
      {
        String str3;
        if (paramString.equals("schema-type"))
        {
          if ((paramObject instanceof String))
          {
            try
            {
              if (paramObject.equals(Constants.NS_XMLSCHEMA))
              {
                this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema", true);
                this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_XMLSCHEMA);
                this.fSchemaType = Constants.NS_XMLSCHEMA;
              }
              else if (paramObject.equals(Constants.NS_DTD))
              {
                this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema", false);
                this.fConfiguration.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_DTD);
                this.fSchemaType = Constants.NS_DTD;
              }
            }
            catch (XMLConfigurationException localXMLConfigurationException4) {}
          }
          else
          {
            str3 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
            throw new DOMException((short)9, str3);
          }
        }
        else if (paramString.equals("http://apache.org/xml/properties/dom/document-class-name"))
        {
          this.fConfiguration.setProperty("http://apache.org/xml/properties/dom/document-class-name", paramObject);
        }
        else
        {
          str3 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
          throw new DOMException((short)8, str3);
        }
      }
    }
  }
  
  public Object getParameter(String paramString)
    throws DOMException
  {
    if (paramString.equals("comments")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/include-comments") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("datatype-normalization")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/validation/schema/normalized-value") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("entities")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("namespaces")) {
      return this.fConfiguration.getFeature("http://xml.org/sax/features/namespaces") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("validate")) {
      return this.fConfiguration.getFeature("http://xml.org/sax/features/validation") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("validate-if-schema")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/validation/dynamic") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("element-content-whitespace")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("disallow-doctype")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/disallow-doctype-decl") ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("infoset"))
    {
      int i = (this.fConfiguration.getFeature("http://xml.org/sax/features/namespaces")) && (this.fConfiguration.getFeature("http://apache.org/xml/features/include-comments")) && (this.fConfiguration.getFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace")) && (!this.fConfiguration.getFeature("http://apache.org/xml/features/validation/dynamic")) && (!this.fConfiguration.getFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes")) && (!this.fConfiguration.getFeature("http://apache.org/xml/features/validation/schema/normalized-value")) && (!this.fConfiguration.getFeature("http://apache.org/xml/features/create-cdata-nodes")) ? 1 : 0;
      return i != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("cdata-sections")) {
      return this.fConfiguration.getFeature("http://apache.org/xml/features/create-cdata-nodes") ? Boolean.TRUE : Boolean.FALSE;
    }
    if ((paramString.equals("check-character-normalization")) || (paramString.equals("normalize-characters"))) {
      return Boolean.FALSE;
    }
    if ((paramString.equals("namespace-declarations")) || (paramString.equals("well-formed")) || (paramString.equals("ignore-unknown-character-denormalizations")) || (paramString.equals("canonical-form")) || (paramString.equals("supported-media-types-only")) || (paramString.equals("charset-overrides-xml-encoding"))) {
      return this.fConfiguration.getFeature(paramString) ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("error-handler"))
    {
      if (this.fErrorHandler != null) {
        return this.fErrorHandler.getErrorHandler();
      }
      return null;
    }
    if (paramString.equals("resource-resolver"))
    {
      try
      {
        XMLEntityResolver localXMLEntityResolver = (XMLEntityResolver)this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
        if ((localXMLEntityResolver != null) && ((localXMLEntityResolver instanceof DOMEntityResolverWrapper))) {
          return ((DOMEntityResolverWrapper)localXMLEntityResolver).getEntityResolver();
        }
        return null;
      }
      catch (XMLConfigurationException localXMLConfigurationException) {}
    }
    else
    {
      if (paramString.equals("schema-type")) {
        return this.fConfiguration.getProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
      }
      if (paramString.equals("schema-location")) {
        return this.fSchemaLocation;
      }
      if (paramString.equals("http://apache.org/xml/properties/internal/symbol-table")) {
        return this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/symbol-table");
      }
      if (paramString.equals("http://apache.org/xml/properties/dom/document-class-name")) {
        return this.fConfiguration.getProperty("http://apache.org/xml/properties/dom/document-class-name");
      }
      String str = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
      throw new DOMException((short)8, str);
    }
    return null;
  }
  
  public boolean canSetParameter(String paramString, Object paramObject)
  {
    if ((paramObject instanceof Boolean))
    {
      boolean bool = ((Boolean)paramObject).booleanValue();
      if ((paramString.equals("supported-media-types-only")) || (paramString.equals("normalize-characters")) || (paramString.equals("check-character-normalization")) || (paramString.equals("canonical-form"))) {
        return !bool;
      }
      if ((paramString.equals("namespace-declarations")) || (paramString.equals("well-formed")) || (paramString.equals("ignore-unknown-character-denormalizations"))) {
        return bool;
      }
      if ((paramString.equals("cdata-sections")) || (paramString.equals("charset-overrides-xml-encoding")) || (paramString.equals("comments")) || (paramString.equals("datatype-normalization")) || (paramString.equals("disallow-doctype")) || (paramString.equals("entities")) || (paramString.equals("infoset")) || (paramString.equals("namespaces")) || (paramString.equals("validate")) || (paramString.equals("validate-if-schema")) || (paramString.equals("element-content-whitespace")) || (paramString.equals("xml-declaration"))) {
        return true;
      }
      try
      {
        this.fConfiguration.getFeature(paramString);
        return true;
      }
      catch (XMLConfigurationException localXMLConfigurationException)
      {
        return false;
      }
    }
    if (paramString.equals("error-handler")) {
      return (paramObject instanceof DOMErrorHandler);
    }
    if (paramString.equals("resource-resolver")) {
      return (paramObject instanceof LSResourceResolver);
    }
    if (paramString.equals("schema-type")) {
      return ((paramObject instanceof String)) && ((paramObject.equals(Constants.NS_XMLSCHEMA)) || (paramObject.equals(Constants.NS_DTD)));
    }
    if (paramString.equals("schema-location")) {
      return (paramObject instanceof String);
    }
    return paramString.equals("http://apache.org/xml/properties/dom/document-class-name");
  }
  
  public DOMStringList getParameterNames()
  {
    if (this.fRecognizedParameters == null)
    {
      Vector localVector = new Vector();
      localVector.add("namespaces");
      localVector.add("cdata-sections");
      localVector.add("canonical-form");
      localVector.add("namespace-declarations");
      localVector.add("entities");
      localVector.add("validate-if-schema");
      localVector.add("validate");
      localVector.add("datatype-normalization");
      localVector.add("charset-overrides-xml-encoding");
      localVector.add("check-character-normalization");
      localVector.add("supported-media-types-only");
      localVector.add("ignore-unknown-character-denormalizations");
      localVector.add("normalize-characters");
      localVector.add("well-formed");
      localVector.add("infoset");
      localVector.add("disallow-doctype");
      localVector.add("element-content-whitespace");
      localVector.add("entities");
      localVector.add("element-content-whitespace");
      localVector.add("comments");
      localVector.add("error-handler");
      localVector.add("resource-resolver");
      localVector.add("schema-location");
      localVector.add("schema-type");
      this.fRecognizedParameters = new DOMStringListImpl(localVector);
    }
    return this.fRecognizedParameters;
  }
  
  public Document parseURI(String paramString)
    throws LSException
  {
    if (this.fBusy)
    {
      localObject = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_STATE_ERR", null);
      throw new DOMException((short)11, (String)localObject);
    }
    Object localObject = new XMLInputSource(null, paramString, null);
    try
    {
      this.fBusy = true;
      parse((XMLInputSource)localObject);
      this.fBusy = false;
    }
    catch (Exception localException)
    {
      this.fBusy = false;
      if (localException != AbstractDOMParser.abort)
      {
        if (this.fErrorHandler != null)
        {
          DOMErrorImpl localDOMErrorImpl = new DOMErrorImpl();
          localDOMErrorImpl.fException = localException;
          localDOMErrorImpl.fMessage = localException.getMessage();
          localDOMErrorImpl.fSeverity = 3;
          this.fErrorHandler.getErrorHandler().handleError(localDOMErrorImpl);
        }
        throw new LSException((short)81, localException.getMessage());
      }
    }
    return getDocument();
  }
  
  public Document parse(LSInput paramLSInput)
    throws LSException
  {
    XMLInputSource localXMLInputSource = dom2xmlInputSource(paramLSInput);
    if (this.fBusy)
    {
      String str = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_STATE_ERR", null);
      throw new DOMException((short)11, str);
    }
    try
    {
      this.fBusy = true;
      parse(localXMLInputSource);
      this.fBusy = false;
    }
    catch (Exception localException)
    {
      this.fBusy = false;
      if (localException != AbstractDOMParser.abort)
      {
        if (this.fErrorHandler != null)
        {
          DOMErrorImpl localDOMErrorImpl = new DOMErrorImpl();
          localDOMErrorImpl.fException = localException;
          localDOMErrorImpl.fMessage = localException.getMessage();
          localDOMErrorImpl.fSeverity = 3;
          this.fErrorHandler.getErrorHandler().handleError(localDOMErrorImpl);
        }
        throw new LSException((short)81, localException.getMessage());
      }
    }
    return getDocument();
  }
  
  public Node parseWithContext(LSInput paramLSInput, Node paramNode, short paramShort)
    throws DOMException, LSException
  {
    throw new DOMException((short)9, "Not supported");
  }
  
  XMLInputSource dom2xmlInputSource(LSInput paramLSInput)
  {
    XMLInputSource localXMLInputSource = null;
    if (paramLSInput.getStringData() != null) {
      localXMLInputSource = new XMLInputSource(paramLSInput.getPublicId(), paramLSInput.getSystemId(), paramLSInput.getBaseURI(), new StringReader(paramLSInput.getStringData()), "UTF-16");
    } else if (paramLSInput.getCharacterStream() != null) {
      localXMLInputSource = new XMLInputSource(paramLSInput.getPublicId(), paramLSInput.getSystemId(), paramLSInput.getBaseURI(), paramLSInput.getCharacterStream(), "UTF-16");
    } else if (paramLSInput.getByteStream() != null) {
      localXMLInputSource = new XMLInputSource(paramLSInput.getPublicId(), paramLSInput.getSystemId(), paramLSInput.getBaseURI(), paramLSInput.getByteStream(), paramLSInput.getEncoding());
    } else {
      localXMLInputSource = new XMLInputSource(paramLSInput.getPublicId(), paramLSInput.getSystemId(), paramLSInput.getBaseURI());
    }
    return localXMLInputSource;
  }
  
  public boolean getAsync()
  {
    return false;
  }
  
  public boolean getBusy()
  {
    return this.fBusy;
  }
  
  public void abort()
  {
    if (this.fBusy)
    {
      this.fBusy = false;
      throw AbstractDOMParser.abort;
    }
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\parsers\DOMParserImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */