package org.apache.xerces.dom;

import java.util.Hashtable;

class LCount
{
  static Hashtable lCounts = new Hashtable();
  public int captures = 0;
  public int bubbles = 0;
  public int defaults = 0;
  
  static LCount lookup(String paramString)
  {
    LCount localLCount = (LCount)lCounts.get(paramString);
    if (localLCount == null) {
      lCounts.put(paramString, localLCount = new LCount());
    }
    return localLCount;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\LCount.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */