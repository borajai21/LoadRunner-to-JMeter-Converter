package org.apache.xerces.dom;

import org.apache.xerces.dom3.DOMImplementationList;
import org.apache.xerces.dom3.bootstrap.DOMImplementationListImpl;
import org.apache.xerces.impl.xs.XSImplementationImpl;
import org.w3c.dom.DOMImplementation;

public class DOMXSImplementationSourceImpl
  extends DOMImplementationSourceImpl
{
  public DOMImplementation getDOMImplementation(String paramString)
  {
    DOMImplementation localDOMImplementation = super.getDOMImplementation(paramString);
    if (localDOMImplementation != null) {
      return localDOMImplementation;
    }
    localDOMImplementation = PSVIDOMImplementationImpl.getDOMImplementation();
    if (testImpl(localDOMImplementation, paramString)) {
      return localDOMImplementation;
    }
    localDOMImplementation = XSImplementationImpl.getDOMImplementation();
    if (testImpl(localDOMImplementation, paramString)) {
      return localDOMImplementation;
    }
    return null;
  }
  
  public DOMImplementationList getDOMImplementationList(String paramString)
  {
    DOMImplementationListImpl localDOMImplementationListImpl = (DOMImplementationListImpl)super.getDOMImplementationList(paramString);
    DOMImplementation localDOMImplementation = PSVIDOMImplementationImpl.getDOMImplementation();
    if (testImpl(localDOMImplementation, paramString)) {
      localDOMImplementationListImpl.add(localDOMImplementation);
    }
    localDOMImplementation = XSImplementationImpl.getDOMImplementation();
    if (testImpl(localDOMImplementation, paramString)) {
      localDOMImplementationListImpl.add(localDOMImplementation);
    }
    return localDOMImplementationListImpl;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DOMXSImplementationSourceImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */