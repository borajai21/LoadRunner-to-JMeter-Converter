package org.apache.xerces.dom;

import org.w3c.dom.CDATASection;

public class CDATASectionImpl
  extends TextImpl
  implements CDATASection
{
  static final long serialVersionUID = 2372071297878177780L;
  
  public CDATASectionImpl(CoreDocumentImpl paramCoreDocumentImpl, String paramString)
  {
    super(paramCoreDocumentImpl, paramString);
  }
  
  public short getNodeType()
  {
    return 4;
  }
  
  public String getNodeName()
  {
    return "#cdata-section";
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\CDATASectionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */