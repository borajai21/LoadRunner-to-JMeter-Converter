package org.apache.xerces.dom;

import org.w3c.dom.ranges.RangeException;

public class RangeExceptionImpl
  extends RangeException
{
  public RangeExceptionImpl(short paramShort, String paramString)
  {
    super(paramShort, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\RangeExceptionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */