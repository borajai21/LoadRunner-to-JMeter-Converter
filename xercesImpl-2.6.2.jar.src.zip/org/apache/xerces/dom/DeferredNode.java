package org.apache.xerces.dom;

import org.w3c.dom.Node;

public abstract interface DeferredNode
  extends Node
{
  public static final short TYPE_NODE = 20;
  
  public abstract int getNodeIndex();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DeferredNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */