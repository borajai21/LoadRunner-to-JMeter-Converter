package org.apache.xerces.dom;

import java.io.Serializable;

class NodeListCache
  implements Serializable
{
  int fLength = -1;
  int fChildIndex = -1;
  ChildNode fChild;
  ParentNode fOwner;
  NodeListCache next;
  
  NodeListCache(ParentNode paramParentNode)
  {
    this.fOwner = paramParentNode;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\NodeListCache.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */