package org.apache.xerces.dom;

public class DeferredProcessingInstructionImpl
  extends ProcessingInstructionImpl
  implements DeferredNode
{
  static final long serialVersionUID = -4643577954293565388L;
  protected transient int fNodeIndex;
  
  DeferredProcessingInstructionImpl(DeferredDocumentImpl paramDeferredDocumentImpl, int paramInt)
  {
    super(paramDeferredDocumentImpl, null, null);
    this.fNodeIndex = paramInt;
    needsSyncData(true);
  }
  
  public int getNodeIndex()
  {
    return this.fNodeIndex;
  }
  
  protected void synchronizeData()
  {
    needsSyncData(false);
    DeferredDocumentImpl localDeferredDocumentImpl = (DeferredDocumentImpl)ownerDocument();
    this.target = localDeferredDocumentImpl.getNodeName(this.fNodeIndex);
    this.data = localDeferredDocumentImpl.getNodeValueString(this.fNodeIndex);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DeferredProcessingInstructionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */