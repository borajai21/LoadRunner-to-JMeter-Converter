package org.apache.xerces.dom;

import java.util.Vector;
import org.apache.xerces.dom3.DOMStringList;

public class DOMStringListImpl
  implements DOMStringList
{
  private Vector fStrings;
  
  public DOMStringListImpl()
  {
    this.fStrings = new Vector();
  }
  
  public DOMStringListImpl(Vector paramVector)
  {
    this.fStrings = paramVector;
  }
  
  public String item(int paramInt)
  {
    try
    {
      return (String)this.fStrings.elementAt(paramInt);
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {}
    return null;
  }
  
  public int getLength()
  {
    return this.fStrings.size();
  }
  
  public boolean contains(String paramString)
  {
    return this.fStrings.contains(paramString);
  }
  
  public void add(String paramString)
  {
    this.fStrings.add(paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DOMStringListImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */