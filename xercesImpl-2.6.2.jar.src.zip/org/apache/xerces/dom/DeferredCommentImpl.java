package org.apache.xerces.dom;

public class DeferredCommentImpl
  extends CommentImpl
  implements DeferredNode
{
  static final long serialVersionUID = 6498796371083589338L;
  protected transient int fNodeIndex;
  
  DeferredCommentImpl(DeferredDocumentImpl paramDeferredDocumentImpl, int paramInt)
  {
    super(paramDeferredDocumentImpl, null);
    this.fNodeIndex = paramInt;
    needsSyncData(true);
  }
  
  public int getNodeIndex()
  {
    return this.fNodeIndex;
  }
  
  protected void synchronizeData()
  {
    needsSyncData(false);
    DeferredDocumentImpl localDeferredDocumentImpl = (DeferredDocumentImpl)ownerDocument();
    this.data = localDeferredDocumentImpl.getNodeValueString(this.fNodeIndex);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DeferredCommentImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */