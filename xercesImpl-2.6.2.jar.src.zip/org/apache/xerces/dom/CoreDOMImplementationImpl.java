package org.apache.xerces.dom;

import org.apache.xerces.impl.RevalidationHandler;
import org.apache.xerces.parsers.DOMParserImpl;
import org.apache.xerces.util.XMLChar;
import org.apache.xml.serialize.DOMSerializerImpl;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSSerializer;

public class CoreDOMImplementationImpl
  implements DOMImplementation, DOMImplementationLS
{
  private static final int SIZE = 2;
  private RevalidationHandler[] validators = new RevalidationHandler[2];
  private int freeValidatorIndex = -1;
  private int currentSize = 2;
  private int docAndDoctypeCounter = 0;
  static CoreDOMImplementationImpl singleton = new CoreDOMImplementationImpl();
  
  public static DOMImplementation getDOMImplementation()
  {
    return singleton;
  }
  
  public boolean hasFeature(String paramString1, String paramString2)
  {
    int i = (paramString2 == null) || (paramString2.length() == 0) ? 1 : 0;
    if (paramString1.startsWith("+")) {
      paramString1 = paramString1.substring(1);
    }
    if (((paramString1.equalsIgnoreCase("XPath")) || (paramString1.equalsIgnoreCase("+XPath"))) && ((i != 0) || (paramString2.equals("3.0"))))
    {
      try
      {
        Class localClass = ObjectFactory.findProviderClass("org.apache.xpath.domapi.XPathEvaluatorImpl", ObjectFactory.findClassLoader(), true);
      }
      catch (Exception localException)
      {
        return false;
      }
      return true;
    }
    return ((paramString1.equalsIgnoreCase("Core")) && ((i != 0) || (paramString2.equals("1.0")) || (paramString2.equals("2.0")) || (paramString2.equals("3.0")))) || ((paramString1.equalsIgnoreCase("XML")) && ((i != 0) || (paramString2.equals("1.0")) || (paramString2.equals("2.0")) || (paramString2.equals("3.0")))) || ((paramString1.equalsIgnoreCase("LS")) && ((i != 0) || (paramString2.equals("3.0"))));
  }
  
  public DocumentType createDocumentType(String paramString1, String paramString2, String paramString3)
  {
    checkQName(paramString1);
    return new DocumentTypeImpl(null, paramString1, paramString2, paramString3);
  }
  
  final void checkQName(String paramString)
  {
    int i = paramString.indexOf(':');
    int j = paramString.lastIndexOf(':');
    int k = paramString.length();
    if ((i == 0) || (i == k - 1) || (j != i))
    {
      String str1 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "NAMESPACE_ERR", null);
      throw new DOMException((short)14, str1);
    }
    int m = 0;
    String str4;
    if (i > 0)
    {
      if (!XMLChar.isNCNameStart(paramString.charAt(m)))
      {
        String str2 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_CHARACTER_ERR", null);
        throw new DOMException((short)5, str2);
      }
      for (int n = 1; n < i; n++) {
        if (!XMLChar.isNCName(paramString.charAt(n)))
        {
          str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_CHARACTER_ERR", null);
          throw new DOMException((short)5, str4);
        }
      }
      m = i + 1;
    }
    if (!XMLChar.isNCNameStart(paramString.charAt(m)))
    {
      String str3 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_CHARACTER_ERR", null);
      throw new DOMException((short)5, str3);
    }
    for (int i1 = m + 1; i1 < k; i1++) {
      if (!XMLChar.isNCName(paramString.charAt(i1)))
      {
        str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INVALID_CHARACTER_ERR", null);
        throw new DOMException((short)5, str4);
      }
    }
  }
  
  public Document createDocument(String paramString1, String paramString2, DocumentType paramDocumentType)
    throws DOMException
  {
    if ((paramDocumentType != null) && (paramDocumentType.getOwnerDocument() != null))
    {
      localObject = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "WRONG_DOCUMENT_ERR", null);
      throw new DOMException((short)4, (String)localObject);
    }
    Object localObject = new CoreDocumentImpl(paramDocumentType);
    Element localElement = ((CoreDocumentImpl)localObject).createElementNS(paramString1, paramString2);
    ((NodeImpl)localObject).appendChild(localElement);
    return (Document)localObject;
  }
  
  public Object getFeature(String paramString1, String paramString2)
  {
    if (singleton.hasFeature(paramString1, paramString2)) {
      return singleton;
    }
    return null;
  }
  
  public LSParser createLSParser(short paramShort, String paramString)
    throws DOMException
  {
    if ((paramShort != 1) || ((paramString != null) && (!"http://www.w3.org/2001/XMLSchema".equals(paramString)) && (!"http://www.w3.org/TR/REC-xml".equals(paramString))))
    {
      String str = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "NOT_SUPPORTED_ERR", null);
      throw new DOMException((short)9, str);
    }
    if ((paramString != null) && (paramString.equals("http://www.w3.org/TR/REC-xml"))) {
      return new DOMParserImpl("org.apache.xerces.parsers.DTDConfiguration", paramString);
    }
    return new DOMParserImpl("org.apache.xerces.parsers.XML11Configuration", paramString);
  }
  
  public LSSerializer createLSSerializer()
  {
    return new DOMSerializerImpl();
  }
  
  public LSInput createLSInput()
  {
    return new DOMInputImpl();
  }
  
  synchronized RevalidationHandler getValidator(String paramString)
  {
    if (this.freeValidatorIndex < 0) {
      return (RevalidationHandler)ObjectFactory.newInstance("org.apache.xerces.impl.xs.XMLSchemaValidator", ObjectFactory.findClassLoader(), true);
    }
    RevalidationHandler localRevalidationHandler = this.validators[this.freeValidatorIndex];
    this.validators[(this.freeValidatorIndex--)] = null;
    return localRevalidationHandler;
  }
  
  synchronized void releaseValidator(String paramString, RevalidationHandler paramRevalidationHandler)
  {
    this.freeValidatorIndex += 1;
    if (this.validators.length == this.freeValidatorIndex)
    {
      this.currentSize += 2;
      RevalidationHandler[] arrayOfRevalidationHandler = new RevalidationHandler[this.currentSize];
      System.arraycopy(this.validators, 0, arrayOfRevalidationHandler, 0, this.validators.length);
      this.validators = arrayOfRevalidationHandler;
    }
    this.validators[this.freeValidatorIndex] = paramRevalidationHandler;
  }
  
  protected synchronized int assignDocumentNumber()
  {
    return ++this.docAndDoctypeCounter;
  }
  
  protected synchronized int assignDocTypeNumber()
  {
    return ++this.docAndDoctypeCounter;
  }
  
  public LSOutput createLSOutput()
  {
    return new DOMOutputImpl();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\CoreDOMImplementationImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */