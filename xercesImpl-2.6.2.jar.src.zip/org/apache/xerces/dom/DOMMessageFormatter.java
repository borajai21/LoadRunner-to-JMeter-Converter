package org.apache.xerces.dom;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class DOMMessageFormatter
{
  public static final String XML_DOMAIN = "http://www.w3.org/TR/1998/REC-xml-19980210";
  public static final String DOM_DOMAIN = "http://www.w3.org/dom/DOMTR";
  public static final String SERIALIZER_DOMAIN = "http://apache.org/xml/serializer";
  
  public static String formatMessage(String paramString1, String paramString2, Object[] paramArrayOfObject)
    throws MissingResourceException
  {
    ResourceBundle localResourceBundle = null;
    if (paramString1.equals("http://www.w3.org/dom/DOMTR")) {
      localResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.DOMMessages");
    } else if (paramString1.equals("http://apache.org/xml/serializer")) {
      localResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.XMLSerializerMessages");
    } else if (paramString1.equals("http://www.w3.org/TR/1998/REC-xml-19980210")) {
      localResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.XMLMessages");
    } else {
      throw new MissingResourceException("Unknown domain" + paramString1, null, paramString2);
    }
    String str;
    try
    {
      str = paramString2 + ": " + localResourceBundle.getString(paramString2);
      if (paramArrayOfObject != null) {
        try
        {
          str = MessageFormat.format(str, paramArrayOfObject);
        }
        catch (Exception localException)
        {
          str = localResourceBundle.getString("FormatFailed");
          str = str + " " + localResourceBundle.getString(paramString2);
        }
      }
    }
    catch (MissingResourceException localMissingResourceException)
    {
      str = localResourceBundle.getString("BadMessageKey");
      throw new MissingResourceException(paramString2, str, paramString2);
    }
    if (str == null)
    {
      str = paramString2;
      if (paramArrayOfObject.length > 0)
      {
        StringBuffer localStringBuffer = new StringBuffer(str);
        localStringBuffer.append('?');
        for (int i = 0; i < paramArrayOfObject.length; i++)
        {
          if (i > 0) {
            localStringBuffer.append('&');
          }
          localStringBuffer.append(String.valueOf(paramArrayOfObject[i]));
        }
      }
    }
    return str;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DOMMessageFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */