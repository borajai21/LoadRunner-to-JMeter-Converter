package org.apache.xerces.dom;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class TextImpl
  extends CharacterDataImpl
  implements CharacterData, Text
{
  static final long serialVersionUID = -5294980852957403469L;
  
  public TextImpl() {}
  
  public TextImpl(CoreDocumentImpl paramCoreDocumentImpl, String paramString)
  {
    super(paramCoreDocumentImpl, paramString);
  }
  
  public void setValues(CoreDocumentImpl paramCoreDocumentImpl, String paramString)
  {
    this.flags = 0;
    this.nextSibling = null;
    this.previousSibling = null;
    setOwnerDocument(paramCoreDocumentImpl);
    this.data = paramString;
  }
  
  public short getNodeType()
  {
    return 3;
  }
  
  public String getNodeName()
  {
    return "#text";
  }
  
  public void setIgnorableWhitespace(boolean paramBoolean)
  {
    if (needsSyncData()) {
      synchronizeData();
    }
    isIgnorableWhitespace(paramBoolean);
  }
  
  public boolean isElementContentWhitespace()
  {
    if (needsSyncData()) {
      synchronizeData();
    }
    return internalIsIgnorableWhitespace();
  }
  
  public String getWholeText()
  {
    if (needsSyncData()) {
      synchronizeData();
    }
    if (this.nextSibling == null) {
      return this.data;
    }
    if (this.fBufferStr == null) {
      this.fBufferStr = new StringBuffer();
    } else {
      this.fBufferStr.setLength(0);
    }
    if ((this.data != null) && (this.data.length() != 0)) {
      this.fBufferStr.append(this.data);
    }
    getWholeText(this.nextSibling, this.fBufferStr);
    return this.fBufferStr.toString();
  }
  
  private boolean getWholeText(Node paramNode, StringBuffer paramStringBuffer)
  {
    while (paramNode != null)
    {
      int i = paramNode.getNodeType();
      if (i == 5)
      {
        if (getWholeText(paramNode.getFirstChild(), paramStringBuffer)) {
          return true;
        }
      }
      else if ((i == 3) || (i == 4)) {
        ((NodeImpl)paramNode).getTextContent(paramStringBuffer);
      } else {
        return true;
      }
      paramNode = paramNode.getNextSibling();
    }
    return false;
  }
  
  public Text replaceWholeText(String paramString)
    throws DOMException
  {
    if (needsSyncData()) {
      synchronizeData();
    }
    if (!canModify(this.nextSibling)) {
      throw new DOMException((short)7, DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "NO_MODIFICATION_ALLOWED_ERR", null));
    }
    Node localNode = getParentNode();
    if (((paramString == null) || (paramString.length() == 0)) && (localNode != null))
    {
      localNode.removeChild(this);
      return null;
    }
    Object localObject1 = null;
    if (isReadOnly())
    {
      localObject2 = ownerDocument().createTextNode(paramString);
      if (localNode != null)
      {
        localNode.insertBefore((Node)localObject2, this);
        localNode.removeChild(this);
        localObject1 = localObject2;
      }
      else
      {
        return (Text)localObject2;
      }
    }
    else
    {
      setData(paramString);
      localObject1 = this;
    }
    for (Object localObject2 = ((Node)localObject1).getNextSibling(); localObject2 != null; localObject2 = ((Node)localObject1).getNextSibling()) {
      localNode.removeChild((Node)localObject2);
    }
    return (Text)localObject1;
  }
  
  private boolean canModify(Node paramNode)
  {
    while (paramNode != null)
    {
      int i = paramNode.getNodeType();
      if (i == 5)
      {
        if (!canModify(paramNode.getFirstChild())) {
          return false;
        }
      }
      else if ((i != 3) && (i != 4)) {
        return false;
      }
      paramNode = paramNode.getNextSibling();
    }
    return true;
  }
  
  public boolean isIgnorableWhitespace()
  {
    if (needsSyncData()) {
      synchronizeData();
    }
    return internalIsIgnorableWhitespace();
  }
  
  public Text splitText(int paramInt)
    throws DOMException
  {
    if (isReadOnly()) {
      throw new DOMException((short)7, DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "NO_MODIFICATION_ALLOWED_ERR", null));
    }
    if (needsSyncData()) {
      synchronizeData();
    }
    if ((paramInt < 0) || (paramInt > this.data.length())) {
      throw new DOMException((short)1, DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "INDEX_SIZE_ERR", null));
    }
    Text localText = getOwnerDocument().createTextNode(this.data.substring(paramInt));
    setNodeValue(this.data.substring(0, paramInt));
    Node localNode = getParentNode();
    if (localNode != null) {
      localNode.insertBefore(localText, this.nextSibling);
    }
    return localText;
  }
  
  public void replaceData(String paramString)
  {
    this.data = paramString;
  }
  
  public String removeData()
  {
    String str = this.data;
    this.data = "";
    return str;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\TextImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */