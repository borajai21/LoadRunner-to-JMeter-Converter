package org.apache.xerces.dom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import org.apache.xerces.dom3.DOMConfiguration;
import org.apache.xerces.dom3.DOMErrorHandler;
import org.apache.xerces.dom3.DOMStringList;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.msg.XMLMessageFormatter;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.DOMErrorHandlerWrapper;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.ls.LSResourceResolver;

public class DOMConfigurationImpl
  extends ParserConfigurationSettings
  implements XMLParserConfiguration, DOMConfiguration
{
  protected static final String XERCES_VALIDATION = "http://xml.org/sax/features/validation";
  protected static final String XERCES_NAMESPACES = "http://xml.org/sax/features/namespaces";
  protected static final String SCHEMA = "http://apache.org/xml/features/validation/schema";
  protected static final String DYNAMIC_VALIDATION = "http://apache.org/xml/features/validation/dynamic";
  protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
  protected static final String SEND_PSVI = "http://apache.org/xml/features/validation/schema/augment-psvi";
  protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
  protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
  protected static final String XML_STRING = "http://xml.org/sax/properties/xml-string";
  protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
  protected static final String GRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
  protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
  protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
  protected static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
  protected static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
  protected static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
  XMLDocumentHandler fDocumentHandler;
  protected short features = 0;
  protected static final short NAMESPACES = 1;
  protected static final short DTNORMALIZATION = 2;
  protected static final short ENTITIES = 4;
  protected static final short CDATA = 8;
  protected static final short SPLITCDATA = 16;
  protected static final short COMMENTS = 32;
  protected static final short VALIDATE = 64;
  protected static final short PSVI = 128;
  protected static final short WELLFORMED = 256;
  protected static final short INFOSET_TRUE_PARAMS = 289;
  protected static final short INFOSET_FALSE_PARAMS = 14;
  protected static final short INFOSET_MASK = 303;
  protected SymbolTable fSymbolTable;
  protected ArrayList fComponents;
  protected ValidationManager fValidationManager;
  protected Locale fLocale;
  protected XMLErrorReporter fErrorReporter;
  protected final DOMErrorHandlerWrapper fErrorHandlerWrapper = new DOMErrorHandlerWrapper();
  private DOMStringList fRecognizedParameters;
  
  protected DOMConfigurationImpl()
  {
    this(null, null);
  }
  
  protected DOMConfigurationImpl(SymbolTable paramSymbolTable)
  {
    this(paramSymbolTable, null);
  }
  
  protected DOMConfigurationImpl(SymbolTable paramSymbolTable, XMLComponentManager paramXMLComponentManager)
  {
    super(paramXMLComponentManager);
    this.fRecognizedFeatures = new ArrayList();
    this.fRecognizedProperties = new ArrayList();
    this.fFeatures = new Hashtable();
    this.fProperties = new Hashtable();
    String[] arrayOfString1 = { "http://xml.org/sax/features/validation", "http://xml.org/sax/features/namespaces", "http://apache.org/xml/features/validation/schema", "http://apache.org/xml/features/validation/dynamic", "http://apache.org/xml/features/validation/schema/normalized-value", "http://apache.org/xml/features/validation/schema/augment-psvi" };
    addRecognizedFeatures(arrayOfString1);
    setFeature("http://xml.org/sax/features/validation", false);
    setFeature("http://apache.org/xml/features/validation/schema", false);
    setFeature("http://apache.org/xml/features/validation/dynamic", false);
    setFeature("http://apache.org/xml/features/validation/schema/normalized-value", false);
    setFeature("http://xml.org/sax/features/namespaces", true);
    setFeature("http://apache.org/xml/features/validation/schema/augment-psvi", true);
    String[] arrayOfString2 = { "http://xml.org/sax/properties/xml-string", "http://apache.org/xml/properties/internal/symbol-table", "http://apache.org/xml/properties/internal/error-handler", "http://apache.org/xml/properties/internal/entity-resolver", "http://apache.org/xml/properties/internal/error-reporter", "http://apache.org/xml/properties/internal/entity-manager", "http://apache.org/xml/properties/internal/validation-manager", "http://apache.org/xml/properties/internal/grammar-pool", "http://java.sun.com/xml/jaxp/properties/schemaSource", "http://java.sun.com/xml/jaxp/properties/schemaLanguage" };
    addRecognizedProperties(arrayOfString2);
    this.features = ((short)(this.features | 0x1));
    this.features = ((short)(this.features | 0x4));
    this.features = ((short)(this.features | 0x20));
    this.features = ((short)(this.features | 0x8));
    this.features = ((short)(this.features | 0x10));
    this.features = ((short)(this.features | 0x100));
    if (paramSymbolTable == null) {
      paramSymbolTable = new SymbolTable();
    }
    this.fSymbolTable = paramSymbolTable;
    this.fComponents = new ArrayList();
    setProperty("http://apache.org/xml/properties/internal/symbol-table", this.fSymbolTable);
    this.fErrorReporter = new XMLErrorReporter();
    setProperty("http://apache.org/xml/properties/internal/error-reporter", this.fErrorReporter);
    addComponent(this.fErrorReporter);
    XMLEntityManager localXMLEntityManager = new XMLEntityManager();
    setProperty("http://apache.org/xml/properties/internal/entity-manager", localXMLEntityManager);
    addComponent(localXMLEntityManager);
    this.fValidationManager = createValidationManager();
    setProperty("http://apache.org/xml/properties/internal/validation-manager", this.fValidationManager);
    Object localObject;
    if (this.fErrorReporter.getMessageFormatter("http://www.w3.org/TR/1998/REC-xml-19980210") == null)
    {
      localObject = new XMLMessageFormatter();
      this.fErrorReporter.putMessageFormatter("http://www.w3.org/TR/1998/REC-xml-19980210", (MessageFormatter)localObject);
      this.fErrorReporter.putMessageFormatter("http://www.w3.org/TR/1999/REC-xml-names-19990114", (MessageFormatter)localObject);
    }
    if (this.fErrorReporter.getMessageFormatter("http://www.w3.org/TR/xml-schema-1") == null)
    {
      localObject = null;
      try
      {
        localObject = (MessageFormatter)ObjectFactory.newInstance("org.apache.xerces.impl.xs.XSMessageFormatter", ObjectFactory.findClassLoader(), true);
      }
      catch (Exception localException) {}
      if (localObject != null) {
        this.fErrorReporter.putMessageFormatter("http://www.w3.org/TR/xml-schema-1", (MessageFormatter)localObject);
      }
    }
    try
    {
      setLocale(Locale.getDefault());
    }
    catch (XNIException localXNIException) {}
  }
  
  public void parse(XMLInputSource paramXMLInputSource)
    throws XNIException, IOException
  {}
  
  public void setDocumentHandler(XMLDocumentHandler paramXMLDocumentHandler)
  {
    this.fDocumentHandler = paramXMLDocumentHandler;
  }
  
  public XMLDocumentHandler getDocumentHandler()
  {
    return this.fDocumentHandler;
  }
  
  public void setDTDHandler(XMLDTDHandler paramXMLDTDHandler) {}
  
  public XMLDTDHandler getDTDHandler()
  {
    return null;
  }
  
  public void setDTDContentModelHandler(XMLDTDContentModelHandler paramXMLDTDContentModelHandler) {}
  
  public XMLDTDContentModelHandler getDTDContentModelHandler()
  {
    return null;
  }
  
  public void setEntityResolver(XMLEntityResolver paramXMLEntityResolver)
  {
    if (paramXMLEntityResolver != null) {
      this.fProperties.put("http://apache.org/xml/properties/internal/entity-resolver", paramXMLEntityResolver);
    }
  }
  
  public XMLEntityResolver getEntityResolver()
  {
    return (XMLEntityResolver)this.fProperties.get("http://apache.org/xml/properties/internal/entity-resolver");
  }
  
  public void setErrorHandler(XMLErrorHandler paramXMLErrorHandler)
  {
    if (paramXMLErrorHandler != null) {
      this.fProperties.put("http://apache.org/xml/properties/internal/error-handler", paramXMLErrorHandler);
    }
  }
  
  public XMLErrorHandler getErrorHandler()
  {
    return (XMLErrorHandler)this.fProperties.get("http://apache.org/xml/properties/internal/error-handler");
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
    throws XMLConfigurationException
  {
    super.setFeature(paramString, paramBoolean);
  }
  
  public void setProperty(String paramString, Object paramObject)
    throws XMLConfigurationException
  {
    super.setProperty(paramString, paramObject);
  }
  
  public void setLocale(Locale paramLocale)
    throws XNIException
  {
    this.fLocale = paramLocale;
    this.fErrorReporter.setLocale(paramLocale);
  }
  
  public Locale getLocale()
  {
    return this.fLocale;
  }
  
  public void setParameter(String paramString, Object paramObject)
    throws DOMException
  {
    String str5;
    if ((paramObject instanceof Boolean))
    {
      boolean bool = ((Boolean)paramObject).booleanValue();
      if (paramString.equals("comments"))
      {
        this.features = (bool ? (short)(this.features | 0x20) : (short)(this.features & 0xFFFFFFDF));
      }
      else if (paramString.equals("datatype-normalization"))
      {
        setFeature("http://apache.org/xml/features/validation/schema/normalized-value", bool);
        this.features = (bool ? (short)(this.features | 0x2) : (short)(this.features & 0xFFFFFFFD));
      }
      else if (paramString.equals("namespaces"))
      {
        this.features = (bool ? (short)(this.features | 0x1) : (short)(this.features & 0xFFFFFFFE));
      }
      else if (paramString.equals("cdata-sections"))
      {
        this.features = (bool ? (short)(this.features | 0x8) : (short)(this.features & 0xFFFFFFF7));
      }
      else if (paramString.equals("entities"))
      {
        this.features = (bool ? (short)(this.features | 0x4) : (short)(this.features & 0xFFFFFFFB));
      }
      else if (paramString.equals("split-cdata-sections"))
      {
        this.features = (bool ? (short)(this.features | 0x10) : (short)(this.features & 0xFFFFFFEF));
      }
      else if (paramString.equals("validate"))
      {
        this.features = (bool ? (short)(this.features | 0x40) : (short)(this.features & 0xFFFFFFBF));
      }
      else if (paramString.equals("well-formed"))
      {
        this.features = (bool ? (short)(this.features | 0x100) : (short)(this.features & 0xFEFF));
      }
      else if (paramString.equals("infoset"))
      {
        if (bool)
        {
          this.features = ((short)(this.features | 0x121));
          this.features = ((short)(this.features & 0xFFFFFFF1));
          setFeature("http://apache.org/xml/features/validation/schema/normalized-value", false);
        }
      }
      else if ((paramString.equals("normalize-characters")) || (paramString.equals("canonical-form")) || (paramString.equals("validate-if-schema")) || (paramString.equals("check-character-normalization")))
      {
        if (bool)
        {
          str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
          throw new DOMException((short)9, str5);
        }
      }
      else if ((paramString.equals("namespace-declarations")) || (paramString.equals("element-content-whitespace")))
      {
        if (!bool)
        {
          str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
          throw new DOMException((short)9, str5);
        }
      }
      else if (paramString.equals("http://apache.org/xml/features/validation/schema/augment-psvi"))
      {
        if (!bool)
        {
          str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
          throw new DOMException((short)9, str5);
        }
      }
      else if (paramString.equals("psvi"))
      {
        this.features = (bool ? (short)(this.features | 0x80) : (short)(this.features & 0xFF7F));
      }
      else
      {
        str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
        throw new DOMException((short)8, str5);
      }
    }
    else if (paramString.equals("error-handler"))
    {
      if ((paramObject instanceof DOMErrorHandler))
      {
        this.fErrorHandlerWrapper.setErrorHandler((DOMErrorHandler)paramObject);
        setErrorHandler(this.fErrorHandlerWrapper);
      }
      else
      {
        String str1 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
        throw new DOMException((short)9, str1);
      }
    }
    else
    {
      String str2;
      if (paramString.equals("resource-resolver"))
      {
        if ((paramObject instanceof LSResourceResolver))
        {
          try
          {
            setEntityResolver(new DOMEntityResolverWrapper((LSResourceResolver)paramObject));
          }
          catch (XMLConfigurationException localXMLConfigurationException1) {}
        }
        else
        {
          str2 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
          throw new DOMException((short)9, str2);
        }
      }
      else
      {
        String str3;
        if (paramString.equals("schema-location"))
        {
          if ((paramObject instanceof String))
          {
            try
            {
              str2 = (String)getProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
              if (str2 == Constants.NS_XMLSCHEMA)
              {
                setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", paramObject);
              }
              else
              {
                str5 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
                throw new DOMException((short)9, str5);
              }
            }
            catch (XMLConfigurationException localXMLConfigurationException2) {}
          }
          else
          {
            str3 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
            throw new DOMException((short)9, str3);
          }
        }
        else
        {
          String str4;
          if (paramString.equals("schema-type"))
          {
            if ((paramObject instanceof String))
            {
              try
              {
                if (paramObject.equals(Constants.NS_XMLSCHEMA))
                {
                  setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_XMLSCHEMA);
                }
                else if (paramObject.equals(Constants.NS_DTD))
                {
                  str3 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_SUPPORTED", new Object[] { paramString });
                  throw new DOMException((short)9, str3);
                }
              }
              catch (XMLConfigurationException localXMLConfigurationException3) {}
            }
            else
            {
              str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
              throw new DOMException((short)9, str4);
            }
          }
          else if (paramString.equals("http://apache.org/xml/properties/internal/symbol-table"))
          {
            if ((paramObject instanceof SymbolTable))
            {
              setProperty("http://apache.org/xml/properties/internal/symbol-table", paramObject);
            }
            else
            {
              str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
              throw new DOMException((short)9, str4);
            }
          }
          else if (paramString.equals("http://apache.org/xml/properties/internal/grammar-pool"))
          {
            if ((paramObject instanceof XMLGrammarPool))
            {
              setProperty("http://apache.org/xml/properties/internal/grammar-pool", paramObject);
            }
            else
            {
              str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "TYPE_MISMATCH_ERR", new Object[] { paramString });
              throw new DOMException((short)9, str4);
            }
          }
          else
          {
            str4 = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
            throw new DOMException((short)8, str4);
          }
        }
      }
    }
  }
  
  public Object getParameter(String paramString)
    throws DOMException
  {
    if (paramString.equals("comments")) {
      return (this.features & 0x20) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("namespaces")) {
      return (this.features & 0x1) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("datatype-normalization")) {
      return (this.features & 0x2) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("cdata-sections")) {
      return (this.features & 0x8) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("entities")) {
      return (this.features & 0x4) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("split-cdata-sections")) {
      return (this.features & 0x10) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("validate")) {
      return (this.features & 0x40) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("well-formed")) {
      return (this.features & 0x100) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if (paramString.equals("infoset")) {
      return (this.features & 0x12F) == 289 ? Boolean.TRUE : Boolean.FALSE;
    }
    if ((paramString.equals("normalize-characters")) || (paramString.equals("canonical-form")) || (paramString.equals("validate-if-schema")) || (paramString.equals("check-character-normalization"))) {
      return Boolean.FALSE;
    }
    if (paramString.equals("http://apache.org/xml/features/validation/schema/augment-psvi")) {
      return Boolean.TRUE;
    }
    if (paramString.equals("psvi")) {
      return (this.features & 0x80) != 0 ? Boolean.TRUE : Boolean.FALSE;
    }
    if ((paramString.equals("namespace-declarations")) || (paramString.equals("element-content-whitespace"))) {
      return Boolean.TRUE;
    }
    if (paramString.equals("error-handler")) {
      return this.fErrorHandlerWrapper.getErrorHandler();
    }
    if (paramString.equals("resource-resolver"))
    {
      localObject = getEntityResolver();
      if ((localObject != null) && ((localObject instanceof DOMEntityResolverWrapper))) {
        return ((DOMEntityResolverWrapper)localObject).getEntityResolver();
      }
      return null;
    }
    if (paramString.equals("schema-type")) {
      return getProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
    }
    if (paramString.equals("schema-location")) {
      return getProperty("http://java.sun.com/xml/jaxp/properties/schemaSource");
    }
    if (paramString.equals("http://apache.org/xml/properties/internal/symbol-table")) {
      return getProperty("http://apache.org/xml/properties/internal/symbol-table");
    }
    if (paramString.equals("http://apache.org/xml/properties/internal/grammar-pool")) {
      return getProperty("http://apache.org/xml/properties/internal/grammar-pool");
    }
    Object localObject = DOMMessageFormatter.formatMessage("http://www.w3.org/dom/DOMTR", "FEATURE_NOT_FOUND", new Object[] { paramString });
    throw new DOMException((short)8, (String)localObject);
  }
  
  public boolean canSetParameter(String paramString, Object paramObject)
  {
    if (paramObject == null) {
      return true;
    }
    if ((paramObject instanceof Boolean))
    {
      if ((paramString.equals("comments")) || (paramString.equals("datatype-normalization")) || (paramString.equals("cdata-sections")) || (paramString.equals("entities")) || (paramString.equals("split-cdata-sections")) || (paramString.equals("namespaces")) || (paramString.equals("validate")) || (paramString.equals("well-formed")) || (paramString.equals("infoset"))) {
        return true;
      }
      if ((paramString.equals("normalize-characters")) || (paramString.equals("canonical-form")) || (paramString.equals("validate-if-schema")) || (paramString.equals("check-character-normalization"))) {
        return !paramObject.equals(Boolean.TRUE);
      }
      if ((paramString.equals("namespace-declarations")) || (paramString.equals("element-content-whitespace")) || (paramString.equals("http://apache.org/xml/features/validation/schema/augment-psvi"))) {
        return paramObject.equals(Boolean.TRUE);
      }
      return false;
    }
    if (paramString.equals("error-handler")) {
      return (paramObject instanceof DOMErrorHandler);
    }
    if (paramString.equals("resource-resolver")) {
      return (paramObject instanceof LSResourceResolver);
    }
    if (paramString.equals("schema-location")) {
      return (paramObject instanceof String);
    }
    if (paramString.equals("schema-type")) {
      return ((paramObject instanceof String)) && (paramObject.equals(Constants.NS_XMLSCHEMA));
    }
    if (paramString.equals("http://apache.org/xml/properties/internal/symbol-table")) {
      return (paramObject instanceof SymbolTable);
    }
    if (paramString.equals("http://apache.org/xml/properties/internal/grammar-pool")) {
      return (paramObject instanceof XMLGrammarPool);
    }
    return false;
  }
  
  public DOMStringList getParameterNames()
  {
    if (this.fRecognizedParameters == null)
    {
      Vector localVector = new Vector();
      localVector.add("comments");
      localVector.add("datatype-normalization");
      localVector.add("cdata-sections");
      localVector.add("entities");
      localVector.add("split-cdata-sections");
      localVector.add("namespaces");
      localVector.add("validate");
      localVector.add("infoset");
      localVector.add("normalize-characters");
      localVector.add("canonical-form");
      localVector.add("validate-if-schema");
      localVector.add("check-character-normalization");
      localVector.add("well-formed");
      localVector.add("namespace-declarations");
      localVector.add("element-content-whitespace");
      localVector.add("error-handler");
      localVector.add("schema-type");
      localVector.add("schema-location");
      localVector.add("resource-resolver");
      localVector.addAll(this.fRecognizedFeatures);
      localVector.addAll(this.fRecognizedProperties);
      this.fRecognizedParameters = new DOMStringListImpl(localVector);
    }
    return this.fRecognizedParameters;
  }
  
  protected void reset()
    throws XNIException
  {
    if (this.fValidationManager != null) {
      this.fValidationManager.reset();
    }
    int i = this.fComponents.size();
    for (int j = 0; j < i; j++)
    {
      XMLComponent localXMLComponent = (XMLComponent)this.fComponents.get(j);
      localXMLComponent.reset(this);
    }
  }
  
  protected void checkProperty(String paramString)
    throws XMLConfigurationException
  {
    if (paramString.startsWith("http://xml.org/sax/properties/"))
    {
      int i = paramString.length() - "http://xml.org/sax/properties/".length();
      if ((i == "xml-string".length()) && (paramString.endsWith("xml-string")))
      {
        short s = 1;
        throw new XMLConfigurationException(s, paramString);
      }
    }
    super.checkProperty(paramString);
  }
  
  protected void addComponent(XMLComponent paramXMLComponent)
  {
    if (this.fComponents.contains(paramXMLComponent)) {
      return;
    }
    this.fComponents.add(paramXMLComponent);
    String[] arrayOfString1 = paramXMLComponent.getRecognizedFeatures();
    addRecognizedFeatures(arrayOfString1);
    String[] arrayOfString2 = paramXMLComponent.getRecognizedProperties();
    addRecognizedProperties(arrayOfString2);
  }
  
  protected ValidationManager createValidationManager()
  {
    return new ValidationManager();
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom\DOMConfigurationImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */