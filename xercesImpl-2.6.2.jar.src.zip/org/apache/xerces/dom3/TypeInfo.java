package org.apache.xerces.dom3;

public abstract interface TypeInfo
{
  public static final int DERIVATION_RESTRICTION = 1;
  public static final int DERIVATION_EXTENSION = 2;
  public static final int DERIVATION_UNION = 4;
  public static final int DERIVATION_LIST = 8;
  
  public abstract String getTypeName();
  
  public abstract String getTypeNamespace();
  
  public abstract boolean isDerivedFrom(String paramString1, String paramString2, int paramInt);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\TypeInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */