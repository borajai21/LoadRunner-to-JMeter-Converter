package org.apache.xerces.dom3;

public abstract interface DOMStringList
{
  public abstract String item(int paramInt);
  
  public abstract int getLength();
  
  public abstract boolean contains(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\DOMStringList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */