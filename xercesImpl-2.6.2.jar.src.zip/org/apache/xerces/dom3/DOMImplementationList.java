package org.apache.xerces.dom3;

import org.w3c.dom.DOMImplementation;

public abstract interface DOMImplementationList
{
  public abstract DOMImplementation item(int paramInt);
  
  public abstract int getLength();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\DOMImplementationList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */