package org.apache.xerces.dom3;

import org.w3c.dom.DOMException;

public abstract interface DOMConfiguration
{
  public abstract void setParameter(String paramString, Object paramObject)
    throws DOMException;
  
  public abstract Object getParameter(String paramString)
    throws DOMException;
  
  public abstract boolean canSetParameter(String paramString, Object paramObject);
  
  public abstract DOMStringList getParameterNames();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\DOMConfiguration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */