package org.apache.xerces.dom3.bootstrap;

import java.util.Vector;
import org.apache.xerces.dom3.DOMImplementationList;
import org.w3c.dom.DOMImplementation;

public class DOMImplementationListImpl
  implements DOMImplementationList
{
  private Vector sources = new Vector();
  
  public DOMImplementation item(int paramInt)
  {
    try
    {
      return (DOMImplementation)this.sources.elementAt(paramInt);
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {}
    return null;
  }
  
  public int getLength()
  {
    return this.sources.size();
  }
  
  public void add(DOMImplementation paramDOMImplementation)
  {
    this.sources.add(paramDOMImplementation);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\bootstrap\DOMImplementationListImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */