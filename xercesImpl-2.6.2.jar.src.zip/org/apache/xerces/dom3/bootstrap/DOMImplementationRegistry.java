package org.apache.xerces.dom3.bootstrap;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.StringTokenizer;
import java.util.Vector;
import org.apache.xerces.dom3.DOMImplementationList;
import org.apache.xerces.dom3.DOMImplementationSource;
import org.w3c.dom.DOMImplementation;

public class DOMImplementationRegistry
{
  public static final String PROPERTY = "org.w3c.dom.DOMImplementationSourceList";
  private Vector _sources;
  
  private DOMImplementationRegistry() {}
  
  private DOMImplementationRegistry(Vector paramVector)
  {
    this._sources = paramVector;
  }
  
  public static DOMImplementationRegistry newInstance()
    throws ClassNotFoundException, InstantiationException, IllegalAccessException
  {
    Vector localVector = new Vector();
    String str1 = System.getProperty("org.w3c.dom.DOMImplementationSourceList");
    if (str1 != null)
    {
      StringTokenizer localStringTokenizer = new StringTokenizer(str1);
      while (localStringTokenizer.hasMoreTokens())
      {
        String str2 = localStringTokenizer.nextToken();
        Object localObject = getClass(str2).newInstance();
        localVector.add(localObject);
      }
    }
    return new DOMImplementationRegistry(localVector);
  }
  
  public DOMImplementation getDOMImplementation(String paramString)
    throws ClassNotFoundException, InstantiationException, IllegalAccessException, ClassCastException
  {
    int i = this._sources.size();
    Object localObject = null;
    for (int j = 0; j < i; j++)
    {
      DOMImplementationSource localDOMImplementationSource = (DOMImplementationSource)this._sources.get(j);
      DOMImplementation localDOMImplementation = localDOMImplementationSource.getDOMImplementation(paramString);
      if (localDOMImplementation != null) {
        return localDOMImplementation;
      }
    }
    return null;
  }
  
  public DOMImplementationList getDOMImplementationList(String paramString)
    throws ClassNotFoundException, InstantiationException, IllegalAccessException, ClassCastException
  {
    int i = this._sources.size();
    DOMImplementationListImpl localDOMImplementationListImpl = new DOMImplementationListImpl();
    Object localObject = null;
    for (int j = 0; j < i; j++)
    {
      DOMImplementationSource localDOMImplementationSource = (DOMImplementationSource)this._sources.get(j);
      DOMImplementationList localDOMImplementationList = localDOMImplementationSource.getDOMImplementationList(paramString);
      for (int k = 0; k < localDOMImplementationList.getLength(); k++) {
        localDOMImplementationListImpl.add(localDOMImplementationList.item(k));
      }
    }
    return localDOMImplementationListImpl;
  }
  
  public void addSource(DOMImplementationSource paramDOMImplementationSource)
    throws ClassNotFoundException, InstantiationException, IllegalAccessException
  {
    this._sources.add(paramDOMImplementationSource);
  }
  
  private static Class getClass(String paramString)
    throws ClassNotFoundException, IllegalAccessException, InstantiationException
  {
    Method localMethod = null;
    ClassLoader localClassLoader = null;
    try
    {
      localMethod = Thread.class.getMethod("getContextClassLoader", null);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      localClassLoader = DOMImplementationRegistry.class.getClassLoader();
    }
    if (localClassLoader == null) {
      try
      {
        localClassLoader = (ClassLoader)localMethod.invoke(Thread.currentThread(), null);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new UnknownError(localIllegalAccessException.getMessage());
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new UnknownError(localInvocationTargetException.getMessage());
      }
    }
    if (localClassLoader == null) {
      return Class.forName(paramString);
    }
    try
    {
      return localClassLoader.loadClass(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException) {}
    return Class.forName(paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\bootstrap\DOMImplementationRegistry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */