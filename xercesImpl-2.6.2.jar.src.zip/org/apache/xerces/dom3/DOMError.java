package org.apache.xerces.dom3;

public abstract interface DOMError
{
  public static final short SEVERITY_WARNING = 1;
  public static final short SEVERITY_ERROR = 2;
  public static final short SEVERITY_FATAL_ERROR = 3;
  
  public abstract short getSeverity();
  
  public abstract String getMessage();
  
  public abstract String getType();
  
  public abstract Object getRelatedException();
  
  public abstract Object getRelatedData();
  
  public abstract DOMLocator getLocation();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\DOMError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */