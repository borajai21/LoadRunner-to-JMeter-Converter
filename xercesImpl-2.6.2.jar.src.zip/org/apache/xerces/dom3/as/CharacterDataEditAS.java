package org.apache.xerces.dom3.as;

/**
 * @deprecated
 */
public abstract interface CharacterDataEditAS
  extends NodeEditAS
{
  public abstract boolean getIsWhitespaceOnly();
  
  public abstract boolean canSetData(int paramInt1, int paramInt2);
  
  public abstract boolean canAppendData(String paramString);
  
  public abstract boolean canReplaceData(int paramInt1, int paramInt2, String paramString);
  
  public abstract boolean canInsertData(int paramInt, String paramString);
  
  public abstract boolean canDeleteData(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\CharacterDataEditAS.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */