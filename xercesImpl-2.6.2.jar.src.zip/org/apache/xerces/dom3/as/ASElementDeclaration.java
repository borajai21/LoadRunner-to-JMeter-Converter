package org.apache.xerces.dom3.as;

/**
 * @deprecated
 */
public abstract interface ASElementDeclaration
  extends ASObject
{
  public static final short EMPTY_CONTENTTYPE = 1;
  public static final short ANY_CONTENTTYPE = 2;
  public static final short MIXED_CONTENTTYPE = 3;
  public static final short ELEMENTS_CONTENTTYPE = 4;
  
  public abstract boolean getStrictMixedContent();
  
  public abstract void setStrictMixedContent(boolean paramBoolean);
  
  public abstract ASDataType getElementType();
  
  public abstract void setElementType(ASDataType paramASDataType);
  
  public abstract boolean getIsPCDataOnly();
  
  public abstract void setIsPCDataOnly(boolean paramBoolean);
  
  public abstract short getContentType();
  
  public abstract void setContentType(short paramShort);
  
  public abstract String getSystemId();
  
  public abstract void setSystemId(String paramString);
  
  public abstract ASContentModel getAsCM();
  
  public abstract void setAsCM(ASContentModel paramASContentModel);
  
  public abstract ASNamedObjectMap getASAttributeDecls();
  
  public abstract void setASAttributeDecls(ASNamedObjectMap paramASNamedObjectMap);
  
  public abstract void addASAttributeDecl(ASAttributeDeclaration paramASAttributeDeclaration);
  
  public abstract ASAttributeDeclaration removeASAttributeDecl(ASAttributeDeclaration paramASAttributeDeclaration);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\ASElementDeclaration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */