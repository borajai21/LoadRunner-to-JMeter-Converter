package org.apache.xerces.dom3.as;

/**
 * @deprecated
 */
public abstract interface ASObjectList
{
  public abstract int getLength();
  
  public abstract ASObject item(int paramInt);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\ASObjectList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */