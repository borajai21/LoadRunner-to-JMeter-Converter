package org.apache.xerces.dom3.as;

import org.w3c.dom.DOMException;

/**
 * @deprecated
 */
public abstract interface DocumentAS
{
  public abstract ASModel getActiveASModel();
  
  public abstract void setActiveASModel(ASModel paramASModel);
  
  public abstract ASObjectList getBoundASModels();
  
  public abstract void setBoundASModels(ASObjectList paramASObjectList);
  
  public abstract ASModel getInternalAS();
  
  public abstract void setInternalAS(ASModel paramASModel);
  
  public abstract void addAS(ASModel paramASModel);
  
  public abstract void removeAS(ASModel paramASModel);
  
  public abstract ASElementDeclaration getElementDeclaration()
    throws DOMException;
  
  public abstract void validate()
    throws DOMASException;
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\DocumentAS.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */