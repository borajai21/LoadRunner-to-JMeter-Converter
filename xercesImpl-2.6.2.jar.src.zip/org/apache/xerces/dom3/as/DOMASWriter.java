package org.apache.xerces.dom3.as;

import java.io.OutputStream;
import org.w3c.dom.ls.LSSerializer;

/**
 * @deprecated
 */
public abstract interface DOMASWriter
  extends LSSerializer
{
  public abstract void writeASModel(OutputStream paramOutputStream, ASModel paramASModel)
    throws Exception;
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\DOMASWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */