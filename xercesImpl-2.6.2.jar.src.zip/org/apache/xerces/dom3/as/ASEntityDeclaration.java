package org.apache.xerces.dom3.as;

/**
 * @deprecated
 */
public abstract interface ASEntityDeclaration
  extends ASObject
{
  public static final short INTERNAL_ENTITY = 1;
  public static final short EXTERNAL_ENTITY = 2;
  
  public abstract short getEntityType();
  
  public abstract void setEntityType(short paramShort);
  
  public abstract String getEntityValue();
  
  public abstract void setEntityValue(String paramString);
  
  public abstract String getSystemId();
  
  public abstract void setSystemId(String paramString);
  
  public abstract String getPublicId();
  
  public abstract void setPublicId(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\ASEntityDeclaration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */