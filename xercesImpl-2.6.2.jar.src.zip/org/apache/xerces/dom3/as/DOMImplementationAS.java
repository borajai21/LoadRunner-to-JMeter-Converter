package org.apache.xerces.dom3.as;

/**
 * @deprecated
 */
public abstract interface DOMImplementationAS
{
  public abstract ASModel createAS(boolean paramBoolean);
  
  public abstract DOMASBuilder createDOMASBuilder();
  
  public abstract DOMASWriter createDOMASWriter();
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\DOMImplementationAS.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */