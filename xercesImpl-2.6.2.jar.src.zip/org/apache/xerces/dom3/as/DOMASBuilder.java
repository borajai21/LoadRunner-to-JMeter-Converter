package org.apache.xerces.dom3.as;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSParser;

/**
 * @deprecated
 */
public abstract interface DOMASBuilder
  extends LSParser
{
  public abstract ASModel getAbstractSchema();
  
  public abstract void setAbstractSchema(ASModel paramASModel);
  
  public abstract ASModel parseASURI(String paramString)
    throws DOMASException, Exception;
  
  public abstract ASModel parseASInputSource(LSInput paramLSInput)
    throws DOMASException, Exception;
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\as\DOMASBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */