package org.apache.xerces.dom3;

import org.w3c.dom.DOMImplementation;

public abstract interface DOMImplementationSource
{
  public abstract DOMImplementation getDOMImplementation(String paramString);
  
  public abstract DOMImplementationList getDOMImplementationList(String paramString);
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\xerces\dom3\DOMImplementationSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */