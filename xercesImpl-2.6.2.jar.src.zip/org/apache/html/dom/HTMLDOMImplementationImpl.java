package org.apache.html.dom;

import org.apache.xerces.dom.DOMImplementationImpl;
import org.w3c.dom.DOMException;
import org.w3c.dom.html.HTMLDOMImplementation;
import org.w3c.dom.html.HTMLDocument;

public class HTMLDOMImplementationImpl
  extends DOMImplementationImpl
  implements HTMLDOMImplementation
{
  private static HTMLDOMImplementation _instance = new HTMLDOMImplementationImpl();
  
  public final HTMLDocument createHTMLDocument(String paramString)
    throws DOMException
  {
    if (paramString == null) {
      throw new NullPointerException("HTM014 Argument 'title' is null.");
    }
    HTMLDocumentImpl localHTMLDocumentImpl = new HTMLDocumentImpl();
    localHTMLDocumentImpl.setTitle(paramString);
    return localHTMLDocumentImpl;
  }
  
  public static HTMLDOMImplementation getHTMLDOMImplementation()
  {
    return _instance;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLDOMImplementationImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */