package org.apache.html.dom;

class CollectionIndex
{
  private int _index;
  
  int getIndex()
  {
    return this._index;
  }
  
  void decrement()
  {
    this._index -= 1;
  }
  
  boolean isZero()
  {
    return this._index <= 0;
  }
  
  CollectionIndex(int paramInt)
  {
    this._index = paramInt;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\CollectionIndex.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */