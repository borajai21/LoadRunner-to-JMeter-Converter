package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.apache.xerces.dom.ParentNode;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLFormElement;

public class HTMLFormElementImpl
  extends HTMLElementImpl
  implements HTMLFormElement
{
  private HTMLCollectionImpl _elements;
  
  public HTMLCollection getElements()
  {
    if (this._elements == null) {
      this._elements = new HTMLCollectionImpl(this, (short)8);
    }
    return this._elements;
  }
  
  public int getLength()
  {
    return getElements().getLength();
  }
  
  public String getName()
  {
    return getAttribute("name");
  }
  
  public void setName(String paramString)
  {
    setAttribute("name", paramString);
  }
  
  public String getAcceptCharset()
  {
    return getAttribute("accept-charset");
  }
  
  public void setAcceptCharset(String paramString)
  {
    setAttribute("accept-charset", paramString);
  }
  
  public String getAction()
  {
    return getAttribute("action");
  }
  
  public void setAction(String paramString)
  {
    setAttribute("action", paramString);
  }
  
  public String getEnctype()
  {
    return getAttribute("enctype");
  }
  
  public void setEnctype(String paramString)
  {
    setAttribute("enctype", paramString);
  }
  
  public String getMethod()
  {
    return capitalize(getAttribute("method"));
  }
  
  public void setMethod(String paramString)
  {
    setAttribute("method", paramString);
  }
  
  public String getTarget()
  {
    return getAttribute("target");
  }
  
  public void setTarget(String paramString)
  {
    setAttribute("target", paramString);
  }
  
  public void submit() {}
  
  public void reset() {}
  
  public NodeList getChildNodes()
  {
    return getChildNodesUnoptimized();
  }
  
  public HTMLFormElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLFormElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */