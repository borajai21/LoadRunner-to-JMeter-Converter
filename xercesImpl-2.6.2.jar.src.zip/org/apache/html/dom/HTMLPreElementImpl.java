package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.html.HTMLPreElement;

public class HTMLPreElementImpl
  extends HTMLElementImpl
  implements HTMLPreElement
{
  public int getWidth()
  {
    return getInteger(getAttribute("width"));
  }
  
  public void setWidth(int paramInt)
  {
    setAttribute("width", String.valueOf(paramInt));
  }
  
  public HTMLPreElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLPreElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */