package org.apache.html.dom;

import org.apache.xerces.dom.ParentNode;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.w3c.dom.html.HTMLTitleElement;

public class HTMLTitleElementImpl
  extends HTMLElementImpl
  implements HTMLTitleElement
{
  public String getText()
  {
    Node localNode = getFirstChild();
    String str = "";
    while (localNode != null)
    {
      if ((localNode instanceof Text)) {
        str = str + ((Text)localNode).getData();
      }
      localNode = localNode.getNextSibling();
    }
    return str;
  }
  
  public void setText(String paramString)
  {
    Node localNode;
    for (Object localObject = getFirstChild(); localObject != null; localObject = localNode)
    {
      localNode = ((Node)localObject).getNextSibling();
      removeChild((Node)localObject);
    }
    insertBefore(getOwnerDocument().createTextNode(paramString), getFirstChild());
  }
  
  public HTMLTitleElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLTitleElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */