package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.html.HTMLOListElement;

public class HTMLOListElementImpl
  extends HTMLElementImpl
  implements HTMLOListElement
{
  public boolean getCompact()
  {
    return getBinary("compact");
  }
  
  public void setCompact(boolean paramBoolean)
  {
    setAttribute("compact", paramBoolean);
  }
  
  public int getStart()
  {
    return getInteger(getAttribute("start"));
  }
  
  public void setStart(int paramInt)
  {
    setAttribute("start", String.valueOf(paramInt));
  }
  
  public String getType()
  {
    return getAttribute("type");
  }
  
  public void setType(String paramString)
  {
    setAttribute("type", paramString);
  }
  
  public HTMLOListElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLOListElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */