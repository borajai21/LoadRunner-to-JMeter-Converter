package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.html.HTMLLIElement;

public class HTMLLIElementImpl
  extends HTMLElementImpl
  implements HTMLLIElement
{
  public String getType()
  {
    return getAttribute("type");
  }
  
  public void setType(String paramString)
  {
    setAttribute("type", paramString);
  }
  
  public int getValue()
  {
    return getInteger(getAttribute("value"));
  }
  
  public void setValue(int paramInt)
  {
    setAttribute("value", String.valueOf(paramInt));
  }
  
  public HTMLLIElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLLIElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */