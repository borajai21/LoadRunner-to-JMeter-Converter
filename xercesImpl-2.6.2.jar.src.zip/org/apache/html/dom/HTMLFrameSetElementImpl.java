package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.html.HTMLFrameSetElement;

public class HTMLFrameSetElementImpl
  extends HTMLElementImpl
  implements HTMLFrameSetElement
{
  public String getCols()
  {
    return getAttribute("cols");
  }
  
  public void setCols(String paramString)
  {
    setAttribute("cols", paramString);
  }
  
  public String getRows()
  {
    return getAttribute("rows");
  }
  
  public void setRows(String paramString)
  {
    setAttribute("rows", paramString);
  }
  
  public HTMLFrameSetElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLFrameSetElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */