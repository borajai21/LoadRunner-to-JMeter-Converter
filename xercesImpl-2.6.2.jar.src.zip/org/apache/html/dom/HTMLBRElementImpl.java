package org.apache.html.dom;

import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.html.HTMLBRElement;

public class HTMLBRElementImpl
  extends HTMLElementImpl
  implements HTMLBRElement
{
  public String getClear()
  {
    return capitalize(getAttribute("clear"));
  }
  
  public void setClear(String paramString)
  {
    setAttribute("clear", paramString);
  }
  
  public HTMLBRElementImpl(HTMLDocumentImpl paramHTMLDocumentImpl, String paramString)
  {
    super(paramHTMLDocumentImpl, paramString);
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\HTMLBRElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */