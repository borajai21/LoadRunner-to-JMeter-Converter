package org.apache.html.dom;

import org.apache.xerces.dom.DeepNodeListImpl;
import org.apache.xerces.dom.ElementImpl;
import org.apache.xerces.dom.NodeImpl;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NameNodeListImpl
  extends DeepNodeListImpl
  implements NodeList
{
  public NameNodeListImpl(NodeImpl paramNodeImpl, String paramString)
  {
    super(paramNodeImpl, paramString);
  }
  
  protected Node nextMatchingElementAfter(Node paramNode)
  {
    while (paramNode != null)
    {
      if (paramNode.hasChildNodes())
      {
        paramNode = paramNode.getFirstChild();
      }
      else
      {
        Node localNode;
        if ((paramNode != this.rootNode) && (null != (localNode = paramNode.getNextSibling())))
        {
          paramNode = localNode;
        }
        else
        {
          localNode = null;
          while (paramNode != this.rootNode)
          {
            localNode = paramNode.getNextSibling();
            if (localNode != null) {
              break;
            }
            paramNode = paramNode.getParentNode();
          }
          paramNode = localNode;
        }
      }
      if ((paramNode != this.rootNode) && (paramNode != null) && (paramNode.getNodeType() == 1))
      {
        String str = ((ElementImpl)paramNode).getAttribute("name");
        if ((str.equals("*")) || (str.equals(this.tagName))) {
          return paramNode;
        }
      }
    }
    return null;
  }
}


/* Location:              C:\Users\jai.bora\Desktop\Code LR Jmeter\LR2JMeter v2.1.jar!\xercesImpl-2.6.2.jar!\org\apache\html\dom\NameNodeListImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */